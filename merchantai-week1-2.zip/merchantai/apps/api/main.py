from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from core.config import settings
from routers import auth, catalogue, health, products

app = FastAPI(
    title="MerchantAI API",
    version="0.1.0",
    description="AI Commerce Platform for Builders' Merchants — Week 2: product import & catalogue",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api/v1")
app.include_router(auth.router, prefix="/api/v1")
app.include_router(products.router, prefix="/api/v1")
app.include_router(catalogue.router, prefix="/api/v1")
