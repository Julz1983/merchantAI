from engines.import_engine.parsers.base import Parser, ParsedSheet, ParseError
from engines.import_engine.parsers.csv_parser import CSVParser
from engines.import_engine.parsers.xlsx_parser import XLSXParser

# Pluggable by design (brief: CSV/Excel/XML/JSON). MVP ships CSV + XLSX only
# (see architecture §0.2) — adding JSON/XML later means adding a parser here,
# not touching mapping.py or product_import.py.
_PARSERS: dict[str, Parser] = {
    ".csv": CSVParser(),
    ".xlsx": XLSXParser(),
}


def get_parser(filename: str) -> Parser:
    lower = filename.lower()
    for ext, parser in _PARSERS.items():
        if lower.endswith(ext):
            return parser
    raise ParseError(f"Unsupported file type. Supported formats: {', '.join(_PARSERS.keys())}")


__all__ = ["get_parser", "ParsedSheet", "ParseError"]
