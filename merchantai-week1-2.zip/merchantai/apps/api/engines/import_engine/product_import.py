from datetime import datetime, timezone
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from engines.import_engine.mapping import NormalizedRow
from models.catalogue import Brand, Category, ImportJob, Product

# Cap stored error detail so a catalogue with thousands of bad rows doesn't
# bloat the import_jobs row — the merchant gets the first N with actionable
# detail, plus a total count, rather than either nothing or everything.
MAX_STORED_ERRORS = 200

# Job progress is written to the DB in batches, not once per row, so a large
# import doesn't turn into thousands of tiny UPDATE statements.
PROGRESS_FLUSH_EVERY = 25


def _get_or_create_category(db: Session, merchant_id: UUID, name: str, cache: dict[str, UUID]) -> UUID | None:
    if not name:
        return None
    key = name.strip().lower()
    if key in cache:
        return cache[key]
    existing = db.scalar(select(Category).where(Category.merchant_id == merchant_id, Category.name.ilike(name)))
    if existing:
        cache[key] = existing.id
        return existing.id
    new = Category(merchant_id=merchant_id, name=name.strip())
    db.add(new)
    db.flush()
    cache[key] = new.id
    return new.id


def _get_or_create_brand(db: Session, merchant_id: UUID, name: str, cache: dict[str, UUID]) -> UUID | None:
    if not name:
        return None
    key = name.strip().lower()
    if key in cache:
        return cache[key]
    existing = db.scalar(select(Brand).where(Brand.merchant_id == merchant_id, Brand.name.ilike(name)))
    if existing:
        cache[key] = existing.id
        return existing.id
    new = Brand(merchant_id=merchant_id, name=name.strip())
    db.add(new)
    db.flush()
    cache[key] = new.id
    return new.id


def run_import(db: Session, merchant_id: UUID, job: ImportJob, rows: list[NormalizedRow]) -> None:
    """
    Runs synchronously against the given (already tenant-scoped) session —
    the caller is responsible for running this inside a background task with
    its own session, since the request's session is closed by the time a
    FastAPI BackgroundTask executes. See routers/products.py.
    """
    job.status = "processing"
    job.total_rows = len(rows)
    db.commit()

    category_cache: dict[str, UUID] = {}
    brand_cache: dict[str, UUID] = {}
    error_rows: list[dict] = []
    created_count = 0
    updated_count = 0

    for row in rows:
        if not row.is_valid:
            if len(error_rows) < MAX_STORED_ERRORS:
                error_rows.append({"row_number": row.row_number, "errors": row.errors})
        else:
            category_id = _get_or_create_category(db, merchant_id, row.category or "", category_cache)
            brand_id = _get_or_create_brand(db, merchant_id, row.brand or "", brand_cache)

            existing = db.scalar(select(Product).where(Product.merchant_id == merchant_id, Product.sku == row.sku))
            if existing:
                existing.name = row.name
                existing.description = row.description
                existing.category_id = category_id
                existing.brand_id = brand_id
                existing.price = row.price
                existing.images = row.images
                existing.product_url = row.product_url
                existing.specifications = row.specifications
                existing.attributes = row.attributes
                existing.stock_status = row.stock_status
                updated_count += 1
            else:
                db.add(Product(
                    merchant_id=merchant_id,
                    sku=row.sku,
                    name=row.name,
                    description=row.description,
                    category_id=category_id,
                    brand_id=brand_id,
                    price=row.price,
                    images=row.images,
                    product_url=row.product_url,
                    specifications=row.specifications,
                    attributes=row.attributes,
                    stock_status=row.stock_status,
                ))
                created_count += 1

        job.processed_rows += 1
        if job.processed_rows % PROGRESS_FLUSH_EVERY == 0:
            db.commit()

    job.created_count = created_count
    job.updated_count = updated_count
    job.error_rows = error_rows
    job.status = "completed"
    job.completed_at = datetime.now(timezone.utc)
    db.commit()
