"use client";

import { useCallback, useRef, useState } from "react";
import Link from "next/link";
import { api, type ImportInspectResponse, type ImportJob } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

type Step = "upload" | "mapping" | "importing" | "done";

const FIELD_LABELS: Record<string, string> = {
  sku: "SKU", name: "Product name", description: "Description", category: "Category",
  price: "Price", brand: "Brand", images: "Images", product_url: "Product URL",
  specifications: "Specifications", attributes: "Attributes", stock_status: "Stock status",
};

export default function ImportProductsPage() {
  const [step, setStep] = useState<Step>("upload");
  const [file, setFile] = useState<File | null>(null);
  const [inspecting, setInspecting] = useState(false);
  const [inspectData, setInspectData] = useState<ImportInspectResponse | null>(null);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [job, setJob] = useState<ImportJob | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function handleFile(selected: File) {
    setError(null);
    setFile(selected);
    setInspecting(true);
    try {
      const token = getAccessToken();
      if (!token) throw new Error("Not signed in");
      const result = await api.inspectImport(token, selected);
      setInspectData(result);
      setMapping(result.suggested_mapping);
      setStep("mapping");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't read that file");
    } finally {
      setInspecting(false);
    }
  }

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) handleFile(dropped);
  }, []);

  const missingRequired = (inspectData?.required_fields ?? []).filter((f) => !mapping[f]);

  async function startImport() {
    if (!file) return;
    setError(null);
    setStep("importing");
    try {
      const token = getAccessToken();
      if (!token) throw new Error("Not signed in");
      const startedJob = await api.startImport(token, file, mapping);
      pollJob(token, startedJob.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Import failed to start");
      setStep("mapping");
    }
  }

  function pollJob(token: string, jobId: string) {
    const interval = setInterval(async () => {
      try {
        const status = await api.getImportStatus(token, jobId);
        setJob(status);
        if (status.status === "completed" || status.status === "failed") {
          clearInterval(interval);
          setStep("done");
        }
      } catch {
        clearInterval(interval);
        setError("Lost connection while checking import progress");
        setStep("done");
      }
    }, 800);
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/products" className="text-sm text-ink-muted hover:text-steel">← Products</Link>
      <h1 className="mt-3 font-display text-2xl font-bold">Import products</h1>
      <p className="mt-1 text-sm text-ink-muted">Upload a CSV or Excel file, review how columns map to product fields, then confirm.</p>

      {error && (
        <p className="mt-4 border-l-2 border-signal bg-signal/5 px-3 py-2 text-sm text-signal">{error}</p>
      )}

      {step === "upload" && (
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={onDrop}
          onClick={() => fileInputRef.current?.click()}
          className="mt-6 flex cursor-pointer flex-col items-center justify-center border-2 border-dashed border-line bg-white px-6 py-16 text-center transition hover:border-steel"
        >
          <div className="mb-3 h-10 w-10 bg-signal spec-corner" />
          <p className="font-medium">{inspecting ? "Reading file…" : "Drop a CSV or XLSX file here"}</p>
          <p className="mt-1 text-sm text-ink-muted">or click to browse</p>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.xlsx"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
        </div>
      )}

      {step === "mapping" && inspectData && (
        <div className="mt-6">
          <div className="border border-line bg-white p-5">
            <div className="mb-4 flex items-center justify-between">
              <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">
                {file?.name} — {inspectData.total_rows} rows detected
              </p>
            </div>

            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line font-mono text-[11px] uppercase tracking-wider text-ink-muted">
                  <th className="py-2 pr-4 font-medium">Product field</th>
                  <th className="py-2 font-medium">Your column</th>
                </tr>
              </thead>
              <tbody>
                {inspectData.target_fields.map((field) => {
                  const required = inspectData.required_fields.includes(field);
                  return (
                    <tr key={field} className="border-b border-line last:border-0">
                      <td className="py-2 pr-4">
                        {FIELD_LABELS[field] ?? field}
                        {required && <span className="ml-1 text-signal">*</span>}
                      </td>
                      <td className="py-2">
                        <select
                          value={mapping[field] ?? ""}
                          onChange={(e) => setMapping((m) => ({ ...m, [field]: e.target.value }))}
                          className="w-full border border-line bg-paper px-2 py-1.5 text-sm focus:border-steel focus:outline-none"
                        >
                          <option value="">— not mapped —</option>
                          {inspectData.headers.map((h) => <option key={h} value={h}>{h}</option>)}
                        </select>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {inspectData.sample_rows.length > 0 && (
            <div className="mt-4 border border-line bg-white p-5">
              <p className="mb-3 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Preview (first {inspectData.sample_rows.length} rows)</p>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-line">
                      {inspectData.headers.map((h) => <th key={h} className="py-1.5 pr-4 font-medium text-ink-muted">{h}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {inspectData.sample_rows.map((row, i) => (
                      <tr key={i} className="border-b border-line last:border-0">
                        {inspectData.headers.map((h) => <td key={h} className="py-1.5 pr-4 font-mono">{row[h] || "—"}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {missingRequired.length > 0 && (
            <p className="mt-4 text-sm text-signal">
              Map required fields before continuing: {missingRequired.map((f) => FIELD_LABELS[f] ?? f).join(", ")}
            </p>
          )}

          <div className="mt-4 flex gap-3">
            <button
              onClick={() => { setStep("upload"); setInspectData(null); setFile(null); }}
              className="border border-line px-4 py-2.5 text-sm font-medium text-ink-muted hover:border-steel hover:text-steel"
            >
              Choose a different file
            </button>
            <button
              onClick={startImport}
              disabled={missingRequired.length > 0}
              className="bg-ink px-4 py-2.5 text-sm font-medium text-paper transition hover:bg-steel disabled:opacity-40"
            >
              Import {inspectData.total_rows} rows
            </button>
          </div>
        </div>
      )}

      {step === "importing" && (
        <div className="mt-6 border border-line bg-white p-8 text-center">
          <p className="font-mono text-sm text-ink-muted">
            Importing{job ? ` — ${job.processed_rows} / ${job.total_rows} rows` : "…"}
          </p>
          <div className="mx-auto mt-4 h-1.5 w-full max-w-sm bg-paper">
            <div
              className="h-1.5 bg-signal transition-all"
              style={{ width: job && job.total_rows > 0 ? `${(job.processed_rows / job.total_rows) * 100}%` : "10%" }}
            />
          </div>
        </div>
      )}

      {step === "done" && job && (
        <div className="mt-6 border border-line bg-white p-6">
          <p className="font-display text-lg font-bold">
            {job.status === "completed" ? "Import complete" : "Import failed"}
          </p>
          <div className="mt-4 grid grid-cols-3 gap-4">
            <div>
              <p className="font-mono text-2xl font-bold">{job.created_count}</p>
              <p className="text-xs text-ink-muted">Created</p>
            </div>
            <div>
              <p className="font-mono text-2xl font-bold">{job.updated_count}</p>
              <p className="text-xs text-ink-muted">Updated</p>
            </div>
            <div>
              <p className="font-mono text-2xl font-bold text-signal">{job.error_rows.length}</p>
              <p className="text-xs text-ink-muted">Skipped</p>
            </div>
          </div>

          {job.error_rows.length > 0 && (
            <div className="mt-5">
              <p className="mb-2 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Skipped rows</p>
              <ul className="space-y-1 text-sm">
                {job.error_rows.slice(0, 10).map((e) => (
                  <li key={e.row_number} className="text-ink-muted">
                    Row {e.row_number}: {e.errors.join(", ")}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <Link
            href="/products"
            className="mt-6 inline-block bg-ink px-4 py-2.5 text-sm font-medium text-paper transition hover:bg-steel"
          >
            View products
          </Link>
        </div>
      )}
    </div>
  );
}
