const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000/api/v1";

type Envelope<T> = {
  data: T | null;
  meta: { request_id: string };
  error: { message: string } | null;
};

export class ApiError extends Error {}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const isFormData = options.body instanceof FormData;
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      // Don't set Content-Type for FormData — the browser needs to add its
      // own multipart boundary, which it can only do if we leave this unset.
      ...(isFormData ? {} : { "Content-Type": "application/json" }),
      ...(options.headers ?? {}),
    },
  });

  let body: Envelope<T>;
  try {
    body = await res.json();
  } catch {
    throw new ApiError(`Request to ${path} failed (${res.status})`);
  }

  if (!res.ok || body.error) {
    throw new ApiError(body.error?.message ?? `Request to ${path} failed (${res.status})`);
  }
  if (body.data === null) {
    throw new ApiError(`Request to ${path} returned no data`);
  }
  return body.data;
}

function authHeaders(token: string): HeadersInit {
  return { Authorization: `Bearer ${token}` };
}

// ── Auth ──────────────────────────────────────────────────────────────

export type TokenResponse = {
  access_token: string;
  refresh_token: string;
  token_type: string;
};

export type MeResponse = {
  user_id: string;
  merchant_id: string;
  email: string;
  role: string;
  merchant_name: string;
};

// ── Catalogue ─────────────────────────────────────────────────────────

export type Product = {
  id: string;
  sku: string;
  name: string;
  description: string | null;
  category_id: string | null;
  category_name: string | null;
  brand_id: string | null;
  brand_name: string | null;
  price: number | null;
  currency: string;
  images: string[];
  product_url: string | null;
  specifications: Record<string, string>;
  attributes: Record<string, string>;
  stock_status: string;
  created_at: string;
  updated_at: string;
};

export type ProductListResponse = {
  items: Product[];
  total: number;
  page: number;
  page_size: number;
};

export type Category = { id: string; name: string; parent_id: string | null };
export type Brand = { id: string; name: string };

// ── Import ────────────────────────────────────────────────────────────

export type ImportInspectResponse = {
  headers: string[];
  suggested_mapping: Record<string, string>;
  sample_rows: Record<string, string>[];
  total_rows: number;
  target_fields: string[];
  required_fields: string[];
};

export type ImportJob = {
  id: string;
  filename: string;
  status: "pending" | "processing" | "completed" | "failed";
  total_rows: number;
  processed_rows: number;
  created_count: number;
  updated_count: number;
  error_rows: { row_number: number; errors: string[] }[];
  created_at: string;
  completed_at: string | null;
};

export const api = {
  login: (email: string, password: string) =>
    request<TokenResponse>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),

  me: (token: string) => request<MeResponse>("/auth/me", { headers: authHeaders(token) }),

  listProducts: (
    token: string,
    params: { page?: number; page_size?: number; search?: string; category_id?: string; brand_id?: string; stock_status?: string } = {}
  ) => {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v && query.set(k, String(v)));
    return request<ProductListResponse>(`/products?${query.toString()}`, { headers: authHeaders(token) });
  },

  getProduct: (token: string, id: string) => request<Product>(`/products/${id}`, { headers: authHeaders(token) }),

  listCategories: (token: string) => request<Category[]>("/categories", { headers: authHeaders(token) }),
  listBrands: (token: string) => request<Brand[]>("/brands", { headers: authHeaders(token) }),

  inspectImport: (token: string, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<ImportInspectResponse>("/products/import/inspect", {
      method: "POST",
      headers: authHeaders(token),
      body: form,
    });
  },

  startImport: (token: string, file: File, mapping: Record<string, string>) => {
    const form = new FormData();
    form.append("file", file);
    form.append("mapping", JSON.stringify(mapping));
    return request<ImportJob>("/products/import", {
      method: "POST",
      headers: authHeaders(token),
      body: form,
    });
  },

  getImportStatus: (token: string, jobId: string) =>
    request<ImportJob>(`/products/import/${jobId}`, { headers: authHeaders(token) }),
};
