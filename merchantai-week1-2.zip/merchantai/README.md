# MerchantAI — Week 1–2: Foundations + Product Import

Implements Weeks 1–2 of the roadmap (see `docs/architecture/MerchantAI-Architecture-v1.md`):

**Week 1 — Foundations**
- Monorepo scaffold (`apps/api`, `apps/dashboard`, `packages/types`)
- Postgres schema + Alembic migrations for tenancy (`merchants`, `users`, `api_keys`)
- Row-Level Security enforced per `merchant_id`, verified against a real restricted DB role (see "Security note" below)
- Auth & tenancy: JWT login/refresh, `/auth/me`, tenant context middleware
- Docker Compose local environment
- Dashboard shell: login page + empty authenticated shell

**Week 2 — Product import & catalogue**
- CSV/XLSX import engine: pluggable parsers, header-to-field mapping with auto-suggestion, tolerant per-row validation
- Product/Category/Brand models + upsert-by-SKU import pipeline
- Import job tracking with progress + per-row error reporting (`/products/import/inspect`, `/products/import`, `/products/import/{job_id}`)
- Full Products CRUD + list (search, filter by category/brand/stock, pagination)

## Running it locally

```bash
cp .env.example .env
docker compose up --build
```

Then, **on first boot**, run these in order:

```bash
docker compose exec api alembic upgrade head
docker compose exec api python -m core.bootstrap_roles
docker compose exec api python -m core.seed
```

- API: http://localhost:8000 (docs at `/docs`)
- Dashboard: http://localhost:3000
- Postgres: localhost:5432
- Qdrant: http://localhost:6333
- Redis: localhost:6379

Seeded login: `admin@demo-merchant.dev` / `changeme123`

## Security note: why there's a `bootstrap_roles` step

`alembic upgrade` runs as a superuser/owner role (needs DDL rights to create
tables and RLS policies). The **running API must not use that same role** —
Postgres superusers bypass Row-Level Security unconditionally, even with
`FORCE ROW LEVEL SECURITY` set, with no error or warning. Connect the app as
a superuser and every tenant-isolation policy in the schema silently stops
being enforced.

`core/bootstrap_roles.py` creates a separate, least-privilege `merchantai_app`
role (DML only, no DDL, no BYPASSRLS, no SUPERUSER) that the running app
connects as instead. This was caught by live-testing tenant isolation
end-to-end with two seeded merchants — the policies looked correct in
isolation but weren't actually being enforced until the app stopped
connecting as the migration role. See `MIGRATIONS_DATABASE_URL` vs
`DATABASE_URL` in `.env.example`.

## What's deliberately NOT in this slice

Per the roadmap, documents/RAG, Knowledge Graph, AI Engine, widget, and
analytics land in Weeks 3–7. JSON/XML product import formats are a deliberate
post-MVP cut (architecture §0.2) — the parser interface is pluggable so
adding them later doesn't touch the mapping or import pipeline.
