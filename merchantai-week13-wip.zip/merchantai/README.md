# MerchantAI — Weeks 1–10: MVP + JSON/XML Import + Basket Builder

The full 8-week MVP roadmap, plus two post-MVP additions.

**Weeks 1–8** — tenancy/auth, product import, documents/RAG, Knowledge Graph, AI Engine, embeddable
widget, analytics, hardening (RLS audit, rate limiting, consistent error handling, realistic demo
data, production deployment config).

**Week 9 — JSON/XML product import.** Deferred at MVP with the parser interface built specifically
to make this additive — proved out with two new parser files and one registry entry, zero changes
to mapping/import-orchestration logic.

**Week 10 — Basket Builder**
- Explicitly teed up in architecture Journey B: *"Assistant offers to build a shopping list from
  the conversation — the data model supports this now."* This week builds the module.
- `baskets` / `basket_items` tables, session-scoped (anonymous widget sessions, same pattern as
  `chats`), RLS-protected like everything else.
- `engines/commerce_engine/basket_service.py`: add (increments quantity if already present, never
  duplicates), remove, update quantity, and a fully-hydrated view joined against live product data
  (price, stock status) so a basket never shows stale information.
- Widget-facing endpoints under `/widget/basket/*`, API-key authed, inheriting the same rate
  limiting and error-envelope consistency as every other widget route.
- New `basket_add` analytics event — the concrete signal that closes the loop from "recommended"
  all the way to "customer built a list."
- Widget UI: an "Add to list" button on every recommended product card, a basket icon with a live
  item-count badge in the header, and a basket view (remove items, see running subtotal) — all
  built in vanilla TS, still well under the 50kb budget (15.2kb total).

## Running it locally

```bash
cp .env.example .env
docker compose up --build
```

Then, **on first boot**, run these in order:

```bash
docker compose exec api alembic upgrade head
docker compose exec api python -m core.bootstrap_roles
docker compose exec api python -m core.seed
docker compose exec api python -m core.rls_audit   # optional but recommended
```

- API: http://localhost:8000 (docs at `/docs`) · Dashboard: http://localhost:3000
- Widget test page: http://localhost:8080/example/
- Postgres: localhost:5432 · Qdrant: http://localhost:6333 · Redis: localhost:6379

Seeded login: `admin@demo-merchant.dev` / `changeme123`

## Deploying to staging/production

See `docs/DEPLOYMENT.md`.

## Design notes worth knowing about

**A real float-precision bug, caught by testing with a real price, not a round number.** Adding 5
units of a £45.99 product produced a subtotal of `229.95000000000002` — standard floating-point
imprecision from `price * quantity` in Python floats, invisible in tests that only use round
numbers like £10.00. Fixed by rounding every currency value to 2 decimal places at the point where
it's computed, with a regression test that asserts *exact* equality (`== 229.95`, not
`pytest.approx`) specifically to catch this class of bug reappearing.

**The unique `(basket_id, product_id)` constraint is a backstop, not just documentation.** Adding a
product already in the basket increments its quantity in application code — the database
constraint exists so that even a race between two near-simultaneous "add" requests for the same
product can't produce two rows for one product in one basket.

**A basket item can only be removed by the session that owns it, not just the right merchant.**
`remove_item`/`update_item_quantity` check both the merchant AND the session_id on the item's
parent basket — verified with a dedicated test simulating one session trying to manipulate
another's basket item by id.

**The full basket flow is verified against the real built widget bundle**, not just the API:
`apps/widget/test-e2e.mjs` clicks the real "Add to list" button, confirms the header badge updates,
opens the basket view, confirms the item renders, removes it, and confirms both the view and badge
correctly reset — all against a live server with real seeded product data, and confirming the
`basket_add` analytics event actually landed via a separate API call, not just that the UI didn't
throw.

## Design notes from earlier weeks (still relevant)

**Security — `bootstrap_roles` step is not optional.** Postgres superusers bypass Row-Level
Security unconditionally. `core/rls_audit.py` verifies this is actually enforced by reading
Postgres's live catalog.

**Products and document chunks share one Qdrant collection per merchant**, distinguished by an
explicit `content_type` tag — a real bug here was caught once demo data included a realistic
number of products alongside documents.

**Rate limiting fails open**; an unreachable Redis degrades gracefully.

## What's deliberately out of scope

`conversion` event tracking (needs a real e-commerce webhook integration) and the rest of the
architecture doc's "Long Term Roadmap" (Project Builder, Quantity Calculators, ERP integration,
branch stock lookup, and more) — built so each is additive later, not a rewrite (architecture §15).

## Week 11 — Quantity Calculators

`engines/commerce_engine/quantity_calculator.py` reads coverage directly from a product's own
free-text `specifications` — no separate calculator config per product:

- An explicit `Coverage` spec, handling both **direct** phrasing ("Approx 60m²", "5.76m²/pack")
  and **inverse** phrasing ("Approx 10 tiles/m²" — units per area, not area per unit)
- Falls back to `Length × Width` for products with dimensions but no stated coverage
- 10% waste-factor allowance by default, configurable
- A clear, actionable error when specs genuinely don't have enough information (e.g. a joist with
  only Length and Cross-section) rather than guessing

`POST /widget/calculate-quantity` — API-key authed like every other widget route. 17 unit tests
cover every spec-format ambiguity plus the real seed catalogue's exact spec shapes.

**Scope note:** natural-language dimension extraction (a customer typing "I have a 4m by 3m deck"
directly into chat) is deferred — it needs LLM tool-calling infrastructure not yet built into the
LLM gateway. The calculator engine and API endpoint are real and fully tested now; widget-side UI
(a calculate form on product cards) is the natural next increment.

## Week 12 — Quote Builder

Turns a Basket Builder basket (Week 10) into a formal, reference-numbered quote.

- `quotes` / `quote_items` tables (migration 0011), RLS-protected like every other tenant table.
- **Quotes are snapshots, not live views.** `quote_items` copies sku/name/price at creation time
  instead of joining to `products` — a customer quoted £10.00 still sees £10.00 if the merchant
  later reprices the product, and the quote still reads correctly if the product is deleted
  (`product_id` is `ON DELETE SET NULL`). This is the deliberate opposite of `basket_items`, which
  joins live so a basket never shows stale prices. Both behaviours are covered by tests.
- Short, phone-friendly reference numbers (`Q-4K7XJ9`), using an alphabet without ambiguous
  characters (no O/0/I/1), unique per merchant with a collision-retry loop backed by a DB
  constraint.
- 14-day validity by default; `is_expired` is computed from `expires_at` on read.
- Refuses to quote an empty basket, or a basket containing any item with no price set (a quote
  with a blank price isn't a quote).
- `POST /widget/quotes` (create from the session's basket) and `GET /widget/quotes/{reference}`,
  API-key authed with the same tenancy/rate-limit/error-envelope behaviour as every other widget
  route.
- 7 integration tests against real Postgres: snapshot correctness, price freezing, product
  deletion survival, empty/unpriced rejection, expiry, and cross-merchant isolation.

**Not in this week:** widget UI for requesting a quote, emailing/PDF export of a quote, and a
staff-side dashboard view for looking a quote up by reference — the data model and API are in
place for each.
