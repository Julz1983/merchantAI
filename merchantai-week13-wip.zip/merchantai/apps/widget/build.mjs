import * as esbuild from "esbuild";

const watch = process.argv.includes("--watch");

const options = {
  entryPoints: ["src/init.ts"],
  bundle: true,
  outfile: "build/merchantai.js",
  format: "iife",
  globalName: "__MerchantAIBundle",
  target: "es2020",
  minify: !watch,
  sourcemap: watch ? "inline" : false,
  logLevel: "info",
};

if (watch) {
  const ctx = await esbuild.context(options);
  await ctx.watch();
  console.log("Watching for changes...");
} else {
  const result = await esbuild.build({ ...options, metafile: true });
  const outputPath = Object.keys(result.metafile.outputs)[0];
  const sizeBytes = result.metafile.outputs[outputPath].bytes;
  console.log(`Built ${outputPath} — ${(sizeBytes / 1024).toFixed(1)}kb`);
  if (sizeBytes > 50 * 1024) {
    console.warn(`WARNING: bundle exceeds the 50kb budget (architecture §7)`);
  }
}
