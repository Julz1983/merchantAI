// Loads the real built bundle (build/merchantai.js) into a jsdom window and
// drives it exactly as a browser would — clicking the launcher, typing into
// the input, reading the streamed response back out of the DOM. This is the
// strongest verification available short of a real browser: it proves the
// bundle actually executes (not just typechecks/builds) against the real
// running API, including Shadow DOM construction and SSE stream parsing.
import { readFileSync } from "node:fs";
import { JSDOM, VirtualConsole } from "jsdom";

const API_KEY = process.env.MERCHANTAI_TEST_API_KEY;
const BASE_URL = process.env.MERCHANTAI_TEST_BASE_URL || "http://127.0.0.1:8123/api/v1";

if (!API_KEY) {
  console.error("MERCHANTAI_TEST_API_KEY env var is required");
  process.exit(1);
}

const bundleCode = readFileSync("build/merchantai.js", "utf-8");

const virtualConsole = new VirtualConsole();
virtualConsole.sendTo(console, { omitJSDOMErrors: true });

const dom = new JSDOM("<!DOCTYPE html><html><body></body></html>", {
  url: "https://example-merchant-site.test/",
  runScripts: "outside-only",
  pretendToBeVisual: true,
  virtualConsole,
});

const { window } = dom;
window.fetch = fetch; // Node 22's native fetch
window.TextDecoder = TextDecoder; // jsdom doesn't polyfill this standard Web API onto window

let failed = false;
function assert(condition, message) {
  if (!condition) {
    console.error(`FAIL: ${message}`);
    failed = true;
  } else {
    console.log(`PASS: ${message}`);
  }
}

dom.window.eval(bundleCode);
assert(typeof window.MerchantAI?.init === "function", "window.MerchantAI.init is defined after loading the bundle");

window.MerchantAI.init({ apiKey: API_KEY, baseUrl: BASE_URL });

// mount() is async (awaits /widget/config) — give it a moment to complete.
await new Promise((r) => setTimeout(r, 1000));

const host = window.document.getElementById("merchantai-widget-host");
assert(host !== null, "widget host element was appended to document.body");
assert(host.shadowRoot !== null, "widget uses a Shadow DOM root (site CSS isolation)");

const launcher = host.shadowRoot.querySelector(".mai-launcher");
assert(launcher !== null, "launcher button rendered");

const panel = host.shadowRoot.querySelector(".mai-panel");
assert(panel !== null, "chat panel rendered");
assert(!panel.classList.contains("mai-open"), "chat panel starts closed");

launcher.click();
assert(panel.classList.contains("mai-open"), "clicking the launcher opens the panel");

const messagesBefore = host.shadowRoot.querySelectorAll(".mai-bubble").length;
assert(messagesBefore === 1, `greeting message shown on first open (found ${messagesBefore})`);

const input = host.shadowRoot.querySelector(".mai-input");
const sendBtn = host.shadowRoot.querySelector(".mai-send");
input.value = "I want to build a raised deck, what do I need?";
sendBtn.click();

// Wait for the streamed response to complete.
await new Promise((r) => setTimeout(r, 3000));

const bubbles = host.shadowRoot.querySelectorAll(".mai-bubble");
assert(bubbles.length === 3, `user + assistant bubbles present after sending (found ${bubbles.length})`);
assert(bubbles[1].textContent.trim().length > 0, "user message bubble shows the typed text");
assert(bubbles[2].textContent.trim().length > 0, "assistant bubble received streamed text");

console.log("\n--- assistant reply ---");
console.log(bubbles[2].textContent);

const productCards = host.shadowRoot.querySelectorAll(".mai-product-card");
console.log(`\nproduct cards rendered: ${productCards.length}`);
for (const card of productCards) {
  console.log(" -", card.querySelector(".mai-product-name")?.textContent);
}

assert(productCards.length > 0, "at least one product card rendered from the grounded answer");

if (productCards.length > 0) {
  const firstCardInfo = productCards[0].querySelector(".mai-product-info");
  assert(firstCardInfo?.classList.contains("mai-clickable"), "product card info is clickable");

  // Click the product info (not the whole card, which now also contains a
  // separate "Add to list" button), firing trackClick() -> POST /widget/track-click.
  firstCardInfo.click();
  await new Promise((r) => setTimeout(r, 500)); // let the fire-and-forget fetch complete

  if (process.env.MERCHANTAI_TEST_JWT) {
    const eventsRes = await fetch(`${BASE_URL}/analytics/events?type=click&range=all`, {
      headers: { Authorization: `Bearer ${process.env.MERCHANTAI_TEST_JWT}` },
    });
    const eventsBody = await eventsRes.json();
    assert(eventsRes.ok && eventsBody.data.length > 0, `clicking a product card recorded a real 'click' analytics event (found ${eventsBody.data?.length ?? 0})`);
  } else {
    console.log("(skipping click-event verification — MERCHANTAI_TEST_JWT not set)");
  }

  // --- Basket Builder verification ---
  const basketBadge = host.shadowRoot.querySelector(".mai-basket-badge");
  assert(basketBadge.hidden, "basket badge starts hidden (empty basket)");

  const addBtn = productCards[0].querySelector(".mai-add-btn");
  assert(addBtn !== null, "product card has an 'Add to list' button");
  addBtn.click();
  await new Promise((r) => setTimeout(r, 800)); // let the addToBasket() fetch complete

  assert(addBtn.textContent.includes("Added"), "add button shows confirmation after adding");
  assert(!basketBadge.hidden && basketBadge.textContent === "1", `basket badge shows count 1 after adding (got '${basketBadge.textContent}', hidden=${basketBadge.hidden})`);

  if (process.env.MERCHANTAI_TEST_JWT) {
    const basketEventsRes = await fetch(`${BASE_URL}/analytics/events?type=basket_add&range=all`, {
      headers: { Authorization: `Bearer ${process.env.MERCHANTAI_TEST_JWT}` },
    });
    const basketEventsBody = await basketEventsRes.json();
    assert(basketEventsRes.ok && basketEventsBody.data.length > 0, `adding to basket recorded a real 'basket_add' analytics event (found ${basketEventsBody.data?.length ?? 0})`);
  }

  // Open the basket view via the header button.
  const basketBtn = host.shadowRoot.querySelector(".mai-basket-btn");
  const messagesEl = host.shadowRoot.querySelector(".mai-messages");
  const basketViewEl = host.shadowRoot.querySelector(".mai-basket-view");
  basketBtn.click();
  await new Promise((r) => setTimeout(r, 300));

  assert(!basketViewEl.hidden, "basket view is shown after clicking the basket button");
  assert(messagesEl.hidden, "chat messages are hidden while viewing the basket");

  const basketRows = basketViewEl.querySelectorAll(".mai-basket-row");
  assert(basketRows.length === 1, `basket view shows exactly the one added item (found ${basketRows.length})`);

  // Remove the item and confirm the view updates.
  const removeBtn = basketViewEl.querySelector(".mai-basket-remove");
  removeBtn.click();
  await new Promise((r) => setTimeout(r, 500));

  const rowsAfterRemove = basketViewEl.querySelectorAll(".mai-basket-row");
  assert(rowsAfterRemove.length === 0, "basket view is empty after removing the item");
  assert(basketBadge.hidden, "basket badge hides again once the basket is empty");
}

process.exit(failed ? 1 : 0);
