# MerchantAI Widget

Vanilla TypeScript, no framework runtime shipped — bundled to a single IIFE
(`build/merchantai.js`, ~9kb minified, well under the 50kb budget in
architecture §7) so it can be dropped into any website with one script tag.

## Build

```bash
npm install
npm run build       # outputs build/merchantai.js
npm run dev          # watch mode
npm run typecheck
```

## Embed

```html
<script src="https://cdn.merchantai.com/merchantai.js"></script>
<script>
  MerchantAI.init({ apiKey: "YOUR_WIDGET_API_KEY" });
</script>
```

Get a widget-scoped API key from the dashboard's API Keys page. See
`example/index.html` for a working static test page — open it in a browser
with the API running locally (`baseUrl` points at `http://localhost:8000/api/v1`).

## End-to-end test

`test-e2e.mjs` loads the real built bundle into a jsdom-simulated browser
and drives it exactly as a user would — clicking the launcher, sending a
message, reading the streamed response back out of the Shadow DOM — against
a real running API instance:

```bash
npm run build
MERCHANTAI_TEST_API_KEY=mai_live_xxx MERCHANTAI_TEST_BASE_URL=http://localhost:8000/api/v1 npm run test:e2e
```

This is stronger verification than a typecheck or a manual browser check:
it proves the actual bytes that ship (build/merchantai.js) execute
correctly, including Shadow DOM construction, SSE stream parsing, and
citation-backed product card rendering — not just that the TypeScript source
compiles.

## Design notes

- **Shadow DOM** isolates the widget from the host site's CSS in both
  directions — a merchant's site styles can't leak in, and the widget's
  styles can't leak out.
- **Resilience**: if `GET /widget/config` fails, the widget still renders
  with default branding rather than not rendering at all (architecture §7)
  — a merchant's site should never break because MerchantAI is down.
- **Streaming via fetch + ReadableStream, not EventSource**: the native
  `EventSource` API is GET-only and can't send a request body or the
  `X-API-Key` header this endpoint needs, so this uses the standard
  fetch-based workaround for POST-driven SSE.
- **Simulated token streaming**: the backend computes and citation-validates
  the full answer before streaming starts (see `routers/widget.py`'s module
  docstring for why — citations can't be validated before the full response
  exists), then streams the already-correct text back in word chunks for
  the perceived-latency UX benefit. The widget doesn't know or care that
  it's not "real" token-by-token generation — the event format is the same
  either way, which is what lets that implementation detail change later
  without touching this code.
