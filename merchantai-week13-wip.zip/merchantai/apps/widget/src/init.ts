import { MerchantAIWidget } from "./widget";
import type { MerchantAIConfig } from "./types";

const DEFAULT_BASE_URL = "https://api.merchantai.com/api/v1";

declare global {
  interface Window {
    MerchantAI: { init: (config: MerchantAIConfig) => void };
  }
}

function init(config: MerchantAIConfig): void {
  if (!config?.apiKey) {
    console.error("[MerchantAI] init() requires an apiKey.");
    return;
  }

  const start = () => {
    const widget = new MerchantAIWidget(config.apiKey, config.baseUrl || DEFAULT_BASE_URL);
    widget.mount().catch((err) => {
      // Resilience per architecture §7: a widget failure must never break
      // the host page. Log and stop, don't throw into the merchant's site.
      console.error("[MerchantAI] failed to load widget:", err);
    });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
}

window.MerchantAI = { init };
