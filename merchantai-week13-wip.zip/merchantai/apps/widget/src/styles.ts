export function buildStyles(): string {
  return `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, Roboto, sans-serif; }

    .mai-root {
      --mai-primary: var(--mai-brand-primary, #1B1F23);
      --mai-accent: var(--mai-brand-accent, #D9491F);
      position: fixed;
      bottom: 20px;
      z-index: 2147483000;
    }
    .mai-root.mai-right { right: 20px; }
    .mai-root.mai-left { left: 20px; }

    .mai-launcher {
      width: 56px; height: 56px; border-radius: 50%;
      background: var(--mai-primary);
      box-shadow: 0 4px 16px rgba(0,0,0,0.2);
      border: none; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: transform 0.15s ease;
    }
    .mai-launcher:hover { transform: scale(1.05); }
    .mai-launcher svg { width: 26px; height: 26px; }

    .mai-panel {
      position: absolute; bottom: 72px;
      width: 360px; max-width: calc(100vw - 40px);
      height: 520px; max-height: calc(100vh - 120px);
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.24);
      display: flex; flex-direction: column;
      overflow: hidden;
      opacity: 0; transform: translateY(8px) scale(0.98);
      pointer-events: none;
      transition: opacity 0.15s ease, transform 0.15s ease;
    }
    .mai-root.mai-right .mai-panel { right: 0; }
    .mai-root.mai-left .mai-panel { left: 0; }
    .mai-panel.mai-open { opacity: 1; transform: translateY(0) scale(1); pointer-events: auto; }

    .mai-header {
      background: var(--mai-primary); color: #fff;
      padding: 14px 16px; display: flex; align-items: center; justify-content: space-between;
      flex-shrink: 0;
    }
    .mai-header-title { font-size: 14px; font-weight: 600; }
    .mai-header-actions { display: flex; align-items: center; gap: 4px; }
    .mai-basket-btn {
      position: relative; background: none; border: none; color: #fff; opacity: 0.85;
      cursor: pointer; padding: 4px; display: flex; align-items: center;
    }
    .mai-basket-btn:hover { opacity: 1; }
    .mai-basket-btn svg { width: 19px; height: 19px; }
    .mai-basket-badge {
      position: absolute; top: -2px; right: -4px; background: var(--mai-accent); color: #fff;
      font-size: 9px; font-weight: 700; line-height: 1; border-radius: 999px;
      min-width: 14px; height: 14px; display: flex; align-items: center; justify-content: center; padding: 0 3px;
    }
    .mai-close { background: none; border: none; color: #fff; opacity: 0.8; cursor: pointer; font-size: 18px; line-height: 1; padding: 4px; }
    .mai-close:hover { opacity: 1; }

    .mai-messages { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 10px; }

    .mai-bubble { max-width: 85%; padding: 9px 12px; font-size: 13.5px; line-height: 1.4; border-radius: 10px; white-space: pre-wrap; }
    .mai-bubble.mai-user { align-self: flex-end; background: var(--mai-primary); color: #fff; border-bottom-right-radius: 3px; }
    .mai-bubble.mai-assistant { align-self: flex-start; background: #F0F0EA; color: #191B1D; border-bottom-left-radius: 3px; }

    .mai-products { display: flex; flex-direction: column; gap: 6px; align-self: flex-start; max-width: 90%; }
    .mai-product-card {
      border: 1px solid #E0DED6; border-radius: 8px; padding: 8px 10px; font-size: 12.5px;
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
    }
    .mai-product-info.mai-clickable { cursor: pointer; flex: 1; min-width: 0; }
    .mai-product-name { font-weight: 600; color: #191B1D; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .mai-product-meta { color: #5B5F5A; font-size: 11px; margin-top: 2px; }
    .mai-add-btn {
      flex-shrink: 0; background: var(--mai-primary); color: #fff; border: none; border-radius: 6px;
      padding: 5px 9px; font-size: 11px; font-weight: 600; cursor: pointer; white-space: nowrap;
    }
    .mai-add-btn:disabled { opacity: 0.6; cursor: default; }

    .mai-basket-view { flex: 1; overflow-y: auto; padding: 14px; }
    .mai-basket-empty { color: #5B5F5A; font-size: 13px; text-align: center; padding: 24px 8px; }
    .mai-basket-list { display: flex; flex-direction: column; gap: 8px; }
    .mai-basket-row {
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
      border-bottom: 1px solid #EEEDE7; padding-bottom: 8px;
    }
    .mai-basket-remove {
      flex-shrink: 0; background: none; border: 1px solid #DDD9D0; border-radius: 6px; width: 24px; height: 24px;
      color: #5B5F5A; cursor: pointer; font-size: 15px; line-height: 1;
    }
    .mai-basket-remove:hover { border-color: var(--mai-primary); color: var(--mai-primary); }
    .mai-basket-subtotal { margin-top: 14px; padding-top: 10px; border-top: 1px solid #EEEDE7; font-weight: 700; font-size: 13.5px; text-align: right; }

    .mai-input-row { border-top: 1px solid #EEEDE7; padding: 10px; display: flex; gap: 8px; flex-shrink: 0; }
    .mai-input {
      flex: 1; border: 1px solid #DDD9D0; border-radius: 8px; padding: 8px 10px;
      font-size: 13.5px; outline: none;
    }
    .mai-input:focus { border-color: var(--mai-primary); }
    .mai-send {
      background: var(--mai-primary); color: #fff; border: none; border-radius: 8px;
      padding: 0 14px; font-size: 13px; font-weight: 600; cursor: pointer;
    }
    .mai-send:disabled { opacity: 0.5; cursor: default; }

    .mai-typing { display: inline-flex; gap: 3px; align-items: center; padding: 2px 4px; }
    .mai-typing span { width: 5px; height: 5px; border-radius: 50%; background: #999; animation: mai-bounce 1s infinite ease-in-out; }
    .mai-typing span:nth-child(2) { animation-delay: 0.15s; }
    .mai-typing span:nth-child(3) { animation-delay: 0.3s; }
    @keyframes mai-bounce { 0%, 60%, 100% { transform: translateY(0); opacity: 0.5; } 30% { transform: translateY(-3px); opacity: 1; } }
  `;
}
