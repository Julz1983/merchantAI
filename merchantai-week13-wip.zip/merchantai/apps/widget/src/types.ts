export interface MerchantAIConfig {
  apiKey: string;
  baseUrl?: string;
}

export interface WidgetConfigResponse {
  merchant_name: string;
  logo_url: string | null;
  brand_colors: { primary?: string; secondary?: string; accent?: string };
  launcher_position: "bottom-right" | "bottom-left";
  greeting_message: string;
}

export interface SuggestedProduct {
  id: string;
  sku: string;
  name: string;
  price: number | null;
  stock_status: string;
  reason: string;
}

export interface StreamDoneEvent {
  type: "done";
  citations: { product_ids: string[]; document_chunk_ids: string[] };
  suggested_products: SuggestedProduct[];
}

export interface StreamTokenEvent {
  type: "token";
  text: string;
}

export type StreamEvent = StreamTokenEvent | StreamDoneEvent;

export interface BasketItem {
  id: string;
  product_id: string;
  sku: string;
  name: string;
  price: number | null;
  stock_status: string;
  quantity: number;
  line_total: number | null;
  source: string;
}

export interface Basket {
  id: string;
  items: BasketItem[];
  item_count: number;
  subtotal: number | null;
}
