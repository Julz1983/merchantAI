import type { Basket, StreamEvent, WidgetConfigResponse } from "./types";

const DEFAULT_GREETING = "Hi! How can I help you find what you need?";

// Resilience (architecture §7): if /widget/config fails, the widget still
// renders with sane defaults rather than not rendering at all — a
// merchant's site should never break because MerchantAI is down.
export const FALLBACK_CONFIG: WidgetConfigResponse = {
  merchant_name: "Assistant",
  logo_url: null,
  brand_colors: { primary: "#1B1F23", secondary: "#2B4A63", accent: "#D9491F" },
  launcher_position: "bottom-right",
  greeting_message: DEFAULT_GREETING,
};

export class MerchantAIClient {
  constructor(private readonly apiKey: string, private readonly baseUrl: string) {}

  async fetchConfig(): Promise<WidgetConfigResponse> {
    try {
      const res = await fetch(`${this.baseUrl}/widget/config`, {
        headers: { "X-API-Key": this.apiKey },
      });
      if (!res.ok) throw new Error(`config fetch failed: ${res.status}`);
      const body = await res.json();
      if (!body.data) throw new Error("config response had no data");
      return body.data as WidgetConfigResponse;
    } catch {
      return FALLBACK_CONFIG;
    }
  }

  /**
   * Consumes the SSE stream via fetch + a ReadableStream reader, not the
   * native EventSource API — EventSource is GET-only and can't send a
   * request body or custom headers (X-API-Key), both of which this endpoint
   * needs. This is the standard workaround for POST-based SSE.
   */
  async streamChat(sessionId: string, message: string, onEvent: (event: StreamEvent) => void): Promise<void> {
    const res = await fetch(`${this.baseUrl}/widget/chat/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-API-Key": this.apiKey },
      body: JSON.stringify({ session_id: sessionId, message }),
    });

    if (!res.ok || !res.body) {
      throw new Error(`chat request failed: ${res.status}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n\n");
      buffer = lines.pop() ?? ""; // keep the last (possibly incomplete) chunk for next read

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const jsonStr = trimmed.slice("data:".length).trim();
        try {
          onEvent(JSON.parse(jsonStr) as StreamEvent);
        } catch {
          // malformed SSE chunk — skip it rather than breaking the whole stream
        }
      }
    }
  }

  async trackClick(sessionId: string, productId: string, sku: string): Promise<void> {
    try {
      await fetch(`${this.baseUrl}/widget/track-click`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-API-Key": this.apiKey },
        body: JSON.stringify({ session_id: sessionId, product_id: productId, sku }),
      });
    } catch {
      // Analytics tracking must never break the chat experience — a failed
      // click-tracking call is silently dropped, not surfaced to the user.
    }
  }

  async getBasket(sessionId: string): Promise<Basket | null> {
    try {
      const res = await fetch(`${this.baseUrl}/widget/basket?session_id=${encodeURIComponent(sessionId)}`, {
        headers: { "X-API-Key": this.apiKey },
      });
      if (!res.ok) return null;
      const body = await res.json();
      return body.data as Basket;
    } catch {
      return null;
    }
  }

  async addToBasket(sessionId: string, productId: string, quantity = 1, source: "manual" | "assistant" = "manual"): Promise<Basket | null> {
    try {
      const res = await fetch(`${this.baseUrl}/widget/basket/items`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-API-Key": this.apiKey },
        body: JSON.stringify({ session_id: sessionId, product_id: productId, quantity, source }),
      });
      if (!res.ok) return null;
      const body = await res.json();
      return body.data as Basket;
    } catch {
      return null;
    }
  }

  async removeFromBasket(sessionId: string, itemId: string): Promise<Basket | null> {
    try {
      const res = await fetch(`${this.baseUrl}/widget/basket/items/${itemId}?session_id=${encodeURIComponent(sessionId)}`, {
        method: "DELETE",
        headers: { "X-API-Key": this.apiKey },
      });
      if (!res.ok) return null;
      const body = await res.json();
      return body.data as Basket;
    } catch {
      return null;
    }
  }
}
