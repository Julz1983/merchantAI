import { MerchantAIClient } from "./api";
import { buildStyles } from "./styles";
import type { Basket, StreamEvent, SuggestedProduct, WidgetConfigResponse } from "./types";

const LAUNCHER_ICON = `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M4 4h16v12H7l-3 3V4z" stroke="white" stroke-width="1.8" stroke-linejoin="round"/>
</svg>`;

const BASKET_ICON = `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M5 8h14l-1.2 10.2a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8L5 8z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M9 8V6a3 3 0 0 1 6 0v2" stroke="currentColor" stroke-width="1.6"/>
</svg>`;

const SESSION_STORAGE_KEY = "merchantai_session_id";

function getOrCreateSessionId(): string {
  try {
    const existing = window.sessionStorage.getItem(SESSION_STORAGE_KEY);
    if (existing) return existing;
    const fresh = `web-${crypto.randomUUID()}`;
    window.sessionStorage.setItem(SESSION_STORAGE_KEY, fresh);
    return fresh;
  } catch {
    // sessionStorage can throw in restrictive iframe/privacy contexts —
    // fall back to an in-memory id rather than breaking the widget.
    return `web-${Math.random().toString(36).slice(2)}`;
  }
}

export class MerchantAIWidget {
  private readonly client: MerchantAIClient;
  private readonly sessionId: string;
  private config: WidgetConfigResponse | null = null;
  private shadowRoot!: ShadowRoot;
  private panelEl!: HTMLDivElement;
  private messagesEl!: HTMLDivElement;
  private inputEl!: HTMLInputElement;
  private sendBtn!: HTMLButtonElement;
  private basketBtn!: HTMLButtonElement;
  private basketBadge!: HTMLSpanElement;
  private basketViewEl!: HTMLDivElement;
  private isOpen = false;
  private hasGreeted = false;
  private basket: Basket | null = null;

  constructor(apiKey: string, baseUrl: string) {
    this.client = new MerchantAIClient(apiKey, baseUrl);
    this.sessionId = getOrCreateSessionId();
  }

  async mount(): Promise<void> {
    this.config = await this.client.fetchConfig();

    const host = document.createElement("div");
    host.id = "merchantai-widget-host";
    document.body.appendChild(host);
    this.shadowRoot = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = buildStyles();
    this.shadowRoot.appendChild(style);

    this.render();
  }

  private render(): void {
    const cfg = this.config!;
    const root = document.createElement("div");
    root.className = `mai-root ${cfg.launcher_position === "bottom-left" ? "mai-left" : "mai-right"}`;
    root.style.setProperty("--mai-brand-primary", cfg.brand_colors.primary || "#1B1F23");
    root.style.setProperty("--mai-brand-accent", cfg.brand_colors.accent || "#D9491F");

    const launcher = document.createElement("button");
    launcher.className = "mai-launcher";
    launcher.setAttribute("aria-label", `Chat with ${cfg.merchant_name}`);
    launcher.innerHTML = LAUNCHER_ICON;
    launcher.addEventListener("click", () => this.toggle());

    this.panelEl = document.createElement("div");
    this.panelEl.className = "mai-panel";
    this.panelEl.innerHTML = this.panelSkeleton(cfg);

    root.appendChild(this.panelEl);
    root.appendChild(launcher);
    this.shadowRoot.appendChild(root);

    this.messagesEl = this.panelEl.querySelector(".mai-messages")!;
    this.inputEl = this.panelEl.querySelector(".mai-input")!;
    this.sendBtn = this.panelEl.querySelector(".mai-send")!;
    this.basketBtn = this.panelEl.querySelector(".mai-basket-btn")!;
    this.basketBadge = this.panelEl.querySelector(".mai-basket-badge")!;
    this.basketViewEl = this.panelEl.querySelector(".mai-basket-view")!;
    const closeBtn = this.panelEl.querySelector(".mai-close")!;

    closeBtn.addEventListener("click", () => this.toggle());
    this.sendBtn.addEventListener("click", () => this.handleSend());
    this.inputEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") this.handleSend();
    });
    this.basketBtn.addEventListener("click", () => this.toggleBasketView());

    // Refresh the badge on mount (not just after an add) — a returning
    // visitor with items already in their session's basket should see the
    // count immediately, not only after their next add.
    void this.refreshBasket();
  }

  private panelSkeleton(cfg: WidgetConfigResponse): string {
    return `
      <div class="mai-header">
        <span class="mai-header-title">${escapeHtml(cfg.merchant_name)}</span>
        <div class="mai-header-actions">
          <button class="mai-basket-btn" aria-label="View your list">
            ${BASKET_ICON}
            <span class="mai-basket-badge" hidden>0</span>
          </button>
          <button class="mai-close" aria-label="Close chat">&times;</button>
        </div>
      </div>
      <div class="mai-messages"></div>
      <div class="mai-basket-view" hidden></div>
      <div class="mai-input-row">
        <input class="mai-input" type="text" placeholder="Ask a question…" />
        <button class="mai-send">Send</button>
      </div>
    `;
  }

  private toggle(): void {
    this.isOpen = !this.isOpen;
    this.panelEl.classList.toggle("mai-open", this.isOpen);
    if (this.isOpen && !this.hasGreeted) {
      this.hasGreeted = true;
      this.addBubble("assistant", this.config!.greeting_message);
    }
  }

  private addBubble(role: "user" | "assistant", text: string): HTMLDivElement {
    const bubble = document.createElement("div");
    bubble.className = `mai-bubble mai-${role}`;
    bubble.textContent = text;
    this.messagesEl.appendChild(bubble);
    this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
    return bubble;
  }

  private addProductCards(products: SuggestedProduct[]): void {
    if (products.length === 0) return;
    const container = document.createElement("div");
    container.className = "mai-products";
    for (const p of products) {
      const card = document.createElement("div");
      card.className = "mai-product-card";
      const priceStr = p.price != null ? `£${p.price.toFixed(2)}` : "";

      const info = document.createElement("div");
      info.className = "mai-product-info mai-clickable";
      info.innerHTML = `<div class="mai-product-name">${escapeHtml(p.name)}</div><div class="mai-product-meta">${escapeHtml(p.sku)} ${priceStr ? "· " + priceStr : ""}</div>`;
      info.addEventListener("click", () => {
        void this.client.trackClick(this.sessionId, p.id, p.sku);
      });

      const addBtn = document.createElement("button");
      addBtn.className = "mai-add-btn";
      addBtn.textContent = "Add to list";
      addBtn.addEventListener("click", async () => {
        addBtn.disabled = true;
        addBtn.textContent = "Added ✓";
        const basket = await this.client.addToBasket(this.sessionId, p.id, 1, "assistant");
        if (basket) {
          this.basket = basket;
          this.updateBasketBadge();
        } else {
          addBtn.disabled = false;
          addBtn.textContent = "Add to list";
        }
      });

      card.appendChild(info);
      card.appendChild(addBtn);
      container.appendChild(card);
    }
    this.messagesEl.appendChild(container);
    this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
  }

  private async refreshBasket(): Promise<void> {
    this.basket = await this.client.getBasket(this.sessionId);
    this.updateBasketBadge();
  }

  private updateBasketBadge(): void {
    const count = this.basket?.item_count ?? 0;
    this.basketBadge.textContent = String(count);
    this.basketBadge.hidden = count === 0;
  }

  private toggleBasketView(): void {
    const showing = !this.basketViewEl.hidden;
    if (showing) {
      this.basketViewEl.hidden = true;
      this.messagesEl.hidden = false;
      this.inputEl.parentElement!.hidden = false;
    } else {
      this.renderBasketView();
      this.basketViewEl.hidden = false;
      this.messagesEl.hidden = true;
      this.inputEl.parentElement!.hidden = true;
    }
  }

  private renderBasketView(): void {
    const basket = this.basket;
    if (!basket || basket.items.length === 0) {
      this.basketViewEl.innerHTML = `<div class="mai-basket-empty">Your list is empty. Ask the assistant a question to get product suggestions you can add.</div>`;
      return;
    }

    const rows = basket.items.map((item) => `
      <div class="mai-basket-row" data-item-id="${item.id}">
        <div>
          <div class="mai-product-name">${escapeHtml(item.name)}</div>
          <div class="mai-product-meta">${escapeHtml(item.sku)} · qty ${item.quantity}${item.price != null ? ` · £${item.line_total!.toFixed(2)}` : ""}</div>
        </div>
        <button class="mai-basket-remove" aria-label="Remove ${escapeHtml(item.name)}">&times;</button>
      </div>
    `).join("");

    const subtotalRow = basket.subtotal != null
      ? `<div class="mai-basket-subtotal">Subtotal: £${basket.subtotal.toFixed(2)}</div>`
      : "";

    this.basketViewEl.innerHTML = `<div class="mai-basket-list">${rows}</div>${subtotalRow}`;

    this.basketViewEl.querySelectorAll<HTMLButtonElement>(".mai-basket-remove").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const row = btn.closest<HTMLElement>(".mai-basket-row")!;
        const itemId = row.dataset.itemId!;
        btn.disabled = true;
        const updated = await this.client.removeFromBasket(this.sessionId, itemId);
        if (updated) {
          this.basket = updated;
          this.updateBasketBadge();
          this.renderBasketView();
        } else {
          btn.disabled = false;
        }
      });
    });
  }

  private async handleSend(): Promise<void> {
    const message = this.inputEl.value.trim();
    if (!message) return;

    this.inputEl.value = "";
    this.inputEl.disabled = true;
    this.sendBtn.disabled = true;
    this.addBubble("user", message);

    const assistantBubble = this.addBubble("assistant", "");
    assistantBubble.innerHTML = `<span class="mai-typing"><span></span><span></span><span></span></span>`;
    let firstToken = true;
    let fullText = "";

    try {
      await this.client.streamChat(this.sessionId, message, (event: StreamEvent) => {
        if (event.type === "token") {
          if (firstToken) {
            assistantBubble.textContent = "";
            firstToken = false;
          }
          fullText += event.text;
          assistantBubble.textContent = fullText;
          this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
        } else if (event.type === "done") {
          this.addProductCards(event.suggested_products);
        }
      });
    } catch (err) {
      console.error("[MerchantAI] chat request failed:", err);
      assistantBubble.textContent = "Sorry, something went wrong. Please try again in a moment.";
    } finally {
      this.inputEl.disabled = false;
      this.sendBtn.disabled = false;
      this.inputEl.focus();
    }
  }
}

function escapeHtml(text: string): string {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}
