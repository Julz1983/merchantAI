"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api, type KGNeighborhood, type Product } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

export default function ProductDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [neighborhood, setNeighborhood] = useState<KGNeighborhood | null>(null);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) return;
    api
      .getProduct(token, params.id)
      .then(async (p) => {
        setProduct(p);
        const node = await api.getNodeByRef(token, "PRODUCT", p.id);
        if (node) {
          const nb = await api.getNodeNeighborhood(token, node.id, 1);
          setNeighborhood(nb);
        }
      })
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load product"))
      .finally(() => setLoading(false));
  }, [params.id]);

  if (loading) return <p className="font-mono text-sm text-ink-muted">Loading…</p>;
  if (error || !product) {
    return (
      <div>
        <p className="border-l-2 border-signal bg-signal/5 px-3 py-2 text-sm text-signal">{error ?? "Product not found"}</p>
        <button onClick={() => router.push("/products")} className="mt-4 text-sm text-steel hover:underline">
          ← Back to products
        </button>
      </div>
    );
  }

  return (
    <div>
      <Link href="/products" className="text-sm text-ink-muted hover:text-steel">← Products</Link>

      <div className="mt-3 flex items-start justify-between">
        <div>
          <p className="font-mono text-xs uppercase tracking-wider text-ink-muted">{product.sku}</p>
          <h1 className="mt-1 font-display text-2xl font-bold">{product.name}</h1>
        </div>
        {product.price != null && (
          <p className="font-mono text-2xl font-bold">{product.currency} {product.price.toFixed(2)}</p>
        )}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {product.description && (
            <div className="border border-line bg-white p-5">
              <p className="mb-2 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Description</p>
              <p className="text-sm leading-relaxed">{product.description}</p>
            </div>
          )}

          {Object.keys(product.specifications).length > 0 && (
            <div className="border border-line bg-white p-5">
              <p className="mb-3 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Specifications</p>
              <table className="w-full text-sm">
                <tbody>
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <tr key={key} className="border-b border-line last:border-0">
                      <td className="py-2 pr-4 text-ink-muted">{key}</td>
                      <td className="py-2 font-mono">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {Object.keys(product.attributes).length > 0 && (
            <div className="border border-line bg-white p-5">
              <p className="mb-3 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Attributes</p>
              <div className="flex flex-wrap gap-2">
                {Object.entries(product.attributes).map(([key, value]) => (
                  <span key={key} className="border border-line bg-paper px-2 py-1 text-xs">
                    {key}: <span className="font-medium">{value}</span>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="border border-line bg-white p-5">
            <p className="mb-3 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Details</p>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-ink-muted">Category</dt>
                <dd className="font-medium">{product.category_name ?? "—"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ink-muted">Brand</dt>
                <dd className="font-medium">{product.brand_name ?? "—"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ink-muted">Stock status</dt>
                <dd className="font-medium">{product.stock_status.replace("_", " ")}</dd>
              </div>
            </dl>
          </div>

          {product.product_url && (
            <a
              href={product.product_url}
              target="_blank"
              rel="noreferrer"
              className="block border border-line bg-white p-5 text-sm text-steel hover:border-steel"
            >
              View on storefront ↗
            </a>
          )}

          {neighborhood && neighborhood.edges.filter((e) => e.relationship_type !== "CATEGORY" && e.relationship_type !== "BRAND").length > 0 && (
            <div className="border border-line bg-white p-5">
              <p className="mb-3 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Related products</p>
              <ul className="space-y-2">
                {neighborhood.edges
                  .filter((e) => e.relationship_type !== "CATEGORY" && e.relationship_type !== "BRAND")
                  .map((e) => {
                    const otherId = e.source_node_id === neighborhood.nodes.find((n) => n.ref_id === product.id)?.id ? e.target_node_id : e.source_node_id;
                    const other = neighborhood.nodes.find((n) => n.id === otherId);
                    if (!other) return null;
                    return (
                      <li key={e.id} className="flex items-center justify-between text-sm">
                        <span>{other.label}</span>
                        <span className="font-mono text-[10px] uppercase tracking-wider text-ink-muted">{e.relationship_type}</span>
                      </li>
                    );
                  })}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
