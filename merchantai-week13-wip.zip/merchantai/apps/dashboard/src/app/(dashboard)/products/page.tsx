"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api, type Brand, type Category, type Product } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

const STOCK_LABELS: Record<string, { label: string; className: string }> = {
  in_stock: { label: "In stock", className: "text-success" },
  out_of_stock: { label: "Out of stock", className: "text-signal" },
  unknown: { label: "Unknown", className: "text-ink-muted" },
};

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [loading, setLoading] = useState(true);

  const pageSize = 25;

  useEffect(() => {
    const token = getAccessToken();
    if (!token) return;
    api.listCategories(token).then(setCategories).catch(() => {});
    api.listBrands(token).then(setBrands).catch(() => {});
  }, []);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) return;
    setLoading(true);
    api
      .listProducts(token, { page, page_size: pageSize, search: search || undefined, category_id: categoryId || undefined, brand_id: brandId || undefined })
      .then((res) => {
        setProducts(res.items);
        setTotal(res.total);
      })
      .finally(() => setLoading(false));
  }, [page, search, categoryId, brandId]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">Products</h1>
          <p className="mt-1 text-sm text-ink-muted">{total} product{total === 1 ? "" : "s"} in your catalogue</p>
        </div>
        <Link
          href="/products/import"
          className="bg-ink px-4 py-2.5 text-sm font-medium text-paper transition hover:bg-steel"
        >
          Import products
        </Link>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <input
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          placeholder="Search by name or SKU…"
          className="w-64 border border-line bg-white px-3 py-2 text-sm focus:border-steel focus:outline-none focus:ring-1 focus:ring-steel"
        />
        <select
          value={categoryId}
          onChange={(e) => { setCategoryId(e.target.value); setPage(1); }}
          className="border border-line bg-white px-3 py-2 text-sm focus:border-steel focus:outline-none"
        >
          <option value="">All categories</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select
          value={brandId}
          onChange={(e) => { setBrandId(e.target.value); setPage(1); }}
          className="border border-line bg-white px-3 py-2 text-sm focus:border-steel focus:outline-none"
        >
          <option value="">All brands</option>
          {brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
      </div>

      <div className="mt-4 border border-line bg-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-paper font-mono text-[11px] uppercase tracking-wider text-ink-muted">
              <th className="px-4 py-3 font-medium">SKU</th>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Brand</th>
              <th className="px-4 py-3 font-medium">Price</th>
              <th className="px-4 py-3 font-medium">Stock</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-ink-muted">Loading…</td></tr>
            ) : products.length === 0 ? (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-ink-muted">No products yet — try importing a catalogue.</td></tr>
            ) : (
              products.map((p) => {
                const stock = STOCK_LABELS[p.stock_status] ?? STOCK_LABELS.unknown;
                return (
                  <tr key={p.id} className="border-b border-line last:border-0 hover:bg-paper">
                    <td className="px-4 py-3 font-mono text-xs text-ink-muted">
                      <Link href={`/products/${p.id}`} className="hover:text-signal">{p.sku}</Link>
                    </td>
                    <td className="px-4 py-3">
                      <Link href={`/products/${p.id}`} className="font-medium hover:text-signal">{p.name}</Link>
                    </td>
                    <td className="px-4 py-3 text-ink-muted">{p.category_name ?? "—"}</td>
                    <td className="px-4 py-3 text-ink-muted">{p.brand_name ?? "—"}</td>
                    <td className="px-4 py-3 font-mono">{p.price != null ? `${p.currency} ${p.price.toFixed(2)}` : "—"}</td>
                    <td className={`px-4 py-3 text-xs font-medium ${stock.className}`}>{stock.label}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-center gap-2">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="border border-line px-3 py-1.5 text-xs font-medium text-ink-muted disabled:opacity-40 hover:border-steel hover:text-steel"
          >
            Previous
          </button>
          <span className="font-mono text-xs text-ink-muted">Page {page} of {totalPages}</span>
          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
            className="border border-line px-3 py-1.5 text-xs font-medium text-ink-muted disabled:opacity-40 hover:border-steel hover:text-steel"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
