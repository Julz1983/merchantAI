"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, type MeResponse } from "@/lib/api";
import { clearTokens, getAccessToken } from "@/lib/auth";
import { Sidebar } from "@/components/Sidebar";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [me, setMe] = useState<MeResponse | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) {
      router.push("/login");
      return;
    }
    api
      .me(token)
      .then(setMe)
      .catch(() => {
        clearTokens();
        router.push("/login");
      })
      .finally(() => setLoading(false));
  }, [router]);

  if (loading || !me) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="font-mono text-sm text-ink-muted">Loading…</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar merchantName={me.merchant_name} />
      <div className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-line bg-white px-6 py-4">
          <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">
            {me.merchant_name}
          </p>
          <div className="flex items-center gap-3">
            <span className="text-sm text-ink-muted">{me.email}</span>
            <button
              onClick={() => {
                clearTokens();
                router.push("/login");
              }}
              className="border border-line px-3 py-1.5 text-xs font-medium text-ink-muted transition hover:border-signal hover:text-signal"
            >
              Sign out
            </button>
          </div>
        </header>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}
