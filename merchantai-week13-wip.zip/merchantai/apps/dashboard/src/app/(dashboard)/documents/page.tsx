"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, type DocumentSearchResult, type MerchantDocument } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

const DOC_TYPES = [
  { value: "installation_guide", label: "Installation guide" },
  { value: "technical_sheet", label: "Technical sheet" },
  { value: "manual", label: "Manufacturer manual" },
  { value: "faq", label: "FAQ" },
  { value: "other", label: "Other" },
];

const STATUS_STYLES: Record<string, string> = {
  processing: "text-brass",
  ready: "text-success",
  failed: "text-signal",
};

export default function DocumentsPage() {
  const [documents, setDocuments] = useState<MerchantDocument[]>([]);
  const [uploading, setUploading] = useState(false);
  const [docType, setDocType] = useState("installation_guide");
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState<DocumentSearchResult[] | null>(null);
  const [searching, setSearching] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(() => {
    const token = getAccessToken();
    if (!token) return;
    api.listDocuments(token).then(setDocuments).catch(() => {});
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Poll while any document is still processing — same pattern as the
  // import job progress bar, just simpler (no row-level progress to show).
  useEffect(() => {
    const hasProcessing = documents.some((d) => d.status === "processing");
    if (!hasProcessing) return;
    const interval = setInterval(refresh, 1500);
    return () => clearInterval(interval);
  }, [documents, refresh]);

  async function handleFile(file: File) {
    const token = getAccessToken();
    if (!token) return;
    setError(null);
    setUploading(true);
    try {
      await api.uploadDocument(token, file, file.name, docType);
      refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) handleFile(dropped);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [docType]);

  async function handleDelete(id: string) {
    const token = getAccessToken();
    if (!token) return;
    await api.deleteDocument(token, id);
    refresh();
  }

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    const token = getAccessToken();
    if (!token || !query.trim()) return;
    setSearching(true);
    try {
      const results = await api.searchDocuments(token, query);
      setSearchResults(results);
    } finally {
      setSearching(false);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Documents</h1>
      <p className="mt-1 text-sm text-ink-muted">
        Installation guides, technical sheets, and manuals — extracted, chunked, and embedded for search automatically.
      </p>

      {error && <p className="mt-4 border-l-2 border-signal bg-signal/5 px-3 py-2 text-sm text-signal">{error}</p>}

      <div className="mt-6 flex items-center gap-3">
        <select
          value={docType}
          onChange={(e) => setDocType(e.target.value)}
          className="border border-line bg-white px-3 py-2 text-sm focus:border-steel focus:outline-none"
        >
          {DOC_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
        </select>
      </div>

      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
        onClick={() => fileInputRef.current?.click()}
        className="mt-3 flex cursor-pointer flex-col items-center justify-center border-2 border-dashed border-line bg-white px-6 py-10 text-center transition hover:border-steel"
      >
        <div className="mb-2 h-8 w-8 bg-signal spec-corner" />
        <p className="text-sm font-medium">{uploading ? "Uploading…" : "Drop a PDF, Word doc, or text file here"}</p>
        <p className="mt-1 text-xs text-ink-muted">or click to browse</p>
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.docx,.txt"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
      </div>

      <div className="mt-6 border border-line bg-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-paper font-mono text-[11px] uppercase tracking-wider text-ink-muted">
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Type</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Chunks</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {documents.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-8 text-center text-ink-muted">No documents yet.</td></tr>
            ) : (
              documents.map((d) => (
                <tr key={d.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 font-medium">{d.title}</td>
                  <td className="px-4 py-3 text-ink-muted">{d.doc_type.replace("_", " ")}</td>
                  <td className={`px-4 py-3 text-xs font-medium ${STATUS_STYLES[d.status]}`}>
                    {d.status === "failed" ? (d.error_message ?? "failed") : d.status}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-ink-muted">{d.chunk_count}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(d.id)} className="text-xs text-ink-muted hover:text-signal">
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-8 border border-line bg-white p-5">
        <p className="mb-1 font-mono text-[11px] uppercase tracking-wider text-ink-muted">Search test</p>
        <p className="mb-3 text-xs text-ink-muted">Try a question a customer might ask, to see which document chunks would be retrieved.</p>
        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. how do I install hidden fixing clips?"
            className="flex-1 border border-line bg-paper px-3 py-2 text-sm focus:border-steel focus:outline-none focus:ring-1 focus:ring-steel"
          />
          <button
            type="submit"
            disabled={searching}
            className="bg-ink px-4 py-2 text-sm font-medium text-paper transition hover:bg-steel disabled:opacity-50"
          >
            {searching ? "Searching…" : "Search"}
          </button>
        </form>

        {searchResults && (
          <div className="mt-4 space-y-3">
            {searchResults.length === 0 ? (
              <p className="text-sm text-ink-muted">No matching chunks found.</p>
            ) : (
              searchResults.map((r) => (
                <div key={r.chunk_id} className="border-l-2 border-steel bg-paper p-3">
                  <p className="font-mono text-[10px] uppercase tracking-wider text-ink-muted">
                    {r.document_title} — page {r.page_number ?? "?"} — score {r.score.toFixed(3)}
                  </p>
                  <p className="mt-1 text-sm">{r.content.slice(0, 240)}{r.content.length > 240 ? "…" : ""}</p>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
