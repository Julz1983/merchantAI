"use client";

import { useEffect, useState } from "react";
import { api, type ApiKeyItem } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

export default function ApiKeysPage() {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [label, setLabel] = useState("");
  const [creating, setCreating] = useState(false);
  const [newKey, setNewKey] = useState<string | null>(null);

  function refresh() {
    const token = getAccessToken();
    if (!token) return;
    api.listApiKeys(token).then(setKeys).catch(() => {});
  }

  useEffect(refresh, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    const token = getAccessToken();
    if (!token || !label.trim()) return;
    setCreating(true);
    try {
      const created = await api.createApiKey(token, label.trim(), ["widget"]);
      setNewKey(created.plaintext_key);
      setLabel("");
      refresh();
    } finally {
      setCreating(false);
    }
  }

  async function handleRevoke(id: string) {
    const token = getAccessToken();
    if (!token) return;
    await api.revokeApiKey(token, id);
    refresh();
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">API Keys</h1>
      <p className="mt-1 text-sm text-ink-muted">Keys used by the website widget to talk to your assistant.</p>

      {newKey && (
        <div className="mt-4 spec-corner border border-brass bg-brass/10 p-4">
          <p className="text-xs font-medium uppercase tracking-wider text-ink-muted">
            Copy this key now — you won&apos;t be able to see it again
          </p>
          <code className="mt-2 block break-all bg-white px-3 py-2 text-sm">{newKey}</code>
          <button
            onClick={() => setNewKey(null)}
            className="mt-3 border border-line px-3 py-1.5 text-xs font-medium text-ink-muted hover:border-steel hover:text-steel"
          >
            Done, I&apos;ve saved it
          </button>
        </div>
      )}

      <form onSubmit={handleCreate} className="mt-6 flex gap-2">
        <input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="Key label, e.g. 'Main website'"
          className="flex-1 max-w-sm border border-line bg-white px-3 py-2 text-sm focus:border-steel focus:outline-none focus:ring-1 focus:ring-steel"
        />
        <button
          type="submit"
          disabled={creating}
          className="bg-ink px-4 py-2 text-sm font-medium text-paper transition hover:bg-steel disabled:opacity-50"
        >
          {creating ? "Creating…" : "Create key"}
        </button>
      </form>

      <div className="mt-6 border border-line bg-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-paper font-mono text-[11px] uppercase tracking-wider text-ink-muted">
              <th className="px-4 py-3 font-medium">Label</th>
              <th className="px-4 py-3 font-medium">Key</th>
              <th className="px-4 py-3 font-medium">Scopes</th>
              <th className="px-4 py-3 font-medium">Last used</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {keys.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-8 text-center text-ink-muted">No API keys yet.</td></tr>
            ) : (
              keys.map((k) => (
                <tr key={k.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 font-medium">{k.label}</td>
                  <td className="px-4 py-3 font-mono text-xs text-ink-muted">{k.display_prefix}…</td>
                  <td className="px-4 py-3 text-xs text-ink-muted">{k.scopes.join(", ")}</td>
                  <td className="px-4 py-3 text-xs text-ink-muted">{k.last_used_at ? new Date(k.last_used_at).toLocaleString() : "Never"}</td>
                  <td className="px-4 py-3 text-right">
                    {k.revoked_at ? (
                      <span className="text-xs text-ink-muted">Revoked</span>
                    ) : (
                      <button onClick={() => handleRevoke(k.id)} className="text-xs text-ink-muted hover:text-signal">
                        Revoke
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
