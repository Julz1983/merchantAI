"use client";

import { useState } from "react";
import { api, type ChatResponse } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

type Turn = { role: "user" | "assistant"; content: string; response?: ChatResponse };

export default function AssistantPage() {
  const [sessionId] = useState(() => `dashboard-test-${Date.now()}`);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    const token = getAccessToken();
    const message = input.trim();
    if (!token || !message) return;

    setTurns((prev) => [...prev, { role: "user", content: message }]);
    setInput("");
    setSending(true);
    try {
      const response = await api.sendChatMessage(token, sessionId, message);
      setTurns((prev) => [...prev, { role: "assistant", content: response.reply, response }]);
    } catch (err) {
      setTurns((prev) => [...prev, { role: "assistant", content: err instanceof Error ? err.message : "Something went wrong." }]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-bold">Assistant</h1>
      <p className="mt-1 text-sm text-ink-muted">
        Test how the AI assistant answers customer questions using your catalogue, documents, and knowledge graph.
      </p>

      <div className="mt-6 min-h-[300px] border border-line bg-white p-5">
        {turns.length === 0 ? (
          <p className="text-sm text-ink-muted">Ask something a customer might ask — e.g. &ldquo;I want to build a raised deck, what do I need?&rdquo;</p>
        ) : (
          <div className="space-y-4">
            {turns.map((turn, i) => (
              <div key={i} className={turn.role === "user" ? "text-right" : ""}>
                <div
                  className={`inline-block max-w-[85%] px-3 py-2 text-sm text-left ${
                    turn.role === "user" ? "bg-ink text-paper" : "spec-corner border border-line bg-paper"
                  }`}
                >
                  {turn.content}
                </div>
                {turn.response && turn.response.suggested_products.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {turn.response.suggested_products.map((p) => (
                      <div key={p.id} className="border border-line bg-white px-2.5 py-1.5 text-left text-xs">
                        <p className="font-medium">{p.name}</p>
                        <p className="font-mono text-[10px] text-ink-muted">
                          {p.sku} {p.price != null ? `· £${p.price.toFixed(2)}` : ""} · {p.reason.toLowerCase()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="mt-3 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask a question…"
          className="flex-1 border border-line bg-white px-3 py-2 text-sm focus:border-steel focus:outline-none focus:ring-1 focus:ring-steel"
        />
        <button
          type="submit"
          disabled={sending}
          className="bg-ink px-4 py-2 text-sm font-medium text-paper transition hover:bg-steel disabled:opacity-50"
        >
          {sending ? "Thinking…" : "Send"}
        </button>
      </form>
    </div>
  );
}
