"use client";

import { useEffect, useState } from "react";
import { api, type AnalyticsSummary } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

const RANGES = [
  { value: "7d", label: "7 days" },
  { value: "30d", label: "30 days" },
  { value: "90d", label: "90 days" },
  { value: "all", label: "All time" },
];

const STAT_LABELS: { key: keyof AnalyticsSummary["counts"]; label: string }[] = [
  { key: "question", label: "Questions asked" },
  { key: "recommendation", label: "Products recommended" },
  { key: "click", label: "Product clicks" },
  { key: "product_missing", label: "Products not found" },
  { key: "document_used", label: "Document citations" },
  { key: "kg_path_used", label: "Knowledge Graph paths used" },
];

export default function AnalyticsPage() {
  const [range, setRange] = useState("30d");
  const [summary, setSummary] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) return;
    setLoading(true);
    api.getAnalyticsSummary(token, range).then(setSummary).finally(() => setLoading(false));
  }, [range]);

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">Analytics</h1>
          <p className="mt-1 text-sm text-ink-muted">What customers are asking the assistant, and how it's answering.</p>
        </div>
        <select
          value={range}
          onChange={(e) => setRange(e.target.value)}
          className="border border-line bg-white px-3 py-2 text-sm focus:border-steel focus:outline-none"
        >
          {RANGES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
      </div>

      {loading || !summary ? (
        <p className="mt-8 font-mono text-sm text-ink-muted">Loading…</p>
      ) : (
        <>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
            {STAT_LABELS.map((stat) => (
              <div key={stat.key} className="border border-line bg-white p-4">
                <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">{stat.label}</p>
                <p className="mt-1 font-display text-2xl font-bold">{summary.counts[stat.key]}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="border border-line bg-white">
              <div className="border-b border-line px-4 py-3">
                <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">Questions with no matching product</p>
                <p className="mt-0.5 text-xs text-ink-muted">A demand signal — things customers want that aren&apos;t (or aren&apos;t visibly) in your catalogue.</p>
              </div>
              {summary.top_missing_queries.length === 0 ? (
                <p className="px-4 py-6 text-center text-sm text-ink-muted">No gaps found in this range.</p>
              ) : (
                <table className="w-full text-left text-sm">
                  <tbody>
                    {summary.top_missing_queries.map((q, i) => (
                      <tr key={i} className="border-b border-line last:border-0">
                        <td className="px-4 py-2.5">{q.question}</td>
                        <td className="px-4 py-2.5 text-right font-mono text-xs text-ink-muted">{q.count}×</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="border border-line bg-white">
              <div className="border-b border-line px-4 py-3">
                <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">Most-cited documents</p>
                <p className="mt-0.5 text-xs text-ink-muted">Installation guides and manuals the assistant referenced most often.</p>
              </div>
              {summary.most_cited_documents.length === 0 ? (
                <p className="px-4 py-6 text-center text-sm text-ink-muted">No document citations in this range.</p>
              ) : (
                <table className="w-full text-left text-sm">
                  <tbody>
                    {summary.most_cited_documents.map((d) => (
                      <tr key={d.document_id} className="border-b border-line last:border-0">
                        <td className="px-4 py-2.5">{d.document_title}</td>
                        <td className="px-4 py-2.5 text-right font-mono text-xs text-ink-muted">{d.count}×</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
