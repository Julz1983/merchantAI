"use client";

import { useEffect, useState } from "react";
import { api, type PendingEdge } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

const RELATIONSHIP_STYLES: Record<string, string> = {
  REQUIRES: "text-signal",
  ACCESSORY: "text-brass",
  ALTERNATIVE: "text-steel",
  COMPATIBLE_WITH: "text-success",
  NOT_COMPATIBLE_WITH: "text-signal",
  INSTALLED_WITH: "text-steel",
};

export default function KnowledgeGraphPage() {
  const [pending, setPending] = useState<PendingEdge[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  function refresh() {
    const token = getAccessToken();
    if (!token) return;
    api.listPendingEdges(token).then(setPending).catch(() => {});
  }

  useEffect(refresh, []);

  async function handleDecision(id: string, decision: "approve" | "reject") {
    const token = getAccessToken();
    if (!token) return;
    setBusy(id);
    try {
      if (decision === "approve") await api.approveEdge(token, id);
      else await api.rejectEdge(token, id);
      setPending((prev) => (prev ? prev.filter((e) => e.id !== id) : prev));
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Knowledge Graph</h1>
      <p className="mt-1 text-sm text-ink-muted">
        Relationships found automatically while importing your catalogue. Review each before it's used to make recommendations.
      </p>

      {pending === null ? (
        <p className="mt-6 font-mono text-sm text-ink-muted">Loading…</p>
      ) : pending.length === 0 ? (
        <div className="mt-6 border border-line bg-white p-8 text-center">
          <p className="text-sm text-ink-muted">Nothing waiting for review right now.</p>
          <p className="mt-1 text-xs text-ink-muted">Import products to generate new candidate relationships.</p>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {pending.map((edge) => (
            <div key={edge.id} className="border border-line bg-white p-4">
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="font-medium">{edge.source_label}</span>
                    <span className={`font-mono text-xs font-medium ${RELATIONSHIP_STYLES[edge.relationship_type] ?? "text-ink-muted"}`}>
                      —{edge.relationship_type}→
                    </span>
                    <span className="font-medium">{edge.target_label}</span>
                  </div>
                  {edge.evidence && (
                    <p className="mt-1.5 text-xs text-ink-muted">
                      Evidence: <span className="italic">{edge.evidence}</span>
                    </p>
                  )}
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-ink-muted">
                    Confidence {Math.round(edge.weight * 100)}%
                  </p>
                </div>
                <div className="flex flex-shrink-0 gap-2">
                  <button
                    disabled={busy === edge.id}
                    onClick={() => handleDecision(edge.id, "reject")}
                    className="border border-line px-3 py-1.5 text-xs font-medium text-ink-muted transition hover:border-signal hover:text-signal disabled:opacity-40"
                  >
                    Reject
                  </button>
                  <button
                    disabled={busy === edge.id}
                    onClick={() => handleDecision(edge.id, "approve")}
                    className="bg-ink px-3 py-1.5 text-xs font-medium text-paper transition hover:bg-steel disabled:opacity-40"
                  >
                    Approve
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
