export default function OverviewPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Overview</h1>
      <p className="mt-1 text-sm text-ink-muted">
        You&apos;re signed in and tenant-scoped. Feature modules land here week by week.
      </p>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[
          { label: "Products", value: "See Products →", ready: true, href: "/products" },
          { label: "Documents processed", value: "0", ready: false },
          { label: "Knowledge Graph edges", value: "0", ready: false },
        ].map((stat) => (
          <div key={stat.label} className="border border-line bg-white p-5">
            <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">
              {stat.label}
            </p>
            <p className="mt-2 font-display text-2xl font-bold">
              {stat.href ? (
                <a href={stat.href} className="hover:text-signal">{stat.value}</a>
              ) : (
                stat.value
              )}
            </p>
            <p className="mt-1 text-xs text-ink-muted">
              {stat.ready ? "Ready" : "Ships in a later week — see roadmap"}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
