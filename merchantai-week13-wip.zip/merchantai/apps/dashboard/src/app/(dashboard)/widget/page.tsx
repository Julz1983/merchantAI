"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api, type ApiKeyItem } from "@/lib/api";
import { getAccessToken } from "@/lib/auth";

export default function WidgetPage() {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) return;
    api.listApiKeys(token).then(setKeys).catch(() => {});
  }, []);

  const activeKey = keys.find((k) => !k.revoked_at && k.scopes.includes("widget"));

  const snippet = `<script src="https://cdn.merchantai.com/merchantai.js"></script>
<script>
  MerchantAI.init({
    apiKey: "${activeKey ? activeKey.display_prefix + "…" : "YOUR_WIDGET_API_KEY"}"
  });
</script>`;

  function handleCopy() {
    navigator.clipboard.writeText(snippet).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Widget</h1>
      <p className="mt-1 text-sm text-ink-muted">Add the assistant to your website with one script tag.</p>

      {!activeKey && (
        <div className="mt-4 border-l-2 border-brass bg-brass/5 px-4 py-3 text-sm">
          You&apos;ll need a widget-scoped API key before embedding.{" "}
          <Link href="/api-keys" className="font-medium text-steel hover:underline">Create one →</Link>
        </div>
      )}

      <div className="mt-6 border border-line bg-white p-5">
        <div className="mb-3 flex items-center justify-between">
          <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">Embed snippet</p>
          <button
            onClick={handleCopy}
            className="border border-line px-3 py-1 text-xs font-medium text-ink-muted hover:border-steel hover:text-steel"
          >
            {copied ? "Copied!" : "Copy"}
          </button>
        </div>
        <pre className="overflow-x-auto bg-paper p-4 font-mono text-xs leading-relaxed">{snippet}</pre>
        <p className="mt-3 text-xs text-ink-muted">
          Paste this just before the closing <code className="bg-paper px-1">&lt;/body&gt;</code> tag on
          any page you want the assistant to appear on. It renders inside a Shadow DOM, so it won&apos;t
          be affected by — or affect — your site&apos;s existing styles.
        </p>
      </div>

      <div className="mt-6 border border-line bg-white p-5">
        <p className="font-mono text-[11px] uppercase tracking-wider text-ink-muted">Preview</p>
        <p className="mt-2 text-sm text-ink-muted">
          Branding (colors, name) is pulled automatically from your merchant profile. Use the{" "}
          <Link href="/assistant" className="text-steel hover:underline">Assistant</Link> page to test
          how it responds before going live.
        </p>
      </div>
    </div>
  );
}
