"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/api";
import { storeTokens } from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const tokens = await api.login(email, password);
      storeTokens(tokens.access_token, tokens.refresh_token);
      router.push("/");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-center gap-2">
          <div className="h-6 w-6 bg-signal spec-corner" />
          <span className="font-display text-lg font-bold tracking-tight">MerchantAI</span>
        </div>

        <div className="spec-corner border border-line bg-white px-8 py-8">
          <p className="mb-1 font-mono text-[11px] uppercase tracking-wider text-ink-muted">
            Merchant sign in
          </p>
          <h1 className="mb-6 font-display text-2xl font-bold">Welcome back</h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="mb-1 block text-sm font-medium text-ink-muted">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-line bg-paper px-3 py-2 text-sm focus:border-steel focus:outline-none focus:ring-1 focus:ring-steel"
                placeholder="you@merchant.com"
              />
            </div>
            <div>
              <label htmlFor="password" className="mb-1 block text-sm font-medium text-ink-muted">
                Password
              </label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-line bg-paper px-3 py-2 text-sm focus:border-steel focus:outline-none focus:ring-1 focus:ring-steel"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <p className="border-l-2 border-signal bg-signal/5 px-3 py-2 text-sm text-signal">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-ink px-4 py-2.5 text-sm font-medium text-paper transition hover:bg-steel disabled:opacity-50"
            >
              {loading ? "Signing in…" : "Sign in"}
            </button>
          </form>
        </div>

        <p className="mt-4 text-center text-xs text-ink-muted">
          Demo login: admin@demo-merchant.dev / changeme123
        </p>
      </div>
    </main>
  );
}
