import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MerchantAI",
  description: "AI Commerce Platform for Builders' Merchants",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
