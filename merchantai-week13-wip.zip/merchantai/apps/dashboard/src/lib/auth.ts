const ACCESS_TOKEN_KEY = "merchantai_access_token";
const REFRESH_TOKEN_KEY = "merchantai_refresh_token";

export function storeTokens(accessToken: string, refreshToken: string) {
  localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
  localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
}

export function getAccessToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(ACCESS_TOKEN_KEY);
}

export function clearTokens() {
  localStorage.removeItem(ACCESS_TOKEN_KEY);
  localStorage.removeItem(REFRESH_TOKEN_KEY);
}

// NOTE: localStorage is fine for the Week-1 demo slice. Before production,
// this should move to httpOnly cookies set by the API, so an XSS in the
// dashboard can't read the token directly (see architecture §13).
