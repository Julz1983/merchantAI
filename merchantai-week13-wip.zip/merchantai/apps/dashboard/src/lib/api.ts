const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000/api/v1";

type Envelope<T> = {
  data: T | null;
  meta: { request_id: string };
  error: { message: string } | null;
};

export class ApiError extends Error {}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const isFormData = options.body instanceof FormData;
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      // Don't set Content-Type for FormData — the browser needs to add its
      // own multipart boundary, which it can only do if we leave this unset.
      ...(isFormData ? {} : { "Content-Type": "application/json" }),
      ...(options.headers ?? {}),
    },
  });

  let body: Envelope<T>;
  try {
    body = await res.json();
  } catch {
    throw new ApiError(`Request to ${path} failed (${res.status})`);
  }

  if (!res.ok || body.error) {
    throw new ApiError(body.error?.message ?? `Request to ${path} failed (${res.status})`);
  }
  if (body.data === null) {
    throw new ApiError(`Request to ${path} returned no data`);
  }
  return body.data;
}

function authHeaders(token: string): HeadersInit {
  return { Authorization: `Bearer ${token}` };
}

// ── Auth ──────────────────────────────────────────────────────────────

export type TokenResponse = {
  access_token: string;
  refresh_token: string;
  token_type: string;
};

export type MeResponse = {
  user_id: string;
  merchant_id: string;
  email: string;
  role: string;
  merchant_name: string;
};

// ── Catalogue ─────────────────────────────────────────────────────────

export type Product = {
  id: string;
  sku: string;
  name: string;
  description: string | null;
  category_id: string | null;
  category_name: string | null;
  brand_id: string | null;
  brand_name: string | null;
  price: number | null;
  currency: string;
  images: string[];
  product_url: string | null;
  specifications: Record<string, string>;
  attributes: Record<string, string>;
  stock_status: string;
  created_at: string;
  updated_at: string;
};

export type ProductListResponse = {
  items: Product[];
  total: number;
  page: number;
  page_size: number;
};

export type Category = { id: string; name: string; parent_id: string | null };
export type Brand = { id: string; name: string };

// ── Import ────────────────────────────────────────────────────────────

export type ImportInspectResponse = {
  headers: string[];
  suggested_mapping: Record<string, string>;
  sample_rows: Record<string, string>[];
  total_rows: number;
  target_fields: string[];
  required_fields: string[];
};

export type ImportJob = {
  id: string;
  filename: string;
  status: "pending" | "processing" | "completed" | "failed";
  total_rows: number;
  processed_rows: number;
  created_count: number;
  updated_count: number;
  error_rows: { row_number: number; errors: string[] }[];
  created_at: string;
  completed_at: string | null;
};

// ── Documents ─────────────────────────────────────────────────────────

export type MerchantDocument = {
  id: string;
  title: string;
  doc_type: string;
  original_filename: string;
  status: "processing" | "ready" | "failed";
  error_message: string | null;
  page_count: number | null;
  chunk_count: number;
  created_at: string;
  updated_at: string;
};

export type DocumentSearchResult = {
  chunk_id: string;
  score: number;
  document_id: string;
  document_title: string;
  chunk_index: number;
  page_number: number | null;
  content: string;
};

// ── Knowledge Graph ───────────────────────────────────────────────────

export type PendingEdge = {
  id: string;
  source_label: string;
  target_label: string;
  relationship_type: string;
  weight: number;
  evidence: string | null;
  created_at: string;
};

export type KGNode = { id: string; node_type: string; ref_id: string | null; label: string };
export type KGEdgeItem = {
  id: string;
  source_node_id: string;
  target_node_id: string;
  relationship_type: string;
  weight: number;
  source: string;
  status: string;
  evidence: string | null;
};
export type KGNeighborhood = { nodes: KGNode[]; edges: KGEdgeItem[] };

// ── Chat / AI Assistant ──────────────────────────────────────────────

export type SuggestedProduct = {
  id: string;
  sku: string;
  name: string;
  price: number | null;
  stock_status: string;
  reason: string;
};

export type ChatResponse = {
  reply: string;
  citations: { product_ids: string[]; document_chunk_ids: string[] };
  suggested_products: SuggestedProduct[];
};

// ── API Keys ──────────────────────────────────────────────────────────

export type ApiKeyItem = {
  id: string;
  label: string;
  display_prefix: string;
  scopes: string[];
  last_used_at: string | null;
  created_at: string;
  revoked_at: string | null;
};

export type ApiKeyCreateResponse = ApiKeyItem & { plaintext_key: string };

// ── Analytics ─────────────────────────────────────────────────────────

export type EventCounts = {
  question: number;
  recommendation: number;
  click: number;
  product_found: number;
  product_missing: number;
  document_used: number;
  kg_path_used: number;
  conversion: number;
};

export type AnalyticsSummary = {
  range: string;
  counts: EventCounts;
  top_missing_queries: { question: string; count: number }[];
  most_cited_documents: { document_id: string; document_title: string; count: number }[];
};

export const api = {
  login: (email: string, password: string) =>
    request<TokenResponse>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),

  me: (token: string) => request<MeResponse>("/auth/me", { headers: authHeaders(token) }),
  listProducts: (
    token: string,
    params: { page?: number; page_size?: number; search?: string; category_id?: string; brand_id?: string; stock_status?: string } = {}
  ) => {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v && query.set(k, String(v)));
    return request<ProductListResponse>(`/products?${query.toString()}`, { headers: authHeaders(token) });
  },

  getProduct: (token: string, id: string) => request<Product>(`/products/${id}`, { headers: authHeaders(token) }),

  listCategories: (token: string) => request<Category[]>("/categories", { headers: authHeaders(token) }),
  listBrands: (token: string) => request<Brand[]>("/brands", { headers: authHeaders(token) }),

  inspectImport: (token: string, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<ImportInspectResponse>("/products/import/inspect", {
      method: "POST",
      headers: authHeaders(token),
      body: form,
    });
  },

  startImport: (token: string, file: File, mapping: Record<string, string>) => {
    const form = new FormData();
    form.append("file", file);
    form.append("mapping", JSON.stringify(mapping));
    return request<ImportJob>("/products/import", {
      method: "POST",
      headers: authHeaders(token),
      body: form,
    });
  },

  getImportStatus: (token: string, jobId: string) =>
    request<ImportJob>(`/products/import/${jobId}`, { headers: authHeaders(token) }),

  listDocuments: (token: string) => request<MerchantDocument[]>("/documents", { headers: authHeaders(token) }),

  getDocument: (token: string, id: string) =>
    request<MerchantDocument>(`/documents/${id}`, { headers: authHeaders(token) }),

  uploadDocument: (token: string, file: File, title: string, docType: string) => {
    const form = new FormData();
    form.append("file", file);
    form.append("title", title);
    form.append("doc_type", docType);
    return request<MerchantDocument>("/documents", {
      method: "POST",
      headers: authHeaders(token),
      body: form,
    });
  },

  deleteDocument: async (token: string, id: string) => {
    const res = await fetch(`${API_URL}/documents/${id}`, { method: "DELETE", headers: authHeaders(token) });
    if (!res.ok) throw new ApiError(`Failed to delete document (${res.status})`);
  },

  searchDocuments: (token: string, q: string) =>
    request<DocumentSearchResult[]>(`/documents/search?q=${encodeURIComponent(q)}`, { headers: authHeaders(token) }),

  listPendingEdges: (token: string) => request<PendingEdge[]>("/kg/edges/pending", { headers: authHeaders(token) }),

  approveEdge: (token: string, id: string) =>
    request<KGEdgeItem>(`/kg/edges/${id}/approve`, { method: "POST", headers: authHeaders(token) }),

  rejectEdge: (token: string, id: string) =>
    request<KGEdgeItem>(`/kg/edges/${id}/reject`, { method: "POST", headers: authHeaders(token) }),

  getNodeByRef: (token: string, nodeType: string, refId: string) =>
    request<KGNode | null>(`/kg/nodes/by-ref/${nodeType}/${refId}`, { headers: authHeaders(token) }).catch(() => null),

  getNodeNeighborhood: (token: string, nodeId: string, depth = 2) =>
    request<KGNeighborhood>(`/kg/nodes/${nodeId}/neighborhood?depth=${depth}`, { headers: authHeaders(token) }),

  sendChatMessage: (token: string, sessionId: string, message: string) =>
    request<ChatResponse>("/chat/message", {
      method: "POST",
      headers: authHeaders(token),
      body: JSON.stringify({ session_id: sessionId, message }),
    }),

  listApiKeys: (token: string) => request<ApiKeyItem[]>("/api-keys", { headers: authHeaders(token) }),

  createApiKey: (token: string, label: string, scopes: string[]) =>
    request<ApiKeyCreateResponse>("/api-keys", {
      method: "POST",
      headers: authHeaders(token),
      body: JSON.stringify({ label, scopes }),
    }),

  revokeApiKey: async (token: string, id: string) => {
    const res = await fetch(`${API_URL}/api-keys/${id}`, { method: "DELETE", headers: authHeaders(token) });
    if (!res.ok) throw new ApiError(`Failed to revoke key (${res.status})`);
  },

  getAnalyticsSummary: (token: string, range: string) =>
    request<AnalyticsSummary>(`/analytics/summary?range=${range}`, { headers: authHeaders(token) }),
};
