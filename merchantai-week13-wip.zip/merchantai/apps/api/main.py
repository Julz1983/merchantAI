from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from core.error_handlers import register_exception_handlers
from routers import analytics, api_keys, auth, catalogue, chat, documents, health, knowledge_graph, products, settings, users, widget

app = FastAPI(
    title="MerchantAI API",
    version="0.1.0",
    description="AI Commerce Platform for Builders' Merchants — Week 8: hardening",
)

register_exception_handlers(app)

app.add_middleware(
    CORSMiddleware,
    # Deliberately open (not settings.cors_origins_list): the widget
    # (routers/widget.py) is embedded on arbitrary merchant websites we
    # can't enumerate in advance — a fixed origin allowlist that works for
    # the dashboard would break every widget install. This is safe because
    # neither auth mechanism in this API relies on cookies (JWT is sent via
    # an Authorization header, widget auth via X-API-Key) — there's no
    # ambient-credential/CSRF exposure a wildcard origin would normally
    # create. allow_credentials must be False to pair with a wildcard
    # origin (browsers reject the combination of "*" + credentials=true).
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api/v1")
app.include_router(auth.router, prefix="/api/v1")
app.include_router(products.router, prefix="/api/v1")
app.include_router(catalogue.router, prefix="/api/v1")
app.include_router(documents.router, prefix="/api/v1")
app.include_router(knowledge_graph.router, prefix="/api/v1")
app.include_router(chat.router, prefix="/api/v1")
app.include_router(api_keys.router, prefix="/api/v1")
app.include_router(widget.router, prefix="/api/v1")
app.include_router(analytics.router, prefix="/api/v1")
app.include_router(settings.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
