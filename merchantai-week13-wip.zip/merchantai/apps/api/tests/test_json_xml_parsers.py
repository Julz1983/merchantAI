import pytest

from engines.import_engine.mapping import apply_mapping, suggest_mapping
from engines.import_engine.parsers.base import ParseError
from engines.import_engine.parsers.json_parser import JSONParser
from engines.import_engine.parsers.xml_parser import XMLParser

SAMPLE_JSON_ARRAY = """
[
  {"sku": "DK-100", "name": "Composite Decking Board 3.6m", "price": 45.99, "in_stock": true},
  {"sku": "DK-101", "name": "Deck Joist 2.4m", "price": 12.50, "in_stock": true},
  {"sku": "FX-200", "name": "Hidden Fixing Clips", "in_stock": false}
]
"""

SAMPLE_JSON_WRAPPED = """
{
  "exported_at": "2026-09-01",
  "products": [
    {"sku": "DK-100", "name": "Composite Decking Board 3.6m", "price": 45.99}
  ]
}
"""

SAMPLE_XML = """<?xml version="1.0" encoding="UTF-8"?>
<products>
  <product>
    <sku>DK-100</sku>
    <name>Composite Decking Board 3.6m</name>
    <price>45.99</price>
  </product>
  <product>
    <sku>DK-101</sku>
    <name>Deck Joist 2.4m</name>
    <price>12.50</price>
  </product>
</products>
"""


class TestJSONParser:
    def test_parses_top_level_array(self):
        sheet = JSONParser().parse(SAMPLE_JSON_ARRAY.encode("utf-8"))
        assert sheet.headers == ["sku", "name", "price", "in_stock"]
        assert len(sheet.rows) == 3
        assert sheet.rows[0]["sku"] == "DK-100"

    def test_stringifies_non_string_values(self):
        """Numbers/booleans become strings, matching the contract CSV/XLSX
        already establish — mapping.py expects string cell values regardless
        of source format."""
        sheet = JSONParser().parse(SAMPLE_JSON_ARRAY.encode("utf-8"))
        assert sheet.rows[0]["price"] == "45.99"
        assert sheet.rows[0]["in_stock"] == "true"
        assert sheet.rows[2]["in_stock"] == "false"

    def test_handles_missing_keys_across_records(self):
        """FX-200 has no 'price' key — should read as '' (empty), not crash
        or drop the row, matching CSV's tolerance for ragged input."""
        sheet = JSONParser().parse(SAMPLE_JSON_ARRAY.encode("utf-8"))
        fx200 = next(r for r in sheet.rows if r["sku"] == "FX-200")
        assert fx200["price"] == ""

    def test_parses_wrapped_object_with_single_array_field(self):
        sheet = JSONParser().parse(SAMPLE_JSON_WRAPPED.encode("utf-8"))
        assert sheet.headers == ["sku", "name", "price"]
        assert len(sheet.rows) == 1

    def test_rejects_object_with_multiple_array_fields(self):
        ambiguous = '{"products": [{"sku": "A"}], "categories": [{"name": "B"}]}'
        with pytest.raises(ParseError, match="multiple array fields"):
            JSONParser().parse(ambiguous.encode("utf-8"))

    def test_rejects_invalid_json(self):
        with pytest.raises(ParseError, match="Invalid JSON"):
            JSONParser().parse(b"{not valid json")

    def test_rejects_array_of_non_objects(self):
        with pytest.raises(ParseError, match="must be an object"):
            JSONParser().parse(b'["just", "strings"]')

    def test_full_mapping_pipeline_works_on_json_source(self):
        """The whole point of the pluggable parser design — JSON output
        feeds into the exact same mapping/validation pipeline as CSV,
        unmodified."""
        sheet = JSONParser().parse(SAMPLE_JSON_ARRAY.encode("utf-8"))
        mapping = suggest_mapping(sheet.headers)
        rows = apply_mapping(sheet.rows, mapping)
        assert rows[0].is_valid
        assert rows[0].sku == "DK-100"
        assert rows[0].price == 45.99


class TestXMLParser:
    def test_parses_records_and_fields(self):
        sheet = XMLParser().parse(SAMPLE_XML.encode("utf-8"))
        assert sheet.headers == ["sku", "name", "price"]
        assert len(sheet.rows) == 2
        assert sheet.rows[0]["sku"] == "DK-100"
        assert sheet.rows[1]["name"] == "Deck Joist 2.4m"

    def test_rejects_root_with_no_records(self):
        with pytest.raises(ParseError, match="no child records"):
            XMLParser().parse(b"<products></products>")

    def test_rejects_malformed_xml(self):
        with pytest.raises(ParseError, match="Couldn't parse"):
            XMLParser().parse(b"<products><product><sku>DK-100</sku>")  # unclosed tags

    def test_tolerates_ragged_records(self):
        """One record missing a field another has — should read as '' for
        that record, not crash, matching CSV's tolerance."""
        ragged = """<products>
            <product><sku>A</sku><name>Widget</name><price>5.00</price></product>
            <product><sku>B</sku><name>Gadget</name></product>
        </products>"""
        sheet = XMLParser().parse(ragged.encode("utf-8"))
        assert sheet.rows[1]["price"] == ""

    def test_full_mapping_pipeline_works_on_xml_source(self):
        sheet = XMLParser().parse(SAMPLE_XML.encode("utf-8"))
        mapping = suggest_mapping(sheet.headers)
        rows = apply_mapping(sheet.rows, mapping)
        assert rows[0].is_valid
        assert rows[0].sku == "DK-100"
        assert rows[0].price == 45.99

    def test_rejects_xml_entity_expansion_attack(self):
        """defusedxml should reject a billion-laughs-style entity expansion
        payload rather than attempt to parse it — proves the safety guard
        is actually wired in, not just imported."""
        billion_laughs = """<?xml version="1.0"?>
        <!DOCTYPE products [
          <!ENTITY a "spam">
          <!ENTITY b "&a;&a;&a;&a;&a;&a;&a;&a;&a;&a;">
          <!ENTITY c "&b;&b;&b;&b;&b;&b;&b;&b;&b;&b;">
        ]>
        <products>&c;</products>"""
        with pytest.raises(ParseError):
            XMLParser().parse(billion_laughs.encode("utf-8"))
