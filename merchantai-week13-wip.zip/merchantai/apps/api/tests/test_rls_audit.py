"""
Runs the RLS audit (core/rls_audit.py) as part of the test suite — a real
migration or model change that leaves a table without proper RLS should
fail CI, not wait to be caught by manual review or, worse, production
traffic. See core/rls_audit.py's docstring for what "proper" means.

Requires TEST_DATABASE_URL with all migrations already applied (same
convention as the other *_integration.py tests in this directory).
"""
import os

import pytest

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")

pytestmark = pytest.mark.skipif(not TEST_DATABASE_URL, reason="TEST_DATABASE_URL not set — skipping live-Postgres integration tests")


def test_every_tenant_table_has_correct_rls():
    from core.rls_audit import audit

    dsn = TEST_DATABASE_URL.replace("postgresql+psycopg://", "postgresql://")
    problems = audit(dsn)

    assert problems == [], "RLS audit found problems:\n" + "\n".join(f"  - {p}" for p in problems)
