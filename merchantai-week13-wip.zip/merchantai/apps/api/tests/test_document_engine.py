import uuid

from engines.document_engine.chunker import chunk_document
from engines.document_engine.embeddings import EMBEDDING_DIMENSIONS, LocalHashEmbeddingProvider
from engines.document_engine.extractors.txt_extractor import TXTExtractor
from engines.document_engine.vector_store import search, upsert_chunks

DECKING_GUIDE = (
    "Composite Decking Installation Guide\n\n"
    "This guide covers the installation of composite decking boards for "
    "residential garden projects.\n\n"
    "Joist spacing must be between 300mm and 400mm depending on board "
    "thickness. Use pressure-treated timber joists rated for outdoor use.\n\n"
    "Hidden fixing clips should be used between each board to allow for "
    "thermal expansion and contraction across seasons.\n\n"
    "Pre-drill pilot holes near board ends to prevent splitting during "
    "installation."
)

FIXING_MANUAL = (
    "Hidden Fixing Clip Manual\n\n"
    "This manual explains how to install stainless steel hidden fixing "
    "clips for composite decking boards.\n\n"
    "Space clips at 300mm intervals along each joist. Do not overtighten "
    "screws, as this can crack the board edge."
)


def test_txt_extraction_and_chunking_roundtrip():
    doc = TXTExtractor().extract(DECKING_GUIDE.encode("utf-8"))
    assert doc.page_count == 1
    chunks = chunk_document(doc)
    assert len(chunks) >= 1
    # All original content should survive somewhere in the chunks (allowing
    # for the overlap duplicating some text, never losing any).
    joined = " ".join(c.content for c in chunks)
    assert "Hidden fixing clips" in joined
    assert "Pre-drill pilot holes" in joined


def test_local_embedding_provider_is_deterministic():
    provider = LocalHashEmbeddingProvider()
    v1 = provider.embed(["hidden fixing clips"])[0]
    v2 = provider.embed(["hidden fixing clips"])[0]
    assert v1 == v2
    assert len(v1) == EMBEDDING_DIMENSIONS


def test_local_embedding_provider_differs_for_different_text():
    provider = LocalHashEmbeddingProvider()
    v1 = provider.embed(["hidden fixing clips"])[0]
    v2 = provider.embed(["something completely different"])[0]
    assert v1 != v2


def test_full_pipeline_document_is_searchable_after_ingest():
    """
    Exercises the actual Week-3 exit criteria end to end: extract -> chunk ->
    embed -> store in Qdrant -> query -> get the right chunk back. Uses
    Qdrant's in-process local mode (no server needed) and the local hash
    embedding provider (no OpenAI API key needed) — see vector_store.py and
    embeddings.py docstrings for why that's a legitimate way to prove the
    plumbing works, distinct from proving retrieval quality.
    """
    merchant_id = uuid.uuid4()
    provider = LocalHashEmbeddingProvider()

    # Ingest two different documents, so the test also proves search doesn't
    # just return "whatever's in the collection" — it has to pick the right one.
    for doc_id_seed, title, text in [(1, "Decking Installation Guide", DECKING_GUIDE), (2, "Fixing Clip Manual", FIXING_MANUAL)]:
        document_id = uuid.uuid4()
        extracted = TXTExtractor().extract(text.encode("utf-8"))
        chunks = chunk_document(extracted)
        vectors = provider.embed([c.content for c in chunks])
        points = [
            (uuid.uuid4(), vector, {
                "merchant_id": str(merchant_id), "document_id": str(document_id),
                "document_title": title, "chunk_index": i,
                "page_number": chunk.page_number, "content": chunk.content,
            })
            for i, (chunk, vector) in enumerate(zip(chunks, vectors))
        ]
        upsert_chunks(merchant_id, points)

    # Query with text that's an exact substring of a chunk from the first
    # document — the local provider is a hash, not a semantic model, so exact
    # or near-exact text is what it can meaningfully match on.
    query_vector = provider.embed([DECKING_GUIDE])[0]
    results = search(merchant_id, query_vector, limit=1)

    assert len(results) == 1
    assert results[0]["payload"]["document_title"] == "Decking Installation Guide"


def test_search_is_isolated_per_merchant():
    """A second merchant's collection must not surface results for the first
    merchant's documents — same tenant-isolation principle as the RLS tests,
    applied to the vector store."""
    merchant_a = uuid.uuid4()
    merchant_b = uuid.uuid4()
    provider = LocalHashEmbeddingProvider()

    extracted = TXTExtractor().extract(DECKING_GUIDE.encode("utf-8"))
    chunks = chunk_document(extracted)
    vectors = provider.embed([c.content for c in chunks])
    points = [
        (uuid.uuid4(), vector, {"document_title": "Decking Installation Guide", "content": chunk.content})
        for chunk, vector in zip(chunks, vectors)
    ]
    upsert_chunks(merchant_a, points)

    query_vector = provider.embed([DECKING_GUIDE])[0]
    results_for_b = search(merchant_b, query_vector, limit=5)
    assert results_for_b == []


def test_content_type_filter_excludes_products_from_document_search():
    """
    Regression test for a real bug: products and document chunks share one
    Qdrant collection per merchant (architecture §14). An unfiltered search
    mixed both together — since a document-search caller assumes every
    result has document fields (document_id, document_title, content), a
    product vector showing up in those results rendered as an entry with
    all those fields empty, not an error, which made it easy to miss in
    testing with only one document and no products. This test seeds both
    in realistic proportions (many products, one document chunk) and checks
    the content_type filter actually excludes the products.
    """
    merchant_id = uuid.uuid4()
    provider = LocalHashEmbeddingProvider()

    # Many products (mirrors a real catalogue outnumbering documents).
    product_points = [
        (uuid.uuid4(), provider.embed([f"Product number {i} generic description"])[0], {
            "content_type": "product", "product_id": str(uuid.uuid4()), "sku": f"SKU-{i}", "name": f"Product {i}",
        })
        for i in range(20)
    ]
    upsert_chunks(merchant_id, product_points)

    # One document chunk.
    extracted = TXTExtractor().extract(DECKING_GUIDE.encode("utf-8"))
    chunks = chunk_document(extracted)
    doc_vectors = provider.embed([c.content for c in chunks])
    doc_points = [
        (uuid.uuid4(), vector, {
            "content_type": "document_chunk", "document_id": str(uuid.uuid4()),
            "document_title": "Decking Installation Guide", "content": chunk.content,
        })
        for chunk, vector in zip(chunks, doc_vectors)
    ]
    upsert_chunks(merchant_id, doc_points)

    query_vector = provider.embed([DECKING_GUIDE])[0]
    results = search(merchant_id, query_vector, limit=10, content_type="document_chunk")

    assert len(results) == len(chunks)
    for r in results:
        assert r["payload"]["content_type"] == "document_chunk"
        assert r["payload"]["document_title"] == "Decking Installation Guide"
        assert r["payload"]["content"]  # never an empty string, unlike the pre-fix bug
