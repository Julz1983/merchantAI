import uuid

import pytest

from core.rate_limit import check_rate_limit
from core.redis_client import get_redis


@pytest.fixture(autouse=True)
def _skip_if_no_redis():
    try:
        get_redis().ping()
    except Exception:
        pytest.skip("Redis not reachable — skipping rate limit tests")


def test_allows_requests_under_the_limit():
    key = f"test:{uuid.uuid4()}"
    for _ in range(5):
        allowed, remaining = check_rate_limit(key, limit=5, window_seconds=60)
        assert allowed
    get_redis().delete(f"ratelimit:{key}:60")


def test_blocks_requests_over_the_limit():
    key = f"test:{uuid.uuid4()}"
    for _ in range(5):
        check_rate_limit(key, limit=5, window_seconds=60)

    allowed, remaining = check_rate_limit(key, limit=5, window_seconds=60)
    assert not allowed
    assert remaining == 0
    get_redis().delete(f"ratelimit:{key}:60")


def test_different_keys_have_independent_limits():
    key_a = f"test:{uuid.uuid4()}"
    key_b = f"test:{uuid.uuid4()}"

    for _ in range(5):
        check_rate_limit(key_a, limit=5, window_seconds=60)

    allowed_a, _ = check_rate_limit(key_a, limit=5, window_seconds=60)
    allowed_b, _ = check_rate_limit(key_b, limit=5, window_seconds=60)

    assert not allowed_a
    assert allowed_b
    get_redis().delete(f"ratelimit:{key_a}:60", f"ratelimit:{key_b}:60")


def test_fails_open_when_redis_unreachable(monkeypatch):
    """Rate limiting must never take the API down if Redis is unavailable —
    a request that can't be rate-limit-checked should be allowed, not blocked."""
    import redis as redis_module

    class BrokenRedis:
        def incr(self, *a, **kw):
            raise redis_module.RedisError("simulated Redis outage")

    monkeypatch.setattr("core.rate_limit.get_redis", lambda: BrokenRedis())

    allowed, remaining = check_rate_limit("any-key", limit=1, window_seconds=60)
    assert allowed is True
