from engines.ai_engine.llm_gateway import LocalStubProvider, _parse_json_response


def test_parse_json_response_extracts_fields():
    raw = '{"reply": "Here you go", "cited_product_ids": ["a", "b"], "cited_document_chunk_ids": ["c"]}'
    response = _parse_json_response(raw)
    assert response.reply == "Here you go"
    assert response.cited_product_ids == ["a", "b"]
    assert response.cited_document_chunk_ids == ["c"]


def test_parse_json_response_degrades_gracefully_on_malformed_json():
    """A real LLM occasionally ignores the JSON-only instruction. This must
    not crash the request — it should degrade to a plain reply with no
    citations, which the downstream validator then treats as zero citations
    (safe default) rather than raising."""
    raw = "Sorry, I can't help with that in JSON format, but here's my answer: yes."
    response = _parse_json_response(raw)
    assert response.cited_product_ids == []
    assert response.cited_document_chunk_ids == []
    assert "yes" in response.reply


def test_local_stub_provider_extracts_real_ids_from_context():
    provider = LocalStubProvider()
    prompt = (
        "CONTEXT:\n"
        "[PRODUCT id=11111111-1111-1111-1111-111111111111 sku=DK-100] Decking Board: A board (£45.99, in_stock)\n"
        "[PRODUCT id=22222222-2222-2222-2222-222222222222 sku=DK-101] Deck Joist: A joist (£12.50, in_stock)\n"
        "\n\nCUSTOMER QUESTION: what do I need for a deck?"
    )
    response = provider.generate("system", prompt)
    assert "11111111-1111-1111-1111-111111111111" in response.cited_product_ids
    assert "22222222-2222-2222-2222-222222222222" in response.cited_product_ids
    assert len(response.reply) > 0


def test_local_stub_provider_never_cites_ids_not_in_context():
    """Proves the offline stub can't accidentally 'pass' a citation
    validation test by fabricating ids — it can only cite what it actually
    found in the prompt text."""
    provider = LocalStubProvider()
    prompt = "CONTEXT: (nothing relevant found in the catalogue or documentation)\n\nCUSTOMER QUESTION: what do I need?"
    response = provider.generate("system", prompt)
    assert response.cited_product_ids == []
    assert response.cited_document_chunk_ids == []
