from engines.import_engine.mapping import apply_mapping, suggest_mapping
from engines.import_engine.parsers.csv_parser import CSVParser

SAMPLE_CSV = (
    "Item Code,Product Name,Price,Manufacturer,Stock\n"
    "DK-100,Composite Decking Board 3.6m,45.99,TimberTech,In Stock\n"
    "DK-101,Deck Joist 2.4m,,,\n"  # missing price/brand/stock — all optional, should still pass
    ",Missing SKU Product,10.00,BrandX,Yes\n"  # missing SKU — should fail
)


def test_csv_parser_reads_headers_and_rows():
    sheet = CSVParser().parse(SAMPLE_CSV.encode("utf-8"))
    assert sheet.headers == ["Item Code", "Product Name", "Price", "Manufacturer", "Stock"]
    assert len(sheet.rows) == 3


def test_csv_parser_tolerates_ragged_rows():
    """Real merchant spreadsheets have trailing commas / inconsistent column
    counts. csv.DictReader maps overflow columns to a None key and pads
    missing columns with None — both must not crash the parser."""
    ragged_csv = (
        "SKU,Name,Price\n"
        "A1,Widget,5.00,extra,columns\n"  # too many columns
        "A2,Gadget\n"  # too few columns (missing Price)
    )
    sheet = CSVParser().parse(ragged_csv.encode("utf-8"))
    assert len(sheet.rows) == 2
    assert sheet.rows[0]["SKU"] == "A1"
    assert sheet.rows[1]["Price"] == ""  # missing trailing column normalizes to empty string


def test_suggest_mapping_matches_common_synonyms():
    sheet = CSVParser().parse(SAMPLE_CSV.encode("utf-8"))
    mapping = suggest_mapping(sheet.headers)
    assert mapping["sku"] == "Item Code"
    assert mapping["name"] == "Product Name"
    assert mapping["price"] == "Price"
    assert mapping["brand"] == "Manufacturer"
    assert mapping["stock_status"] == "Stock"


def test_apply_mapping_normalizes_and_validates_rows():
    sheet = CSVParser().parse(SAMPLE_CSV.encode("utf-8"))
    mapping = suggest_mapping(sheet.headers)
    rows = apply_mapping(sheet.rows, mapping)

    assert len(rows) == 3
    assert rows[0].is_valid
    assert rows[0].sku == "DK-100"
    assert rows[0].price == 45.99
    assert rows[0].stock_status == "in_stock"

    assert rows[1].is_valid  # optional fields blank is fine
    assert rows[1].price is None

    assert not rows[2].is_valid
    assert "Missing SKU (required)" in rows[2].errors
