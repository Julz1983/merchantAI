"""
Integration tests requiring a real Postgres connection — see
test_kg_repository_integration.py for why.

Run with:
    TEST_DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/merchantai_test \\
        pytest tests/test_basket_integration.py
"""
import os
import uuid

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")

pytestmark = pytest.mark.skipif(not TEST_DATABASE_URL, reason="TEST_DATABASE_URL not set — skipping live-Postgres integration tests")


@pytest.fixture
def merchant_session():
    from core.db import set_tenant_context

    engine = create_engine(TEST_DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()
    merchant_id = uuid.uuid4()

    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Test Merchant', :slug)"), {"id": str(merchant_id), "slug": f"test-{merchant_id}"})
    session.commit()
    set_tenant_context(session, merchant_id)

    yield session, merchant_id

    session.rollback()
    set_tenant_context(session, merchant_id)
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_id)})
    session.commit()
    session.close()
    engine.dispose()


def _make_product(session, merchant_id, sku, name, price):
    from models.catalogue import Product
    product = Product(merchant_id=merchant_id, sku=sku, name=name, price=price, stock_status="in_stock")
    session.add(product)
    session.flush()
    return product


def test_add_item_creates_basket_and_item(merchant_session):
    from engines.commerce_engine.basket_service import add_item, get_basket_view

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 45.99)
    session.commit()

    add_item(session, merchant_id, "session-1", product.id, quantity=2)
    session.commit()

    view = get_basket_view(session, merchant_id, "session-1")
    assert view.item_count == 2
    assert len(view.items) == 1
    assert view.items[0].sku == "DK-100"
    assert view.items[0].quantity == 2
    assert view.subtotal == pytest.approx(91.98)


def test_adding_same_product_twice_increments_quantity_not_duplicates_row(merchant_session):
    from engines.commerce_engine.basket_service import add_item, get_basket_view

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 10.00)
    session.commit()

    add_item(session, merchant_id, "session-1", product.id, quantity=1)
    session.commit()
    add_item(session, merchant_id, "session-1", product.id, quantity=2)
    session.commit()

    view = get_basket_view(session, merchant_id, "session-1")
    assert len(view.items) == 1
    assert view.items[0].quantity == 3


def test_remove_item(merchant_session):
    from engines.commerce_engine.basket_service import add_item, get_basket_view, remove_item

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 10.00)
    session.commit()

    add_item(session, merchant_id, "session-1", product.id)
    session.commit()
    view = get_basket_view(session, merchant_id, "session-1")
    item_id = uuid.UUID(view.items[0].id)

    remove_item(session, merchant_id, "session-1", item_id)
    session.commit()

    view_after = get_basket_view(session, merchant_id, "session-1")
    assert view_after.items == []
    assert view_after.item_count == 0


def test_update_item_quantity(merchant_session):
    from engines.commerce_engine.basket_service import add_item, get_basket_view, update_item_quantity

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 10.00)
    session.commit()

    add_item(session, merchant_id, "session-1", product.id, quantity=1)
    session.commit()
    view = get_basket_view(session, merchant_id, "session-1")
    item_id = uuid.UUID(view.items[0].id)

    update_item_quantity(session, merchant_id, "session-1", item_id, 5)
    session.commit()

    view_after = get_basket_view(session, merchant_id, "session-1")
    assert view_after.items[0].quantity == 5
    assert view_after.subtotal == pytest.approx(50.00)


def test_subtotal_has_no_floating_point_imprecision(merchant_session):
    """Regression test for a real bug found via live testing: 45.99 * 5 in
    plain float arithmetic produces 229.95000000000002, not 229.95 — which
    would display an ugly, wrong-looking number to a customer. Values must
    be rounded to 2 decimal places, not returned raw from float math."""
    from engines.commerce_engine.basket_service import add_item, get_basket_view

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 45.99)
    session.commit()

    add_item(session, merchant_id, "session-1", product.id, quantity=5)
    session.commit()

    view = get_basket_view(session, merchant_id, "session-1")
    assert view.items[0].line_total == 229.95  # exact equality, not approx — proves it's actually rounded
    assert view.subtotal == 229.95


def test_cannot_remove_another_sessions_item(merchant_session):
    """A basket item id from session-1's basket must not be removable via
    session-2 — the item belongs to a specific anonymous session, not just
    a merchant."""
    from engines.commerce_engine.basket_service import BasketError, add_item, get_basket_view, remove_item

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 10.00)
    session.commit()

    add_item(session, merchant_id, "session-1", product.id)
    session.commit()
    view = get_basket_view(session, merchant_id, "session-1")
    item_id = uuid.UUID(view.items[0].id)

    with pytest.raises(BasketError):
        remove_item(session, merchant_id, "session-2", item_id)


def test_basket_isolated_per_merchant(merchant_session):
    """Same tenant-isolation principle as every other feature — a second
    merchant's basket lookups must never see the first merchant's items,
    even with the same session_id string (a real possibility since session
    ids are client-generated, not globally unique)."""
    from core.db import set_tenant_context
    from engines.commerce_engine.basket_service import add_item, get_basket_view

    session, merchant_a = merchant_session
    product = _make_product(session, merchant_a, "DK-100", "Decking Board", 10.00)
    session.commit()
    add_item(session, merchant_a, "shared-session-id", product.id)
    session.commit()

    merchant_b = uuid.uuid4()
    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Merchant B', :slug)"), {"id": str(merchant_b), "slug": f"test-b-{merchant_b}"})
    session.commit()
    set_tenant_context(session, merchant_b)

    view_b = get_basket_view(session, merchant_b, "shared-session-id")
    assert view_b.items == []

    set_tenant_context(session, merchant_a)
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_b)})
    session.commit()


def test_add_item_rejects_product_from_another_merchant(merchant_session):
    """A product id belonging to a different merchant must be rejected, not
    silently added — otherwise a malicious/buggy client could add another
    tenant's product into this merchant's basket by guessing a UUID."""
    from core.db import set_tenant_context
    from engines.commerce_engine.basket_service import BasketError, add_item

    session, merchant_a = merchant_session

    merchant_b = uuid.uuid4()
    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Merchant B', :slug)"), {"id": str(merchant_b), "slug": f"test-b-{merchant_b}"})
    session.commit()
    set_tenant_context(session, merchant_b)
    other_product = _make_product(session, merchant_b, "OTHER-1", "Someone else's product", 5.00)
    session.commit()

    set_tenant_context(session, merchant_a)
    with pytest.raises(BasketError):
        add_item(session, merchant_a, "session-1", other_product.id)

    set_tenant_context(session, merchant_b)
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_b)})
    session.commit()
    set_tenant_context(session, merchant_a)
