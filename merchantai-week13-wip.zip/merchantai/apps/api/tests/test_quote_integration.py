"""
Integration tests requiring a real Postgres connection.

Run with:
    TEST_DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/merchantai_test \\
        pytest tests/test_quote_integration.py
"""
import os
import uuid
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")

pytestmark = pytest.mark.skipif(not TEST_DATABASE_URL, reason="TEST_DATABASE_URL not set — skipping live-Postgres integration tests")


@pytest.fixture
def merchant_session():
    from core.db import set_tenant_context

    engine = create_engine(TEST_DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()
    merchant_id = uuid.uuid4()

    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Test Merchant', :slug)"), {"id": str(merchant_id), "slug": f"test-{merchant_id}"})
    session.commit()
    set_tenant_context(session, merchant_id)

    yield session, merchant_id

    session.rollback()
    set_tenant_context(session, merchant_id)
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_id)})
    session.commit()
    session.close()
    engine.dispose()


def _make_product(session, merchant_id, sku, name, price):
    from models.catalogue import Product
    product = Product(merchant_id=merchant_id, sku=sku, name=name, price=price, stock_status="in_stock")
    session.add(product)
    session.flush()
    return product


def test_create_quote_snapshots_basket(merchant_session):
    from engines.commerce_engine.basket_service import add_item
    from engines.commerce_engine.quote_service import create_quote_from_basket

    session, merchant_id = merchant_session
    p1 = _make_product(session, merchant_id, "DK-100", "Decking Board", 45.99)
    p2 = _make_product(session, merchant_id, "DK-101", "Joist", 12.50)
    session.commit()

    add_item(session, merchant_id, "s1", p1.id, quantity=5)
    add_item(session, merchant_id, "s1", p2.id, quantity=2)
    session.commit()

    quote = create_quote_from_basket(session, merchant_id, "s1")
    session.commit()

    assert quote.reference_number.startswith("Q-")
    assert len(quote.items) == 2
    assert quote.subtotal == 254.95  # 229.95 + 25.00, exact — no float imprecision
    assert quote.status == "draft"
    assert not quote.is_expired


def test_quote_prices_are_frozen_after_product_price_changes(merchant_session):
    """The whole point of a quote: it holds the price quoted at the time,
    even if the merchant later changes the product's price."""
    from engines.commerce_engine.basket_service import add_item
    from engines.commerce_engine.quote_service import create_quote_from_basket, get_quote_by_reference

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 10.00)
    session.commit()
    add_item(session, merchant_id, "s1", product.id, quantity=3)
    session.commit()

    quote = create_quote_from_basket(session, merchant_id, "s1")
    session.commit()

    product.price = 99.99
    session.commit()

    fetched = get_quote_by_reference(session, merchant_id, quote.reference_number)
    assert fetched.items[0].unit_price == 10.00
    assert fetched.subtotal == 30.00


def test_quote_survives_product_deletion(merchant_session):
    from engines.commerce_engine.basket_service import add_item
    from engines.commerce_engine.quote_service import create_quote_from_basket, get_quote_by_reference

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 10.00)
    session.commit()
    add_item(session, merchant_id, "s1", product.id)
    session.commit()
    quote = create_quote_from_basket(session, merchant_id, "s1")
    session.commit()

    session.delete(product)
    session.commit()

    fetched = get_quote_by_reference(session, merchant_id, quote.reference_number)
    assert fetched.items[0].name == "Decking Board"  # snapshotted, not joined live


def test_empty_basket_rejected(merchant_session):
    from engines.commerce_engine.quote_service import QuoteError, create_quote_from_basket

    session, merchant_id = merchant_session
    with pytest.raises(QuoteError, match="empty basket"):
        create_quote_from_basket(session, merchant_id, "no-basket-session")


def test_unpriced_item_rejected(merchant_session):
    from engines.commerce_engine.basket_service import add_item
    from engines.commerce_engine.quote_service import QuoteError, create_quote_from_basket

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "NP-1", "No Price Item", None)
    session.commit()
    add_item(session, merchant_id, "s1", product.id)
    session.commit()

    with pytest.raises(QuoteError, match="price"):
        create_quote_from_basket(session, merchant_id, "s1")


def test_expired_quote_flagged(merchant_session):
    from engines.commerce_engine.basket_service import add_item
    from engines.commerce_engine.quote_service import create_quote_from_basket, get_quote_by_reference
    from models.quote import Quote
    from sqlalchemy import select

    session, merchant_id = merchant_session
    product = _make_product(session, merchant_id, "DK-100", "Decking Board", 10.00)
    session.commit()
    add_item(session, merchant_id, "s1", product.id)
    session.commit()
    view = create_quote_from_basket(session, merchant_id, "s1")
    session.commit()

    q = session.scalar(select(Quote).where(Quote.merchant_id == merchant_id, Quote.reference_number == view.reference_number))
    q.expires_at = datetime.now(timezone.utc) - timedelta(days=1)
    session.commit()

    assert get_quote_by_reference(session, merchant_id, view.reference_number).is_expired


def test_quotes_isolated_per_merchant(merchant_session):
    from core.db import set_tenant_context
    from engines.commerce_engine.basket_service import add_item
    from engines.commerce_engine.quote_service import QuoteError, create_quote_from_basket, get_quote_by_reference

    session, merchant_a = merchant_session
    product = _make_product(session, merchant_a, "DK-100", "Decking Board", 10.00)
    session.commit()
    add_item(session, merchant_a, "s1", product.id)
    session.commit()
    view = create_quote_from_basket(session, merchant_a, "s1")
    session.commit()

    merchant_b = uuid.uuid4()
    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'B', :slug)"), {"id": str(merchant_b), "slug": f"test-b-{merchant_b}"})
    session.commit()
    set_tenant_context(session, merchant_b)

    with pytest.raises(QuoteError, match="not found"):
        get_quote_by_reference(session, merchant_b, view.reference_number)

    set_tenant_context(session, merchant_a)
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_b)})
    session.commit()
