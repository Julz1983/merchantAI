"""
Integration tests requiring a real Postgres connection — see
test_kg_repository_integration.py for why (SQL-dialect bugs only surface
against a live DB).

Run with:
    TEST_DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/merchantai_test \\
        pytest tests/test_analytics_integration.py
"""
import os
import uuid

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")

pytestmark = pytest.mark.skipif(not TEST_DATABASE_URL, reason="TEST_DATABASE_URL not set — skipping live-Postgres integration tests")


@pytest.fixture
def merchant_session():
    from core.db import set_tenant_context

    engine = create_engine(TEST_DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()
    merchant_id = uuid.uuid4()

    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Test Merchant', :slug)"), {"id": str(merchant_id), "slug": f"test-{merchant_id}"})
    session.commit()
    set_tenant_context(session, merchant_id)

    yield session, merchant_id

    session.rollback()
    set_tenant_context(session, merchant_id)
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_id)})
    session.commit()
    session.close()
    engine.dispose()


def test_record_event_and_summary_counts(merchant_session):
    from engines.analytics_engine.event_ingest import record_event
    from models.analytics import AnalyticsEvent
    from sqlalchemy import select

    session, merchant_id = merchant_session

    record_event(session, merchant_id, "question", {"message": "what decking do you have?"})
    record_event(session, merchant_id, "question", {"message": "do you sell paint?"})
    record_event(session, merchant_id, "product_missing", {"question": "do you sell paint?"})
    record_event(session, merchant_id, "recommendation", {"product_id": "abc", "sku": "DK-100"})
    session.commit()

    events = session.scalars(select(AnalyticsEvent).where(AnalyticsEvent.merchant_id == merchant_id)).all()
    assert len(events) == 4

    by_type = {}
    for e in events:
        by_type[e.event_type] = by_type.get(e.event_type, 0) + 1
    assert by_type["question"] == 2
    assert by_type["product_missing"] == 1
    assert by_type["recommendation"] == 1


def test_chat_turn_records_expected_events_end_to_end(merchant_session):
    """Full integration: a real chat turn through handle_chat_turn should
    produce a 'question' event and, since no products/documents exist for
    this merchant, a 'product_missing' event — proving the event recording
    is actually wired into the real chat flow, not just callable in isolation."""
    from engines.ai_engine.chat_service import handle_chat_turn
    from models.analytics import AnalyticsEvent
    from models.merchant import Merchant
    from sqlalchemy import select

    session, merchant_id = merchant_session
    merchant = session.get(Merchant, merchant_id)

    handle_chat_turn(session, merchant, merchant_id, "test-session", "do you sell rocket engines?")

    events = session.scalars(select(AnalyticsEvent).where(AnalyticsEvent.merchant_id == merchant_id)).all()
    event_types = {e.event_type for e in events}
    assert "question" in event_types
    assert "product_missing" in event_types


def test_missing_query_aggregation_groups_correctly(merchant_session):
    """Directly exercises the same aggregation logic routers/analytics.py
    uses for top_missing_queries, proving repeated questions (even with
    different casing) group into one count."""
    from collections import Counter

    from engines.analytics_engine.event_ingest import record_event
    from models.analytics import AnalyticsEvent
    from sqlalchemy import select

    session, merchant_id = merchant_session
    record_event(session, merchant_id, "product_missing", {"question": "Do you sell rocket engines?"})
    record_event(session, merchant_id, "product_missing", {"question": "do you sell rocket engines?"})
    record_event(session, merchant_id, "product_missing", {"question": "do you sell paint?"})
    session.commit()

    payloads = session.scalars(
        select(AnalyticsEvent.payload).where(AnalyticsEvent.merchant_id == merchant_id, AnalyticsEvent.event_type == "product_missing")
    ).all()
    counts = Counter(p.get("question", "").strip().lower() for p in payloads if p.get("question"))

    assert counts["do you sell rocket engines?"] == 2
    assert counts["do you sell paint?"] == 1
