from engines.knowledge_engine.llm_extraction import LocalKeywordExtractionProvider, ProductSummary

DECKING = ProductSummary(id="p1", sku="DK-100", name="Composite Decking Board 3.6m", description="Premium composite decking board for outdoor use", category="Decking")
JOIST = ProductSummary(id="p2", sku="DK-101", name="Deck Joist 2.4m", description="Pressure treated timber joist for deck substructure", category="Decking")
FIXING_CLIP = ProductSummary(id="p3", sku="FX-200", name="Hidden Fixing Clips (Pack of 100)", description="Stainless steel hidden fixing clips", category="Decking")
UNRELATED = ProductSummary(id="p4", sku="PT-900", name="Emulsion Paint 5L", description="Interior matte white emulsion paint", category="Paint")


def test_same_category_products_proposed_as_alternatives():
    provider = LocalKeywordExtractionProvider()
    candidates = provider.propose_edges([DECKING, JOIST, FIXING_CLIP, UNRELATED])

    alternatives = [c for c in candidates if c.relationship_type == "ALTERNATIVE"]
    pairs = {frozenset([c.source_product_id, c.target_product_id]) for c in alternatives}

    # All three decking-category products should be proposed as alternatives to each other
    assert frozenset(["p1", "p2"]) in pairs
    assert frozenset(["p1", "p3"]) in pairs
    assert frozenset(["p2", "p3"]) in pairs
    # The paint product (different category) should never appear
    assert not any("p4" in pair for pair in pairs)


def test_requires_keyword_detected():
    provider = LocalKeywordExtractionProvider()
    candidates = provider.propose_edges([DECKING, JOIST])

    requires = [c for c in candidates if c.relationship_type == "REQUIRES"]
    assert any(c.source_product_id == "p1" and c.target_product_id == "p2" for c in requires)
    # The joist itself (a component) shouldn't be proposed as a REQUIRES source
    assert not any(c.source_product_id == "p2" and c.relationship_type == "REQUIRES" for c in requires)


def test_accessory_keyword_detected():
    provider = LocalKeywordExtractionProvider()
    candidates = provider.propose_edges([DECKING, FIXING_CLIP])

    accessories = [c for c in candidates if c.relationship_type == "ACCESSORY"]
    assert any(c.source_product_id == "p1" and c.target_product_id == "p3" for c in accessories)


def test_unrelated_products_produce_no_keyword_edges():
    provider = LocalKeywordExtractionProvider()
    candidates = provider.propose_edges([DECKING, UNRELATED])

    keyword_edges = [c for c in candidates if c.relationship_type in ("REQUIRES", "ACCESSORY")]
    assert keyword_edges == []


def test_all_candidates_have_evidence_and_valid_confidence():
    provider = LocalKeywordExtractionProvider()
    candidates = provider.propose_edges([DECKING, JOIST, FIXING_CLIP, UNRELATED])
    for c in candidates:
        assert c.evidence  # every candidate must be explainable in the review UI
        assert 0.0 <= c.confidence <= 1.0
