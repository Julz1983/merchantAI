"""
Integration tests requiring a real Postgres connection — see
test_kg_repository_integration.py for why these are separate from the
pure-Python unit tests (SQL-dialect bugs only surface against a live DB).

Run with:
    TEST_DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/merchantai_test \\
        pytest tests/test_rag_pipeline_integration.py
"""
import os
import uuid

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")

pytestmark = pytest.mark.skipif(not TEST_DATABASE_URL, reason="TEST_DATABASE_URL not set — skipping live-Postgres integration tests")


@pytest.fixture
def merchant_session():
    from core.db import set_tenant_context

    engine = create_engine(TEST_DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()
    merchant_id = uuid.uuid4()

    session.execute(
        text("INSERT INTO merchants (id, name, slug, ai_persona) VALUES (:id, 'Test Merchant', :slug, :persona)"),
        {"id": str(merchant_id), "slug": f"test-{merchant_id}", "persona": '{"tone": "formal"}'},
    )
    session.commit()
    set_tenant_context(session, merchant_id)

    yield session, merchant_id

    session.rollback()
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_id)})
    session.commit()
    session.close()


def _make_product(session, merchant_id, sku, name, description, category_id=None):
    from models.catalogue import Product
    product = Product(merchant_id=merchant_id, sku=sku, name=name, description=description, category_id=category_id, price=10.0, stock_status="in_stock")
    session.add(product)
    session.flush()
    return product


def test_full_pipeline_answers_with_valid_citations(merchant_session):
    """
    End-to-end: two products in the DB, indexed into the vector store,
    linked by a KG REQUIRES edge -> ask a question -> get back a reply whose
    citations are real ids that trace back to the actual retrieved products.
    Uses the offline local embedding provider and LocalStubProvider (no
    OPENAI_API_KEY set in the test env), which is a legitimate way to prove
    the plumbing works end-to-end even though it doesn't prove answer
    *quality* — see llm_gateway.py / embeddings.py docstrings.
    """
    from engines.ai_engine.product_indexing import index_products
    from engines.ai_engine.rag_pipeline import answer_question
    from engines.knowledge_engine.kg_repository import create_edge_if_new, get_or_create_node
    from models.merchant import Merchant

    session, merchant_id = merchant_session

    decking = _make_product(session, merchant_id, "DK-100", "Composite Decking Board", "A premium composite decking board for outdoor gardens")
    joist = _make_product(session, merchant_id, "DK-101", "Deck Joist", "A pressure treated timber joist for deck substructure")
    session.commit()

    decking_node = get_or_create_node(session, merchant_id, "PRODUCT", decking.name, ref_id=decking.id)
    joist_node = get_or_create_node(session, merchant_id, "PRODUCT", joist.name, ref_id=joist.id)
    create_edge_if_new(session, merchant_id, decking_node.id, joist_node.id, "REQUIRES", source="manual", status="approved")
    session.commit()

    index_products(session, merchant_id)

    merchant = session.get(Merchant, merchant_id)
    response = answer_question(session, merchant, "I want to build a raised deck, what do I need?")

    # Every citation the pipeline returns must be a real product id from the DB.
    real_ids = {str(decking.id), str(joist.id)}
    for cited_id in response.cited_product_ids:
        assert cited_id in real_ids, f"cited an id that doesn't correspond to a real product: {cited_id}"

    # The KG-linked joist should have been pulled into context (and likely
    # cited) precisely because of the REQUIRES edge, not just vector search.
    assert len(response.reply) > 0


def test_citation_validation_strips_fabricated_ids(merchant_session):
    """Directly proves the grounding enforcement: even if the LLM (or a
    misbehaving provider) returns an id that was never in the retrieved
    context, the pipeline must not pass it through."""
    from unittest.mock import patch

    from engines.ai_engine.llm_gateway import LLMResponse
    from engines.ai_engine.rag_pipeline import answer_question
    from models.merchant import Merchant

    session, merchant_id = merchant_session
    _make_product(session, merchant_id, "DK-100", "Composite Decking Board", "A decking board")
    session.commit()

    from engines.ai_engine.product_indexing import index_products
    index_products(session, merchant_id)

    fabricated_id = str(uuid.uuid4())
    fake_response = LLMResponse(reply="Here's a fake product", cited_product_ids=[fabricated_id], cited_document_chunk_ids=["also-fake"])

    with patch("engines.ai_engine.rag_pipeline.get_llm_provider") as mock_get_provider:
        mock_provider = mock_get_provider.return_value
        mock_provider.generate.return_value = fake_response

        merchant = session.get(Merchant, merchant_id)
        response = answer_question(session, merchant, "any question")

    assert fabricated_id not in response.cited_product_ids
    assert "also-fake" not in response.cited_document_chunk_ids
    assert response.cited_product_ids == []
    assert response.suggested_products == []


def test_retrieval_is_isolated_per_merchant(merchant_session):
    """A second merchant's question must never retrieve the first merchant's
    products — same tenant-isolation principle, applied to the RAG pipeline."""
    from core.db import set_tenant_context
    from engines.ai_engine.product_indexing import index_products
    from engines.knowledge_engine.hybrid_retrieval import hybrid_retrieve

    session, merchant_a = merchant_session
    _make_product(session, merchant_a, "DK-100", "Composite Decking Board", "A decking board for gardens")
    session.commit()
    index_products(session, merchant_a)

    merchant_b = uuid.uuid4()
    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Merchant B', :slug)"), {"id": str(merchant_b), "slug": f"test-b-{merchant_b}"})
    session.commit()
    set_tenant_context(session, merchant_b)

    context = hybrid_retrieve(session, merchant_b, "decking board for gardens")
    assert context.products == []

    set_tenant_context(session, merchant_a)
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_b)})
    session.commit()
