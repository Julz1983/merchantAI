"""
Integration tests requiring a real Postgres connection — these exist because
a real bug (SQLAlchemy's text() misparsing `:param::uuid`, the Postgres cast
operator with no space before it) only surfaced against a live database, not
in pure-Python unit tests or against the app's fake DATABASE_URL used for
routing/import tests.

Run with a real database:
    TEST_DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/merchantai_test \\
        pytest tests/test_kg_repository_integration.py

Skipped automatically if TEST_DATABASE_URL isn't set (e.g. the default
`pytest tests/` run in this repo, which uses a fake DATABASE_URL that's never
actually connected to) — CI should set it via the docker-compose Postgres
service.
"""
import os
import uuid

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")

pytestmark = pytest.mark.skipif(not TEST_DATABASE_URL, reason="TEST_DATABASE_URL not set — skipping live-Postgres integration tests")


@pytest.fixture
def db_session():
    from core.db import set_tenant_context

    engine = create_engine(TEST_DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()
    merchant_id = uuid.uuid4()

    # These tests run against whatever schema TEST_DATABASE_URL points at —
    # they assume migrations have already been applied (alembic upgrade head).
    session.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Test', :slug)"), {"id": str(merchant_id), "slug": f"test-{merchant_id}"})
    session.commit()
    set_tenant_context(session, merchant_id)

    yield session, merchant_id

    session.rollback()
    session.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_id)})
    session.commit()
    session.close()


def test_get_neighborhood_recursive_cte_runs_without_syntax_error(db_session):
    """Regression test for the :start_id::uuid parsing bug — this is
    specifically testing that the SQL is valid, not just that the logic is
    right, since the bug that motivated this test passed logic review and
    only failed at actual query execution time."""
    from engines.knowledge_engine.kg_repository import create_edge_if_new, get_neighborhood, get_or_create_node

    session, merchant_id = db_session

    product_a = get_or_create_node(session, merchant_id, "PRODUCT", "Decking Board", ref_id=uuid.uuid4())
    product_b = get_or_create_node(session, merchant_id, "PRODUCT", "Deck Joist", ref_id=uuid.uuid4())
    create_edge_if_new(session, merchant_id, product_a.id, product_b.id, "REQUIRES", source="manual", status="approved")
    session.commit()

    result = get_neighborhood(session, merchant_id, product_a.id, depth=2)

    node_labels = {n.label for n in result["nodes"]}
    assert "Decking Board" in node_labels
    assert "Deck Joist" in node_labels
    assert len(result["edges"]) == 1
    assert result["edges"][0].relationship_type == "REQUIRES"


def test_get_neighborhood_respects_depth_limit(db_session):
    """A -> B -> C chain: depth=1 from A should see B but not C."""
    from engines.knowledge_engine.kg_repository import create_edge_if_new, get_neighborhood, get_or_create_node

    session, merchant_id = db_session

    a = get_or_create_node(session, merchant_id, "PRODUCT", "A", ref_id=uuid.uuid4())
    b = get_or_create_node(session, merchant_id, "PRODUCT", "B", ref_id=uuid.uuid4())
    c = get_or_create_node(session, merchant_id, "PRODUCT", "C", ref_id=uuid.uuid4())
    create_edge_if_new(session, merchant_id, a.id, b.id, "REQUIRES", source="manual", status="approved")
    create_edge_if_new(session, merchant_id, b.id, c.id, "REQUIRES", source="manual", status="approved")
    session.commit()

    result_depth1 = get_neighborhood(session, merchant_id, a.id, depth=1)
    labels_depth1 = {n.label for n in result_depth1["nodes"]}
    assert labels_depth1 == {"A", "B"}

    result_depth2 = get_neighborhood(session, merchant_id, a.id, depth=2)
    labels_depth2 = {n.label for n in result_depth2["nodes"]}
    assert labels_depth2 == {"A", "B", "C"}


def test_get_neighborhood_excludes_unapproved_edges_by_default(db_session):
    from engines.knowledge_engine.kg_repository import create_edge_if_new, get_neighborhood, get_or_create_node

    session, merchant_id = db_session

    a = get_or_create_node(session, merchant_id, "PRODUCT", "A", ref_id=uuid.uuid4())
    b = get_or_create_node(session, merchant_id, "PRODUCT", "B", ref_id=uuid.uuid4())
    create_edge_if_new(session, merchant_id, a.id, b.id, "REQUIRES", source="llm_extracted", status="pending")
    session.commit()

    result = get_neighborhood(session, merchant_id, a.id, depth=2, only_approved=True)
    assert result["edges"] == []

    result_all = get_neighborhood(session, merchant_id, a.id, depth=2, only_approved=False)
    assert len(result_all["edges"]) == 1


def test_unscoped_lookup_carveout_survives_connection_reuse():
    """
    Regression test for a real bug: Postgres returns NULL for
    current_setting('app.custom_var', true) on a connection that has never
    touched that GUC, but '' (empty string, not NULL) on a connection that
    HAS touched it before, even after the transaction that set it ends
    (commit or rollback) — for the rest of that physical connection's
    lifetime. A carve-out that only checks `IS NULL` (as this project
    shipped for one migration) works on a fresh connection and then breaks
    on every subsequent request that reuses a pooled connection, because
    reuse is the norm. This must check both NULL and ''.
    """
    from core.db import set_tenant_context
    from sqlalchemy import text

    engine = create_engine(TEST_DATABASE_URL)
    LocalSession = sessionmaker(bind=engine)
    merchant_id = uuid.uuid4()

    # First use of a connection: touches the GUC, commits (this is what
    # get_tenant_db/get_widget_context do on every real request).
    db1 = LocalSession()
    set_tenant_context(db1, merchant_id)
    db1.commit()
    db1.close()

    # A second, independent session may check out the SAME pooled physical
    # connection — its "unset" state now reads as '' rather than NULL.
    db2 = LocalSession()
    value = db2.execute(text("SELECT current_setting('app.current_merchant_id', true)")).scalar()
    db2.close()
    engine.dispose()

    assert value == "" or value is None, (
        f"Expected the reverted GUC to read as '' or NULL, got {value!r} — "
        "if this assertion itself starts failing, Postgres's behavior here "
        "has changed and the carve-out policies (migration 0008) need review."
    )


def test_widget_api_key_lookup_succeeds_across_repeated_requests():
    """Same root cause as the test above, exercised through the actual
    production code path (core.api_keys + the ApiKey model + the RLS policy
    together) rather than a raw SQL check — this is what would have caught
    the bug at the right layer, since the raw-SQL test above only proves the
    Postgres behavior, not that our lookup query is written correctly
    against it."""
    from core.api_keys import generate_api_key, hash_api_key
    from core.db import set_tenant_context
    from models.api_key import ApiKey
    from sqlalchemy import select, text

    engine = create_engine(TEST_DATABASE_URL)
    LocalSession = sessionmaker(bind=engine)
    merchant_id = uuid.uuid4()

    db = LocalSession()
    db.execute(text("INSERT INTO merchants (id, name, slug) VALUES (:id, 'Test', :slug)"), {"id": str(merchant_id), "slug": f"test-{merchant_id}"})
    db.commit()
    set_tenant_context(db, merchant_id)

    plaintext, key_hash, prefix = generate_api_key()
    db.add(ApiKey(merchant_id=merchant_id, key_hash=key_hash, display_prefix=prefix, label="test", scopes=["widget"]))
    db.commit()
    db.close()

    def lookup_key() -> bool:
        """Mirrors get_widget_context's lookup exactly: fresh unscoped
        session, select by hash — no set_tenant_context call before the
        SELECT, since the whole point is this runs before we know the
        merchant."""
        lookup_db = LocalSession()
        try:
            found = lookup_db.scalar(select(ApiKey).where(ApiKey.key_hash == hash_api_key(plaintext)))
            return found is not None
        finally:
            lookup_db.close()

    # Simulate several sequential requests reusing pooled connections —
    # every one must succeed, not just the first.
    results = [lookup_key() for _ in range(5)]

    db = LocalSession()
    set_tenant_context(db, merchant_id)
    db.execute(text("DELETE FROM merchants WHERE id = :id"), {"id": str(merchant_id)})
    db.commit()
    db.close()
    engine.dispose()

    assert all(results), f"API key lookup failed on some requests: {results}"
