from unittest.mock import MagicMock

import pytest

from engines.commerce_engine.quantity_calculator import (
    QuantityCalculatorError, calculate_units_for_area, get_coverage_per_unit_m2,
)


def _product(sku="SKU-1", name="Test Product", specifications=None):
    p = MagicMock()
    p.id = "11111111-1111-1111-1111-111111111111"
    p.sku = sku
    p.name = name
    p.specifications = specifications or {}
    return p


class TestGetCoveragePerUnit:
    def test_direct_coverage_plain(self):
        """'Approx 60m2' — paint, one tin covers 60m2."""
        product = _product(specifications={"Coverage": "Approx 60m2"})
        coverage, basis = get_coverage_per_unit_m2(product)
        assert coverage == 60.0
        assert "coverage per unit" in basis

    def test_direct_coverage_with_pack_suffix(self):
        """'5.76m2/pack' — the m2 comes right after the number, so this is
        still a direct area-per-unit value; '/pack' just names the unit."""
        product = _product(specifications={"Coverage": "5.76m2/pack"})
        coverage, basis = get_coverage_per_unit_m2(product)
        assert coverage == 5.76

    def test_inverse_coverage_units_per_area(self):
        """'Approx 10 tiles/m2' — each tile covers 1/10 m2, not 10m2."""
        product = _product(specifications={"Coverage": "Approx 10 tiles/m2"})
        coverage, basis = get_coverage_per_unit_m2(product)
        assert coverage == pytest.approx(0.1)
        assert "units per m²" in basis

    def test_derived_from_length_and_width_meters(self):
        product = _product(specifications={"Length": "3.6m", "Width": "150mm"})
        coverage, basis = get_coverage_per_unit_m2(product)
        assert coverage == pytest.approx(3.6 * 0.15)
        assert "per unit" in basis

    def test_derived_from_length_and_width_mixed_units(self):
        product = _product(specifications={"Length": "1m", "Width": "50cm"})
        coverage, basis = get_coverage_per_unit_m2(product)
        assert coverage == pytest.approx(1 * 0.5)

    def test_no_usable_specs_returns_none(self):
        """A joist with only Length and Cross-section (no Width, no
        Coverage) — matches the real seed data for DK-102 exactly. There's
        genuinely not enough information to compute an area, and this must
        return None rather than guessing."""
        product = _product(specifications={"Length": "2.4m", "Cross-section": "47x150mm"})
        assert get_coverage_per_unit_m2(product) is None

    def test_empty_specs_returns_none(self):
        product = _product(specifications={})
        assert get_coverage_per_unit_m2(product) is None

    def test_coverage_key_case_insensitive_and_partial_match(self):
        product = _product(specifications={"coverage area": "Approx 40m2"})
        coverage, _ = get_coverage_per_unit_m2(product)
        assert coverage == 40.0


class TestCalculateUnitsForArea:
    def test_decking_board_calculation(self):
        """Matches the real DK-100 seed product: 3.6m x 150mm board."""
        product = _product(sku="DK-100", name="Composite Decking Board 3.6m", specifications={"Length": "3.6m", "Width": "150mm"})
        result = calculate_units_for_area(product, area_m2=20.0)

        # coverage per board = 3.6 * 0.15 = 0.54 m2
        # with 10% waste: 20 * 1.1 = 22 m2 -> 22 / 0.54 = 40.74 -> ceil = 41
        assert result.units_needed == 41
        assert result.coverage_per_unit_m2 == pytest.approx(0.54)

    def test_paint_calculation(self):
        product = _product(sku="PT-600", name="Weathershield Exterior Paint 5L", specifications={"Coverage": "Approx 60m2"})
        result = calculate_units_for_area(product, area_m2=100.0, waste_factor=0.0)
        # no waste: 100 / 60 = 1.67 -> ceil = 2
        assert result.units_needed == 2

    def test_roof_tile_inverse_coverage_calculation(self):
        product = _product(sku="RF-400", name="Concrete Roof Tile", specifications={"Coverage": "Approx 10 tiles/m2"})
        result = calculate_units_for_area(product, area_m2=15.0, waste_factor=0.0)
        # 10 tiles/m2 * 15 m2 = 150 tiles exactly
        assert result.units_needed == 150

    def test_default_waste_factor_is_ten_percent(self):
        product = _product(specifications={"Coverage": "Approx 10m2"})
        result = calculate_units_for_area(product, area_m2=10.0)
        assert result.waste_factor == 0.10
        # 10 * 1.1 = 11 / 10 = 1.1 -> ceil = 2
        assert result.units_needed == 2

    def test_zero_area_rejected(self):
        product = _product(specifications={"Coverage": "Approx 10m2"})
        with pytest.raises(QuantityCalculatorError, match="greater than zero"):
            calculate_units_for_area(product, area_m2=0)

    def test_negative_area_rejected(self):
        product = _product(specifications={"Coverage": "Approx 10m2"})
        with pytest.raises(QuantityCalculatorError):
            calculate_units_for_area(product, area_m2=-5.0)

    def test_negative_waste_factor_rejected(self):
        product = _product(specifications={"Coverage": "Approx 10m2"})
        with pytest.raises(QuantityCalculatorError, match="negative"):
            calculate_units_for_area(product, area_m2=10.0, waste_factor=-0.1)

    def test_insufficient_specs_raises_actionable_error(self):
        """A joist (real DK-102-style specs) has no area basis — must fail
        with a message that explains why, not a generic error."""
        product = _product(name="Deck Joist 2.4m", specifications={"Length": "2.4m", "Cross-section": "47x150mm"})
        with pytest.raises(QuantityCalculatorError, match="Not enough specification data"):
            calculate_units_for_area(product, area_m2=20.0)

    def test_result_includes_original_product_identity(self):
        product = _product(sku="DK-100", name="Composite Decking Board", specifications={"Coverage": "Approx 10m2"})
        result = calculate_units_for_area(product, area_m2=5.0)
        assert result.sku == "DK-100"
        assert result.name == "Composite Decking Board"
        assert result.area_m2 == 5.0
