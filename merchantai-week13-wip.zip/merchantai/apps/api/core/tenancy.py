from datetime import datetime, timezone
from uuid import UUID

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.api_keys import hash_api_key
from core.db import SessionLocal, set_tenant_context
from core.security import decode_token

bearer_scheme = HTTPBearer(auto_error=False)


class CurrentUser:
    """Resolved identity for the current request — attached to every tenant-scoped route."""

    def __init__(self, user_id: UUID, merchant_id: UUID, role: str):
        self.user_id = user_id
        self.merchant_id = merchant_id
        self.role = role


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> CurrentUser:
    if credentials is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing bearer token")
    try:
        payload = decode_token(credentials.credentials)
    except JWTError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token") from exc

    if payload.type != "access":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Refresh token used where access token required")

    return CurrentUser(
        user_id=UUID(payload.sub),
        merchant_id=UUID(payload.merchant_id),
        role=payload.role,
    )


def get_tenant_db(current_user: CurrentUser = Depends(get_current_user)) -> Session:
    """
    Every tenant-scoped route depends on this instead of the plain get_db.
    It opens a session, sets the RLS session variable for this request's
    merchant, and yields — so every query on this session is automatically
    scoped, even if a route forgets an explicit merchant_id filter.
    """
    db = SessionLocal()
    try:
        set_tenant_context(db, current_user.merchant_id)
        yield db
    finally:
        db.close()


def require_role(*allowed_roles: str):
    """Route-level guard, e.g. Depends(require_role('owner', 'admin'))."""

    def _check(current_user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if current_user.role not in allowed_roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Insufficient permissions")
        return current_user

    return _check


class WidgetContext:
    """Resolved identity for a widget (API-key-authed) request — deliberately
    thinner than CurrentUser: no user_id/role, since these requests come from
    anonymous website visitors, not a logged-in merchant staff member."""

    def __init__(self, merchant_id: UUID, api_key_id: UUID, scopes: list[str]):
        self.merchant_id = merchant_id
        self.api_key_id = api_key_id
        self.scopes = scopes


def get_widget_context(x_api_key: str | None = Header(None)) -> WidgetContext:
    """
    Widget-facing auth (architecture §13: "widget API keys are read/chat-
    scoped only"). Looks the key up by its hash on an unscoped session first
    — same reasoning as login (core/tenancy.get_current_user is JWT-only;
    this is the API-key equivalent) — then confirms the 'widget' scope and
    that the key hasn't been revoked, before resolving to exactly one
    merchant_id. A widget key can never write, import, or read another
    merchant's config; it always resolves server-side, never from anything
    the caller supplies.
    """
    if not x_api_key:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing X-API-Key header")

    from models.api_key import ApiKey  # local import avoids a circular import at module load time

    key_hash = hash_api_key(x_api_key)
    db = SessionLocal()
    try:
        api_key = db.scalar(select(ApiKey).where(ApiKey.key_hash == key_hash))
        if api_key is None or api_key.revoked_at is not None:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or revoked API key")
        if "widget" not in api_key.scopes:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "This API key isn't scoped for widget access")

        api_key.last_used_at = datetime.now(timezone.utc)
        set_tenant_context(db, api_key.merchant_id)  # must be set before this UPDATE for the write RLS policy
        db.commit()

        return WidgetContext(merchant_id=api_key.merchant_id, api_key_id=api_key.id, scopes=api_key.scopes)
    finally:
        db.close()


def get_widget_db(widget_context: WidgetContext = Depends(get_widget_context)) -> Session:
    """Tenant-scoped session for widget routes — same shape as get_tenant_db,
    just keyed off an API key instead of a JWT."""
    db = SessionLocal()
    try:
        set_tenant_context(db, widget_context.merchant_id)
        yield db
    finally:
        db.close()
