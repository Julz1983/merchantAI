"""
Run with: docker compose exec api python -m core.seed

Creates a realistic demo merchant ("JP Corry Builders' Merchants" — one of
the platform's actual target customers per the brief) with a multi-category
product catalogue, a sample installation guide document, and a ready-to-use
widget API key — so a fresh environment is immediately demo-able rather than
empty. Week 8 hardening item: "seed data for JP Corry-style demo catalogue."

Idempotent: safe to re-run against an environment that's already seeded.
"""
from core.api_keys import generate_api_key
from core.db import SessionLocal, set_tenant_context
from core.security import hash_password
from engines.ai_engine.product_indexing import index_products
from engines.document_engine.pipeline import process_document
from engines.knowledge_engine.pipeline import build_knowledge_graph
from models.api_key import ApiKey
from models.catalogue import Brand, Category, Product
from models.document import Document
from models.merchant import Merchant
from models.user import User

CATEGORIES = ["Decking", "Timber", "Fixings & Fasteners", "Roofing", "Insulation", "Paint & Decorating", "Power Tools"]
BRANDS = ["TimberTech", "FixPro", "Cemex", "Rockwool", "Dulux", "Makita", "Marley"]

# (sku, name, description, category, brand, price, stock_status, attributes, specifications)
PRODUCTS = [
    ("DK-100", "Composite Decking Board 3.6m", "Premium low-maintenance composite decking board with a natural wood-grain finish, resistant to rot and splintering.", "Decking", "TimberTech", 45.99, "in_stock", {"Coastal Areas": "Yes", "Domestic": "Yes"}, {"Length": "3.6m", "Width": "150mm", "Thickness": "25mm"}),
    ("DK-101", "Composite Decking Board 2.4m", "Shorter-length version of our premium composite decking board, ideal for smaller garden projects.", "Decking", "TimberTech", 32.50, "in_stock", {"Coastal Areas": "Yes"}, {"Length": "2.4m", "Width": "150mm"}),
    ("DK-102", "Deck Joist 2.4m Pressure Treated", "Pressure treated timber joist rated for outdoor structural use, forms the substructure beneath decking boards.", "Decking", "TimberTech", 12.50, "in_stock", {}, {"Length": "2.4m", "Cross-section": "47x150mm"}),
    ("DK-103", "Deck Joist 3.0m Pressure Treated", "Longer pressure treated timber joist for larger deck substructures.", "Decking", "TimberTech", 15.75, "in_stock", {}, {"Length": "3.0m", "Cross-section": "47x150mm"}),
    ("FX-200", "Hidden Fixing Clips (Pack of 100)", "Stainless steel hidden fixing clips for composite decking, allow for thermal expansion between boards.", "Fixings & Fasteners", "FixPro", 18.00, "in_stock", {}, {"Material": "Stainless steel", "Pack size": "100"}),
    ("FX-201", "Decking Screws 60mm (Box of 200)", "Corrosion-resistant decking screws for fixing timber joists and boards.", "Fixings & Fasteners", "FixPro", 14.25, "in_stock", {}, {"Length": "60mm", "Pack size": "200"}),
    ("FX-202", "Joist Tape 75mm x 20m", "Self-adhesive butyl joist tape, protects timber joists from moisture and extends their lifespan.", "Fixings & Fasteners", "FixPro", 22.00, "out_of_stock", {}, {"Width": "75mm", "Length": "20m"}),
    ("TM-300", "Treated Timber Post 100x100mm 2.4m", "Pressure treated softwood fence and structural post, suitable for ground contact use.", "Timber", "TimberTech", 19.99, "in_stock", {}, {"Cross-section": "100x100mm", "Length": "2.4m"}),
    ("TM-301", "Sawn Timber Batten 25x50mm 3.6m", "General purpose sawn softwood batten for framing and fixing applications.", "Timber", "TimberTech", 6.50, "in_stock", {}, {"Cross-section": "25x50mm", "Length": "3.6m"}),
    ("RF-400", "Concrete Roof Tile Anthracite", "Interlocking concrete roof tile with a weather-resistant anthracite finish, for pitched roofs.", "Roofing", "Marley", 1.85, "in_stock", {"Domestic": "Yes", "Commercial": "Yes"}, {"Coverage": "Approx 10 tiles/m2"}),
    ("RF-401", "Roofing Underlay Membrane 1m x 50m", "Breathable roofing underlay membrane, provides secondary weather protection beneath roof tiles.", "Roofing", "Marley", 89.00, "in_stock", {}, {"Width": "1m", "Length": "50m"}),
    ("RF-402", "Roof Batten 25x38mm 3.6m Treated", "Pressure treated timber batten for fixing roof tiles to rafters.", "Roofing", "TimberTech", 4.20, "in_stock", {}, {"Cross-section": "25x38mm", "Length": "3.6m"}),
    ("IN-500", "Rockwool Insulation Slab 100mm", "Fire-resistant mineral wool insulation slab for walls and roofs, excellent thermal and acoustic performance.", "Insulation", "Rockwool", 34.50, "in_stock", {}, {"Thickness": "100mm", "Coverage": "5.76m2/pack"}),
    ("IN-501", "Loft Insulation Roll 170mm", "Glass mineral wool loft insulation roll, reduces heat loss through the roof space.", "Insulation", "Rockwool", 28.75, "in_stock", {}, {"Thickness": "170mm", "Coverage": "8.28m2/pack"}),
    ("PT-600", "Weathershield Exterior Paint 5L White", "Durable exterior masonry paint with weather protection technology, 25-year guarantee.", "Paint & Decorating", "Dulux", 42.00, "in_stock", {}, {"Volume": "5L", "Coverage": "Approx 60m2"}),
    ("PT-601", "Wood Primer Undercoat 2.5L", "Fast-drying primer undercoat for bare wood, provides a stable base for exterior topcoats.", "Paint & Decorating", "Dulux", 19.50, "in_stock", {}, {"Volume": "2.5L"}),
    ("PT-602", "Decking Stain Natural Oak 2.5L", "Water-repellent decking stain and protector, enhances the natural wood grain.", "Paint & Decorating", "Dulux", 24.99, "in_stock", {}, {"Volume": "2.5L", "Coverage": "Approx 25m2"}),
    ("PW-700", "Cordless Combi Drill 18V", "18V brushless combi drill with two batteries and a carry case, suitable for drilling and driving.", "Power Tools", "Makita", 189.00, "in_stock", {}, {"Voltage": "18V", "Batteries included": "2"}),
    ("PW-701", "Circular Saw 165mm 1200W", "Corded circular saw with laser guide, suitable for cutting timber and sheet materials on site.", "Power Tools", "Makita", 95.00, "in_stock", {}, {"Blade diameter": "165mm", "Power": "1200W"}),
    ("PW-702", "Angle Grinder 115mm 720W", "Compact angle grinder for cutting and grinding metal, masonry, and tile.", "Power Tools", "Makita", 68.50, "out_of_stock", {}, {"Disc diameter": "115mm", "Power": "720W"}),
]

DECKING_INSTALLATION_GUIDE = """Composite Decking Installation Guide

This guide covers the installation of composite decking boards for
residential and light commercial garden projects.

Before You Start

Check local building regulations for decks over 300mm in height or larger
than 30 square metres, as building control approval may be required.
Ensure the ground beneath the deck area is level and has adequate drainage.

Substructure

Deck joists must be spaced at no more than 400mm centres for standard
composite boards, reducing to 300mm centres in high-traffic commercial
areas. Use pressure-treated timber joists rated for outdoor ground-contact
use. Joist tape should be applied to the top of each joist before boards
are fitted, protecting the timber from moisture ingress and significantly
extending its service life.

Fixing the Boards

Hidden fixing clips should be used between each board rather than
face-screwing, both for a cleaner finish and to allow the boards to expand
and contract with temperature changes across the seasons. Leave a 5mm gap
at board ends and a 3mm gap between boards where clips do not already
enforce spacing. Pre-drill pilot holes near board ends before fixing to
prevent the composite material from splitting.

Finishing

Decking stain is optional for composite boards but can enhance the surface
appearance and is commonly used on the cut ends of boards where the factory
finish has been removed. Allow boards to acclimatise to outdoor conditions
for 48 hours before fitting in extreme temperatures.
"""


def seed() -> None:
    db = SessionLocal()
    try:
        existing = db.query(Merchant).filter(Merchant.slug == "jp-corry").first()
        if existing:
            print("Demo merchant already exists — skipping seed.")
            return

        merchant = Merchant(
            name="JP Corry Builders' Merchants",
            slug="jp-corry",
            brand_colors={"primary": "#E3572A", "secondary": "#2B4C6F", "accent": "#E8A33D"},
            ai_persona={"tone": "formal", "upsell_aggressiveness": "medium", "emphasized_categories": ["Decking"]},
            status="active",
        )
        db.add(merchant)
        db.flush()
        set_tenant_context(db, merchant.id)

        admin = User(merchant_id=merchant.id, email="admin@demo-merchant.dev", password_hash=hash_password("changeme123"), role="owner")
        db.add(admin)

        category_by_name = {}
        for name in CATEGORIES:
            category = Category(merchant_id=merchant.id, name=name)
            db.add(category)
            db.flush()
            category_by_name[name] = category

        brand_by_name = {}
        for name in BRANDS:
            brand = Brand(merchant_id=merchant.id, name=name)
            db.add(brand)
            db.flush()
            brand_by_name[name] = brand

        for sku, name, description, category_name, brand_name, price, stock_status, attributes, specifications in PRODUCTS:
            db.add(Product(
                merchant_id=merchant.id, sku=sku, name=name, description=description,
                category_id=category_by_name[category_name].id, brand_id=brand_by_name[brand_name].id,
                price=price, stock_status=stock_status, attributes=attributes, specifications=specifications,
            ))
        db.commit()
        print(f"Seeded {len(PRODUCTS)} products across {len(CATEGORIES)} categories and {len(BRANDS)} brands.")

        # Sample document, run through the actual pipeline function used by
        # real uploads (process_document) — not a reimplementation of
        # extract/chunk/embed/store here. A previous version of this script
        # duplicated that logic inline, and the duplication meant a real bug
        # (document chunk payloads missing a content_type tag, fixed in
        # pipeline.py) wasn't also present here, but easily could have been
        # the next time either copy changed without the other.
        document = Document(
            merchant_id=merchant.id, title="Composite Decking Installation Guide",
            doc_type="installation_guide", original_filename="decking-installation-guide.txt", status="processing",
        )
        db.add(document)
        db.commit()

        process_document(db, merchant.id, document, DECKING_INSTALLATION_GUIDE.encode("utf-8"))
        print(f"Seeded document '{document.title}' with {document.chunk_count} chunks.")

        # Build the Knowledge Graph and index products for search — the same
        # steps that run automatically after a real import (routers/products.py)
        # — so the seeded catalogue is immediately fully demo-able: searchable,
        # with relationships ready for review, not just rows in a table.
        kg_result = build_knowledge_graph(db, merchant.id)
        print(f"Knowledge Graph: {kg_result}")
        index_result = index_products(db, merchant.id)
        print(f"Product indexing: {index_result}")

        # A ready-to-use widget API key, so the example test page
        # (apps/widget/example/index.html) works immediately without a
        # manual dashboard step.
        plaintext, key_hash, display_prefix = generate_api_key()
        db.add(ApiKey(merchant_id=merchant.id, key_hash=key_hash, display_prefix=display_prefix, label="Demo widget key", scopes=["widget"]))
        db.commit()

        print(f"\nSeeded merchant {merchant.id}")
        print("Login: admin@demo-merchant.dev / changeme123")
        print(f"Widget API key (save this — shown once): {plaintext}")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
