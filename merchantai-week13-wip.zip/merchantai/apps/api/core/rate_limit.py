import redis
from fastapi import Depends, HTTPException, Request, status

from core.redis_client import get_redis
from core.tenancy import CurrentUser, WidgetContext, get_current_user, get_widget_context


def check_rate_limit(key: str, limit: int, window_seconds: int) -> tuple[bool, int]:
    """
    Fixed-window counter via Redis INCR (atomic) + EXPIRE. Simpler than a
    sliding-window/token-bucket implementation and good enough for abuse
    prevention rather than precise fairness — the brief asks for rate
    limiting to protect the platform, not for billing-grade accuracy.

    Fails OPEN (allows the request) if Redis is unreachable, not closed.
    Redis being down is an infrastructure problem the platform should
    degrade gracefully from, not one that should take the entire API down
    with it — losing rate-limit protection temporarily is a much smaller
    problem than an outage.
    """
    client = get_redis()
    full_key = f"ratelimit:{key}:{window_seconds}"
    try:
        current = client.incr(full_key)
        if current == 1:
            client.expire(full_key, window_seconds)
        return current <= limit, max(0, limit - current)
    except redis.RedisError:
        return True, limit


def _enforce(key: str, limit: int, window_seconds: int) -> None:
    allowed, _ = check_rate_limit(key, limit, window_seconds)
    if not allowed:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            "Too many requests. Please try again in a moment.",
            headers={"Retry-After": str(window_seconds)},
        )


def rate_limit_by_ip(prefix: str, limit: int, window_seconds: int):
    """
    For endpoints with no authenticated identity yet — login is the
    canonical case (brute-force protection). Keyed by client IP.

    Trusts X-Forwarded-For's first entry when present, since this API sits
    behind nginx in every real deployment (architecture §12) and
    request.client.host would otherwise always be the proxy's own address,
    not the actual visitor — which would rate-limit "nginx" instead of the
    person making requests through it. This means a deployment that exposes
    the API directly (no reverse proxy) MUST NOT let arbitrary clients set
    X-Forwarded-For, or this becomes spoofable; that's a standard reverse-
    proxy deployment assumption, not unique to this endpoint.
    """
    def _check(request: Request) -> None:
        forwarded = request.headers.get("x-forwarded-for")
        client_ip = forwarded.split(",")[0].strip() if forwarded else (request.client.host if request.client else "unknown")
        _enforce(f"{prefix}:ip:{client_ip}", limit, window_seconds)

    return _check


def rate_limit_by_merchant(prefix: str, limit: int, window_seconds: int):
    """For JWT-authed endpoints — keyed by merchant_id, so one merchant's
    traffic can't degrade another's (architecture §14)."""
    def _check(current_user: CurrentUser = Depends(get_current_user)) -> None:
        _enforce(f"{prefix}:merchant:{current_user.merchant_id}", limit, window_seconds)

    return _check


def rate_limit_widget(prefix: str, limit: int, window_seconds: int):
    """For widget (API-key-authed) endpoints — keyed by merchant_id, same
    reasoning as rate_limit_by_merchant. Deliberately not keyed by API key
    id: a merchant rotating keys shouldn't reset their quota, and the
    isolation goal is per-merchant, not per-key."""
    def _check(widget_context: WidgetContext = Depends(get_widget_context)) -> None:
        _enforce(f"{prefix}:merchant:{widget_context.merchant_id}", limit, window_seconds)

    return _check
