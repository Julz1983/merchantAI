import logging
import uuid

from fastapi import FastAPI, Request, status
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

logger = logging.getLogger("merchantai.errors")


def _error_envelope(message: str, details: object = None) -> dict:
    body = {"data": None, "meta": {"request_id": str(uuid.uuid4())}, "error": {"message": message}}
    if details is not None:
        body["error"]["details"] = details
    return body


def register_exception_handlers(app: FastAPI) -> None:
    """
    Without this, HTTPException (401/403/404/409/429/...) returns FastAPI's
    default `{"detail": "..."}` shape — every successful response in this API
    uses `{data, meta, error}`, but every error response used a completely
    different shape. A frontend or third-party integrator has to special-case
    error parsing instead of always unwrapping the same envelope. This makes
    every response — success or failure — the same shape, with no per-route
    changes needed.
    """

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content=_error_envelope(str(exc.detail)),
            headers=exc.headers or {},  # preserves things like Retry-After on 429s
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
        # exc.errors() can contain non-JSON-serializable values (e.g. a
        # ValueError instance in 'ctx') — jsonable_encoder handles that.
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=_error_envelope("Validation error", jsonable_encoder(exc.errors())),
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        # Never leak an internal stack trace or exception message to the
        # client — log it server-side (where it's actually actionable) and
        # return a generic message. This is the backstop for bugs, not the
        # primary error path — every route that can anticipate a failure
        # mode should raise HTTPException with a specific message instead.
        logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=_error_envelope("An unexpected error occurred. Please try again."),
        )
