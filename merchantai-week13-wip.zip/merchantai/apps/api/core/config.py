from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    All runtime config in one place. Nothing merchant-specific lives here —
    per-merchant config is data (see models.merchant.Merchant), never env vars
    or code branches.
    """

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    ENVIRONMENT: str = "development"

    # Runtime connection for the FastAPI app. MUST be a non-superuser role
    # with no BYPASSRLS attribute — Postgres superusers bypass Row-Level
    # Security unconditionally, even with FORCE ROW LEVEL SECURITY set. If
    # this ever points at a superuser (e.g. the default `postgres` role),
    # every RLS policy in the schema silently stops being enforced with no
    # error — see core/bootstrap_roles.py and README "Security" section.
    DATABASE_URL: str

    # Migration connection — needs DDL rights (CREATE TABLE, CREATE POLICY,
    # etc.) that the restricted app role deliberately doesn't have. Used by
    # alembic and core/bootstrap_roles.py only, never by the running app.
    # Defaults to DATABASE_URL for convenience in quick local setups, but
    # should be overridden in .env to point at a superuser/owner role.
    MIGRATIONS_DATABASE_URL: str | None = None

    REDIS_URL: str = "redis://localhost:6379/0"

    # No default on purpose: an unset QDRANT_URL is how vector_store.py knows
    # to fall back to Qdrant's in-process local mode (used by tests and quick
    # local dev without a running Qdrant server). Giving this a default value
    # like "http://localhost:6333" would silently defeat that fallback —
    # pydantic-settings returns the default rather than None even when the
    # env var is genuinely unset, so the code could never tell "unset" apart
    # from "explicitly localhost". Real deployments set this via .env /
    # docker-compose.yml, where it's never actually unset.
    QDRANT_URL: str | None = None

    JWT_SECRET: str
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 14

    CORS_ORIGINS: str = "http://localhost:3000"

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]

    @property
    def migrations_database_url(self) -> str:
        return self.MIGRATIONS_DATABASE_URL or self.DATABASE_URL


settings = Settings()
