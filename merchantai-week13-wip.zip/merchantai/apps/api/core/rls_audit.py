"""
Systematic Row-Level Security audit. Run with:
    python -m core.rls_audit

Every tenant table in this schema should have RLS enabled AND forced, plus a
SELECT and INSERT policy at minimum. This script introspects Postgres's own
catalog (pg_tables, pg_policies) rather than trusting the migration history —
migrations describe intent, this checks what's actually live in the database,
which is what matters. It's meant to be run after every migration and as
part of any pre-deploy checklist.

Two tables are deliberately exempted from the strict rule and must be listed
in EXPECTED_EXCEPTIONS with a reason, rather than silently skipped:
- merchants: the tenant root itself, has no merchant_id column to scope on.
- alembic_version: Alembic's own bookkeeping table, not tenant data.

Every other table with a merchant_id column MUST have RLS enabled, forced,
and a SELECT + INSERT policy — no other exceptions. This is a hard rule
specifically because it's the kind of thing that's easy to forget when
adding a new table under time pressure, and RLS gaps fail silently (extra
rows show up in a query, not an error) rather than loudly.
"""
import sys

import psycopg

from core.config import settings

EXPECTED_EXCEPTIONS = {
    "merchants": "tenant root — no merchant_id column to scope on",
    "alembic_version": "Alembic bookkeeping, not tenant data",
}

# Tables where a missing UPDATE or DELETE policy is intentional, not an
# oversight — documented per table so an auditor doesn't have to go spelunge
# through migration comments to find out why.
EXPECTED_MISSING_UPDATE = {
    "analytics_events": "append-only event log — nothing in the app edits an event after the fact",
    "chat_messages": "append-only conversation log",
    "kg_nodes": "nodes are replaced (deleted + recreated), never edited in place",
    "document_chunks": "chunks are replaced wholesale on re-processing, never edited in place",
}
EXPECTED_MISSING_DELETE = {
    "chat_messages": "conversation history is retained for citation/audit purposes, not user-deletable",
}


def audit(dsn: str) -> list[str]:
    """Returns a list of problem descriptions — empty list means everything
    checked out. Raises nothing on its own; callers decide how to react."""
    problems: list[str] = []

    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT table_name FROM information_schema.columns
                WHERE table_schema = 'public' AND column_name = 'merchant_id'
                ORDER BY table_name
            """)
            tenant_tables = [row[0] for row in cur.fetchall()]

            cur.execute("""
                SELECT table_name FROM information_schema.tables
                WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
                ORDER BY table_name
            """)
            all_tables = [row[0] for row in cur.fetchall()]

            # Every table should either have merchant_id (and thus be
            # checked below) or be an explicitly documented exception —
            # this catches a brand new table that forgot merchant_id
            # entirely, which no RLS policy check alone would catch.
            for table in all_tables:
                if table not in tenant_tables and table not in EXPECTED_EXCEPTIONS:
                    problems.append(f"{table}: has no merchant_id column and isn't in EXPECTED_EXCEPTIONS — either add merchant_id or document why not")

            for table in tenant_tables:
                cur.execute(
                    "SELECT relrowsecurity, relforcerowsecurity FROM pg_class WHERE relname = %s AND relkind = 'r'",
                    (table,),
                )
                row = cur.fetchone()
                if row is None:
                    problems.append(f"{table}: couldn't read RLS status from pg_tables")
                    continue
                row_security, force_row_security = row
                if not row_security:
                    problems.append(f"{table}: ROW LEVEL SECURITY is not enabled")
                if not force_row_security:
                    problems.append(f"{table}: FORCE ROW LEVEL SECURITY is not set — the table owner would bypass RLS")

                cur.execute("SELECT cmd FROM pg_policies WHERE tablename = %s", (table,))
                policy_commands = {row[0] for row in cur.fetchall()}

                missing_select = not any(c in ("SELECT", "ALL") for c in policy_commands)
                missing_insert = not any(c in ("INSERT", "ALL") for c in policy_commands)
                missing_update = not any(c in ("UPDATE", "ALL") for c in policy_commands)
                missing_delete = not any(c in ("DELETE", "ALL") for c in policy_commands)

                if missing_select:
                    problems.append(f"{table}: no SELECT policy")
                if missing_insert:
                    problems.append(f"{table}: no INSERT policy")
                if missing_update and table not in EXPECTED_MISSING_UPDATE:
                    problems.append(f"{table}: no UPDATE policy (not in EXPECTED_MISSING_UPDATE — add the policy or document why not)")
                if missing_delete and table not in EXPECTED_MISSING_DELETE:
                    problems.append(f"{table}: no DELETE policy (not in EXPECTED_MISSING_DELETE — add the policy or document why not)")

    return problems


def main() -> None:
    dsn = settings.migrations_database_url.replace("postgresql+psycopg://", "postgresql://")
    problems = audit(dsn)

    if problems:
        print(f"RLS AUDIT FAILED — {len(problems)} problem(s) found:\n")
        for p in problems:
            print(f"  ✗ {p}")
        sys.exit(1)
    else:
        print("RLS audit passed — every tenant table has RLS enabled, forced, and the expected policies.")


if __name__ == "__main__":
    main()
