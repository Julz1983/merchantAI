from collections.abc import Generator
from uuid import UUID

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from core.config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    """Base class for all ORM models."""


def get_db() -> Generator[Session, None, None]:
    """
    Plain (non-tenant-scoped) DB session — used only for auth endpoints that run
    *before* a merchant_id is known (e.g. login itself). Every other route should
    use get_tenant_db below.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def set_tenant_context(db: Session, merchant_id: UUID) -> None:
    """
    Sets the Postgres session variable that every tenant table's Row-Level
    Security policy checks against (see migrations/versions/0001_initial.py).
    This is the enforcement point: even if application code forgets a
    `WHERE merchant_id = ...` filter, RLS blocks cross-tenant reads/writes
    at the database layer.

    Uses set_config() with is_local=true, not `SET LOCAL app.x = :val`
    (Postgres's SET LOCAL syntax doesn't accept bind parameters — it needs a
    literal — so set_config is the parameterized-safe equivalent).

    is_local=true means the setting is transaction-scoped and resets on every
    commit. Rather than requiring every route that commits mid-request
    (create/update/delete, the import job's periodic progress commits) to
    remember to re-set it afterwards — a guarantee that's easy to violate by
    forgetting one call site — this registers an `after_begin` listener on the
    session that automatically reapplies the setting whenever a new
    transaction starts. Callers only need to call this once per session.
    """
    mid = str(merchant_id)

    def _reapply_on_new_transaction(session, transaction, connection) -> None:
        connection.execute(text("SELECT set_config('app.current_merchant_id', :mid, true)"), {"mid": mid})

    if not db.info.get("_tenant_context_listener_attached"):
        event.listen(db, "after_begin", _reapply_on_new_transaction)
        db.info["_tenant_context_listener_attached"] = True

    db.execute(text("SELECT set_config('app.current_merchant_id', :mid, true)"), {"mid": mid})
