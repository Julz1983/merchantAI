import hashlib
import secrets

# Format: mai_live_<32 url-safe chars> — the "mai_live_" prefix is shown to
# the merchant even after the full key is hidden (stored nowhere in
# plaintext, see key_hash below), so a partially-redacted key in a support
# ticket or screenshot is still identifiable as a MerchantAI key without
# revealing anything usable.
KEY_PREFIX = "mai_live_"


def generate_api_key() -> tuple[str, str, str]:
    """Returns (plaintext_key, key_hash, display_prefix). The plaintext key
    is returned to the caller exactly once — the database only ever stores
    key_hash. display_prefix is the first 12 chars of the plaintext, shown
    in the dashboard's key list so a merchant can tell keys apart without
    the full secret ever being persisted or re-displayable."""
    token = secrets.token_urlsafe(32)
    plaintext = f"{KEY_PREFIX}{token}"
    key_hash = hash_api_key(plaintext)
    display_prefix = plaintext[:len(KEY_PREFIX) + 8]
    return plaintext, key_hash, display_prefix


def hash_api_key(plaintext: str) -> str:
    # SHA-256 (not bcrypt): API keys are already high-entropy random tokens,
    # not user-chosen passwords, so there's no offline-brute-force risk a
    # slow hash defends against — a fast hash is the right tradeoff here
    # since this runs on every widget request.
    return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()
