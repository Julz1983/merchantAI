"""
Run once per environment, after migrations, using the migration (superuser/
owner) connection: docker compose exec api python -m core.bootstrap_roles

Creates the role the running API connects as (APP_DB_USER / APP_DB_PASSWORD)
and grants it exactly DML access (SELECT/INSERT/UPDATE/DELETE) on tenant
tables — deliberately no CREATE/ALTER/DROP, and critically no BYPASSRLS or
SUPERUSER attribute.

Why this exists: Postgres superusers (and any role with BYPASSRLS) skip
Row-Level Security policies unconditionally, regardless of FORCE ROW LEVEL
SECURITY. If the app ever connects as the same role that owns/migrates the
schema — which is often a superuser locally (e.g. the default `postgres`
role in the official Postgres Docker image) — every RLS policy in the
schema silently stops being enforced, with no error, no warning, just rows
from every tenant appearing in every query. This was caught by live-testing
multi-tenant isolation end to end (a second seeded merchant could see the
first merchant's products) rather than by inspecting the policies
themselves, which looked correct in isolation.

Uses psycopg's sql.Identifier/sql.Literal for client-side-safe composition
rather than SQLAlchemy bind parameters — CREATE ROLE / ALTER ROLE are DDL
and Postgres doesn't support parameter placeholders in that position
(`CREATE ROLE x PASSWORD $1` is a syntax error), so this is the correct way
to safely inline a password here, not a shortcut around parameterization.

`ALTER DEFAULT PRIVILEGES` covers tables created by future migrations too,
so this script doesn't need to be re-run after every new migration adds a
table — only once per environment (or again if the migration role changes).
"""
import os

import psycopg
from psycopg import sql

from core.config import settings

APP_DB_USER = os.environ.get("APP_DB_USER", "merchantai_app")
APP_DB_PASSWORD = os.environ.get("APP_DB_PASSWORD")


def bootstrap() -> None:
    if not APP_DB_PASSWORD:
        raise SystemExit("APP_DB_PASSWORD env var is required — refusing to create a role with no password.")

    dsn = settings.migrations_database_url.replace("postgresql+psycopg://", "postgresql://")

    with psycopg.connect(dsn, autocommit=True) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (APP_DB_USER,))
            role_exists = cur.fetchone() is not None

            role_ident = sql.Identifier(APP_DB_USER)
            pw_literal = sql.Literal(APP_DB_PASSWORD)

            if role_exists:
                print(f"Role '{APP_DB_USER}' already exists — updating password and attributes.")
                cur.execute(
                    sql.SQL("ALTER ROLE {} WITH LOGIN PASSWORD {} NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE")
                    .format(role_ident, pw_literal)
                )
            else:
                print(f"Creating role '{APP_DB_USER}'.")
                cur.execute(
                    sql.SQL("CREATE ROLE {} WITH LOGIN PASSWORD {} NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE")
                    .format(role_ident, pw_literal)
                )

            cur.execute(sql.SQL("GRANT USAGE ON SCHEMA public TO {}").format(role_ident))
            cur.execute(sql.SQL("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {}").format(role_ident))
            cur.execute(sql.SQL("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO {}").format(role_ident))

            # Belt-and-braces check: fail loudly if this role somehow has
            # RLS-bypassing power, instead of deploying a silent no-op.
            cur.execute("SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = %s", (APP_DB_USER,))
            rolsuper, rolbypassrls = cur.fetchone()
            if rolsuper or rolbypassrls:
                raise SystemExit(f"'{APP_DB_USER}' has rolsuper={rolsuper} rolbypassrls={rolbypassrls} — RLS would not be enforced. Aborting.")

    print(f"Done. '{APP_DB_USER}' has DML access (no DDL, no BYPASSRLS, no SUPERUSER) — RLS policies now actually apply to app traffic.")


if __name__ == "__main__":
    bootstrap()
