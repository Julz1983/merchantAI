import json
from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, Form, HTTPException, Query, UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from core.db import SessionLocal, set_tenant_context
from core.rate_limit import rate_limit_by_merchant
from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db, require_role
from engines.import_engine.mapping import REQUIRED_FIELDS, TARGET_FIELDS, apply_mapping, suggest_mapping
from engines.import_engine.parsers import ParseError, get_parser
from engines.import_engine.product_import import run_import
from engines.ai_engine.product_indexing import index_products
from engines.knowledge_engine.pipeline import build_knowledge_graph
from models.catalogue import Brand, Category, ImportJob, Product
from schemas.import_job import ImportInspectResponse, ImportJobOut
from schemas.product import ProductCreate, ProductListResponse, ProductOut, ProductUpdate

router = APIRouter(prefix="/products", tags=["products"])

MAX_UPLOAD_BYTES = 20 * 1024 * 1024  # 20MB — generous for a spreadsheet, small enough to hold in memory


async def _read_upload(file: UploadFile) -> bytes:
    file_bytes = await file.read()
    if len(file_bytes) > MAX_UPLOAD_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "File too large (max 20MB)")
    if not file_bytes:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Uploaded file is empty")
    return file_bytes


# ── Import ──────────────────────────────────────────────────────────────

@router.post("/import/inspect")
async def inspect_import(
    file: UploadFile,
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
):
    """Parses the file and returns headers + a suggested column mapping, without
    writing anything — this powers the mapping-review step before the merchant
    confirms the import (architecture §10, product import wireframe)."""
    file_bytes = await _read_upload(file)
    try:
        parser = get_parser(file.filename or "")
        sheet = parser.parse(file_bytes)
    except ParseError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc

    return envelope(ImportInspectResponse(
        headers=sheet.headers,
        suggested_mapping=suggest_mapping(sheet.headers),
        sample_rows=sheet.rows[:5],
        total_rows=len(sheet.rows),
        target_fields=TARGET_FIELDS,
        required_fields=sorted(REQUIRED_FIELDS),
    ).model_dump())


def _process_import_job(job_id: UUID, merchant_id: UUID, file_bytes: bytes, filename: str, mapping: dict[str, str]) -> None:
    """
    Runs in a FastAPI BackgroundTask, i.e. *after* the request/response cycle
    (and its dependency-injected DB session) has already closed — so this
    opens its own session and sets its own RLS tenant context rather than
    reusing anything from the request. See product_import.py's docstring.
    """
    db: Session = SessionLocal()
    try:
        set_tenant_context(db, merchant_id)
        job = db.get(ImportJob, job_id)
        if job is None:
            return
        try:
            parser = get_parser(filename)
            sheet = parser.parse(file_bytes)
            rows = apply_mapping(sheet.rows, mapping)
            run_import(db, merchant_id, job, rows)

            # KG build and product indexing both run as part of the same
            # background task. Neither failure mode should be able to flip
            # an otherwise-successful import job to "failed", so each gets
            # its own try/except — but the job is only marked "completed"
            # once all three steps have actually finished (see
            # product_import.py's docstring for why this ordering matters:
            # a merchant asking the assistant a question before indexing
            # finishes would get "nothing found" for a catalogue that really
            # was imported, just not searchable yet).
            try:
                build_knowledge_graph(db, merchant_id)
            except Exception:  # noqa: BLE001 — KG build failing shouldn't mask a successful product import
                db.rollback()
            try:
                index_products(db, merchant_id)
            except Exception:  # noqa: BLE001 — indexing failing shouldn't mask a successful product import
                db.rollback()

            job = db.get(ImportJob, job_id)
            if job:
                job.status = "completed"
                job.completed_at = datetime.now(timezone.utc)
                db.commit()
        except Exception as exc:  # noqa: BLE001 — job row is how failures surface to the UI
            db.rollback()
            job = db.get(ImportJob, job_id)
            if job:
                job.status = "failed"
                job.error_rows = [{"row_number": 0, "errors": [str(exc)]}]
                db.commit()
    finally:
        db.close()


@router.post("/import")
async def start_import(
    background_tasks: BackgroundTasks,
    file: UploadFile,
    mapping: str = Form(...),  # JSON-encoded { target_field: source_header }, from the mapping-review step
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
    db: Session = Depends(get_tenant_db),
    _rate_limit: None = Depends(rate_limit_by_merchant("product_import", limit=10, window_seconds=3600)),
):
    file_bytes = await _read_upload(file)
    try:
        mapping_dict: dict[str, str] = json.loads(mapping)
    except json.JSONDecodeError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "mapping must be valid JSON") from exc

    missing_required = REQUIRED_FIELDS - mapping_dict.keys()
    if missing_required:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Missing required field mapping: {', '.join(sorted(missing_required))}")

    job = ImportJob(merchant_id=current_user.merchant_id, filename=file.filename or "upload", status="pending")
    db.add(job)
    db.commit()
    db.refresh(job)

    background_tasks.add_task(_process_import_job, job.id, current_user.merchant_id, file_bytes, file.filename or "", mapping_dict)

    return envelope(ImportJobOut.model_validate(job).model_dump(mode="json"))


@router.get("/import/{job_id}")
def get_import_status(job_id: UUID, current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    job = db.get(ImportJob, job_id)
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Import job not found")
    return envelope(ImportJobOut.model_validate(job).model_dump(mode="json"))


# ── Products CRUD ───────────────────────────────────────────────────────

def _to_product_out(product: Product, category_name: str | None, brand_name: str | None) -> ProductOut:
    return ProductOut(
        id=product.id, sku=product.sku, name=product.name, description=product.description,
        category_id=product.category_id, category_name=category_name,
        brand_id=product.brand_id, brand_name=brand_name,
        price=float(product.price) if product.price is not None else None,
        currency=product.currency, images=product.images or [], product_url=product.product_url,
        specifications=product.specifications or {}, attributes=product.attributes or {},
        stock_status=product.stock_status, created_at=product.created_at, updated_at=product.updated_at,
    )


@router.get("")
def list_products(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: str | None = None,
    category_id: UUID | None = None,
    brand_id: UUID | None = None,
    stock_status: str | None = None,
    current_user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_tenant_db),
):
    query = select(Product, Category.name, Brand.name).outerjoin(Category, Product.category_id == Category.id).outerjoin(Brand, Product.brand_id == Brand.id)

    if search:
        like = f"%{search}%"
        query = query.where((Product.name.ilike(like)) | (Product.sku.ilike(like)))
    if category_id:
        query = query.where(Product.category_id == category_id)
    if brand_id:
        query = query.where(Product.brand_id == brand_id)
    if stock_status:
        query = query.where(Product.stock_status == stock_status)

    total = db.scalar(select(func.count()).select_from(query.subquery())) or 0

    query = query.order_by(Product.updated_at.desc()).offset((page - 1) * page_size).limit(page_size)
    rows = db.execute(query).all()
    items = [_to_product_out(p, cat_name, brand_name) for p, cat_name, brand_name in rows]

    return envelope(ProductListResponse(items=items, total=total, page=page, page_size=page_size).model_dump(mode="json"))


@router.get("/{product_id}")
def get_product(product_id: UUID, current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    row = db.execute(
        select(Product, Category.name, Brand.name)
        .outerjoin(Category, Product.category_id == Category.id)
        .outerjoin(Brand, Product.brand_id == Brand.id)
        .where(Product.id == product_id)
    ).first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")
    product, category_name, brand_name = row
    return envelope(_to_product_out(product, category_name, brand_name).model_dump(mode="json"))


@router.post("", status_code=status.HTTP_201_CREATED)
def create_product(
    payload: ProductCreate,
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
    db: Session = Depends(get_tenant_db),
):
    existing = db.scalar(select(Product).where(Product.merchant_id == current_user.merchant_id, Product.sku == payload.sku))
    if existing:
        raise HTTPException(status.HTTP_409_CONFLICT, f"A product with SKU '{payload.sku}' already exists")

    product = Product(merchant_id=current_user.merchant_id, **payload.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    return envelope(_to_product_out(product, None, None).model_dump(mode="json"))


@router.patch("/{product_id}")
def update_product(
    product_id: UUID,
    payload: ProductUpdate,
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
    db: Session = Depends(get_tenant_db),
):
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")

    for field_name, value in payload.model_dump(exclude_unset=True).items():
        setattr(product, field_name, value)
    db.commit()
    db.refresh(product)
    return envelope(_to_product_out(product, None, None).model_dump(mode="json"))


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_product(
    product_id: UUID,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")
    db.delete(product)
    db.commit()
