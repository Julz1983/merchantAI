import asyncio
import json
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.rate_limit import rate_limit_widget
from core.response import envelope
from core.tenancy import WidgetContext, get_widget_context, get_widget_db
from engines.ai_engine.chat_service import handle_chat_turn
from engines.analytics_engine.event_ingest import record_event
from engines.commerce_engine.basket_service import BasketError, add_item, get_basket_view, remove_item, update_item_quantity
from engines.commerce_engine.quote_service import QuoteError, create_quote_from_basket, get_quote_by_reference
from engines.commerce_engine.quantity_calculator import QuantityCalculatorError, calculate_units_for_area
from models.catalogue import Product
from models.chat import Chat
from models.merchant import Merchant
from models.widget_settings import WidgetSettings
from schemas.chat import SuggestedProductOut
from schemas.widget import (
    BasketAddRequest, BasketItemOut, BasketOut, BasketUpdateQuantityRequest,
    CalculateQuantityRequest, CalculateQuantityResponse, CreateQuoteRequest, QuoteItemOut, QuoteOut,
    WidgetChatRequest, WidgetClickRequest, WidgetConfigResponse,
)

router = APIRouter(prefix="/widget", tags=["widget"])

# Streaming design note (architecture §7): citations must be validated
# against the full retrieved context before they can be trusted (see
# rag_pipeline.py's grounding enforcement), which means the complete answer
# has to exist before any citation can be sent — true incremental
# token-by-token generation and pre-validated citations are in tension.
# This computes the full, already-validated response first, then streams
# the reply text back in word chunks for the perceived-latency UX benefit
# the architecture asks for, with the citations/suggested-products arriving
# as one final structured event once the stream closes. A future iteration
# could stream raw provider tokens and validate citations only at the end
# (accepting a brief window where displayed text implies an uncited claim);
# this MVP takes the more conservative option.
STREAM_WORD_CHUNK = 3
STREAM_DELAY_SECONDS = 0.03


@router.get("/config")
def get_widget_config(widget_context: WidgetContext = Depends(get_widget_context), db: Session = Depends(get_widget_db)):
    merchant = db.get(Merchant, widget_context.merchant_id)
    if merchant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Merchant not found")

    settings = db.get(WidgetSettings, widget_context.merchant_id)

    return envelope(WidgetConfigResponse(
        merchant_name=merchant.name,
        logo_url=merchant.logo_url,
        brand_colors=merchant.brand_colors or {},
        launcher_position=settings.launcher_position if settings else "bottom-right",
        greeting_message=settings.greeting_message if settings else "Hi! How can I help you find what you need?",
    ).model_dump(mode="json"))


@router.post("/chat")
def widget_chat(
    payload: WidgetChatRequest,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
    _rate_limit: None = Depends(rate_limit_widget("widget_chat", limit=30, window_seconds=60)),
):
    merchant = db.get(Merchant, widget_context.merchant_id)
    if merchant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Merchant not found")

    rag_response = handle_chat_turn(db, merchant, widget_context.merchant_id, payload.session_id, payload.message)
    citations = {"product_ids": rag_response.cited_product_ids, "document_chunk_ids": rag_response.cited_document_chunk_ids}

    return envelope({
        "reply": rag_response.reply,
        "citations": citations,
        "suggested_products": [SuggestedProductOut(**vars(p)).model_dump(mode="json") for p in rag_response.suggested_products],
    })


@router.post("/chat/stream")
async def widget_chat_stream(
    payload: WidgetChatRequest,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
    _rate_limit: None = Depends(rate_limit_widget("widget_chat_stream", limit=30, window_seconds=60)),
):
    merchant = db.get(Merchant, widget_context.merchant_id)
    if merchant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Merchant not found")

    # Computed synchronously (and fully) before streaming starts — see the
    # module docstring above for why citations can't be validated any other way.
    rag_response = handle_chat_turn(db, merchant, widget_context.merchant_id, payload.session_id, payload.message)

    async def event_stream():
        words = rag_response.reply.split(" ")
        for i in range(0, len(words), STREAM_WORD_CHUNK):
            chunk = " ".join(words[i:i + STREAM_WORD_CHUNK])
            yield f"data: {json.dumps({'type': 'token', 'text': chunk + ' '})}\n\n"
            await asyncio.sleep(STREAM_DELAY_SECONDS)

        final = {
            "type": "done",
            "citations": {"product_ids": rag_response.cited_product_ids, "document_chunk_ids": rag_response.cited_document_chunk_ids},
            "suggested_products": [SuggestedProductOut(**vars(p)).model_dump(mode="json") for p in rag_response.suggested_products],
        }
        yield f"data: {json.dumps(final)}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@router.post("/track-click", status_code=status.HTTP_204_NO_CONTENT)
def track_click(
    payload: WidgetClickRequest,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    """Fired when a customer clicks a suggested product card in the widget
    — the 'Clicks' metric from the brief's analytics list, and the concrete
    signal that closes the loop from "recommended" to "acted on" (architecture
    Journey B, step 4)."""
    chat = db.scalar(select(Chat).where(Chat.merchant_id == widget_context.merchant_id, Chat.session_id == payload.session_id))
    record_event(db, widget_context.merchant_id, "click", {"product_id": payload.product_id, "sku": payload.sku}, chat_id=chat.id if chat else None)
    db.commit()


def _to_basket_out(view) -> dict:
    return BasketOut(
        id=view.id, item_count=view.item_count, subtotal=view.subtotal,
        items=[BasketItemOut(**vars(item)) for item in view.items],
    ).model_dump(mode="json")


@router.get("/basket")
def get_basket(
    session_id: str,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    view = get_basket_view(db, widget_context.merchant_id, session_id)
    return envelope(_to_basket_out(view))


@router.post("/basket/items", status_code=status.HTTP_201_CREATED)
def add_basket_item(
    payload: BasketAddRequest,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    try:
        add_item(db, widget_context.merchant_id, payload.session_id, UUID(payload.product_id), payload.quantity, payload.source)
    except BasketError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    except ValueError as exc:  # invalid UUID string
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "product_id must be a valid UUID") from exc

    chat = db.scalar(select(Chat).where(Chat.merchant_id == widget_context.merchant_id, Chat.session_id == payload.session_id))
    record_event(db, widget_context.merchant_id, "basket_add", {"product_id": payload.product_id, "quantity": payload.quantity, "source": payload.source}, chat_id=chat.id if chat else None)
    db.commit()

    view = get_basket_view(db, widget_context.merchant_id, payload.session_id)
    return envelope(_to_basket_out(view))


@router.patch("/basket/items/{item_id}")
def update_basket_item(
    item_id: UUID,
    payload: BasketUpdateQuantityRequest,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    try:
        update_item_quantity(db, widget_context.merchant_id, payload.session_id, item_id, payload.quantity)
    except BasketError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    db.commit()

    view = get_basket_view(db, widget_context.merchant_id, payload.session_id)
    return envelope(_to_basket_out(view))


@router.delete("/basket/items/{item_id}")
def delete_basket_item(
    item_id: UUID,
    session_id: str,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    try:
        remove_item(db, widget_context.merchant_id, session_id, item_id)
    except BasketError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    db.commit()

    view = get_basket_view(db, widget_context.merchant_id, session_id)
    return envelope(_to_basket_out(view))


@router.post("/calculate-quantity")
def calculate_quantity(
    payload: CalculateQuantityRequest,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    """Quantity Calculators module: given a project area (directly, or as
    length x width) and a product, works out how many units are needed,
    reading coverage from the product's own specifications."""
    try:
        product_id = UUID(payload.product_id)
    except ValueError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "product_id must be a valid UUID") from exc

    product = db.get(Product, product_id)
    if product is None or product.merchant_id != widget_context.merchant_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")

    if payload.area_m2 is not None:
        area_m2 = payload.area_m2
    elif payload.length_m is not None and payload.width_m is not None:
        area_m2 = payload.length_m * payload.width_m
    else:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Provide either area_m2, or both length_m and width_m")

    try:
        result = calculate_units_for_area(product, area_m2, payload.waste_factor)
    except QuantityCalculatorError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc

    return envelope(CalculateQuantityResponse(**vars(result)).model_dump(mode="json"))



def _to_quote_out(view) -> dict:
    return QuoteOut(
        id=view.id, reference_number=view.reference_number, status=view.status, subtotal=view.subtotal,
        items=[QuoteItemOut(**vars(i)) for i in view.items],
        created_at=view.created_at, expires_at=view.expires_at, is_expired=view.is_expired,
    ).model_dump(mode="json")


@router.post("/quotes", status_code=status.HTTP_201_CREATED)
def create_quote(
    payload: CreateQuoteRequest,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    """Quote Builder: snapshots the session's current basket into a quote
    with a short reference number the customer can quote back to staff."""
    try:
        view = create_quote_from_basket(db, widget_context.merchant_id, payload.session_id)
    except QuoteError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    db.commit()
    return envelope(_to_quote_out(view))


@router.get("/quotes/{reference_number}")
def get_quote(
    reference_number: str,
    widget_context: WidgetContext = Depends(get_widget_context),
    db: Session = Depends(get_widget_db),
):
    try:
        view = get_quote_by_reference(db, widget_context.merchant_id, reference_number)
    except QuoteError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    return envelope(_to_quote_out(view))
