from sqlalchemy import select
from sqlalchemy.orm import Session
from fastapi import APIRouter, Depends, HTTPException, status

from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db
from engines.ai_engine.chat_service import handle_chat_turn
from models.chat import Chat, ChatMessage
from models.merchant import Merchant
from schemas.chat import ChatMessageHistoryItem, ChatMessageRequest, ChatMessageResponse, SuggestedProductOut

router = APIRouter(prefix="/chat", tags=["chat"])

# NOTE: authenticated via JWT (get_current_user) — for merchant-staff use
# (the dashboard's Assistant test page) and any future internal tooling.
# The public widget uses a separate, API-key-scoped set of routes
# (routers/widget.py) that call the same underlying chat_service/rag_pipeline
# — see architecture §13 ("widget API keys are read/chat-scoped only").


@router.post("/message")
def send_message(
    payload: ChatMessageRequest,
    current_user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_tenant_db),
):
    merchant = db.get(Merchant, current_user.merchant_id)
    if merchant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Merchant not found")

    rag_response = handle_chat_turn(db, merchant, current_user.merchant_id, payload.session_id, payload.message)

    citations = {"product_ids": rag_response.cited_product_ids, "document_chunk_ids": rag_response.cited_document_chunk_ids}
    return envelope(ChatMessageResponse(
        reply=rag_response.reply,
        citations=citations,
        suggested_products=[SuggestedProductOut(**vars(p)) for p in rag_response.suggested_products],
    ).model_dump(mode="json"))


@router.get("/{session_id}/history")
def get_chat_history(session_id: str, current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    chat = db.scalar(select(Chat).where(Chat.merchant_id == current_user.merchant_id, Chat.session_id == session_id))
    if chat is None:
        return envelope([])

    messages = db.scalars(select(ChatMessage).where(ChatMessage.chat_id == chat.id).order_by(ChatMessage.created_at)).all()
    return envelope([ChatMessageHistoryItem.model_validate(m, from_attributes=True).model_dump(mode="json") for m in messages])
