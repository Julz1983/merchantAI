from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session, aliased

from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db, require_role
from engines.knowledge_engine.kg_repository import get_neighborhood
from models.knowledge_graph import RELATIONSHIP_TYPES, KGEdge, KGNode
from schemas.knowledge_graph import KGEdgeCreate, KGEdgeOut, KGNeighborhoodResponse, KGNodeOut, PendingEdgeOut

router = APIRouter(prefix="/kg", tags=["knowledge-graph"])


@router.get("/nodes/by-ref/{node_type}/{ref_id}")
def get_node_by_ref(
    node_type: str, ref_id: UUID,
    current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db),
):
    """Resolves a KG node from the id of the record it wraps (e.g. a
    product's id) — lets the dashboard show 'related products' on a product
    page without needing to know internal KG node ids, which are otherwise
    only ever seen via the KG endpoints themselves."""
    node = db.scalar(select(KGNode).where(KGNode.merchant_id == current_user.merchant_id, KGNode.node_type == node_type, KGNode.ref_id == ref_id))
    if node is None:
        return envelope(None)
    return envelope(KGNodeOut.model_validate(node).model_dump(mode="json"))


@router.get("/nodes/{node_id}")
def get_node(node_id: UUID, current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    node = db.get(KGNode, node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Node not found")

    edges = db.scalars(
        select(KGEdge).where(
            KGEdge.merchant_id == current_user.merchant_id,
            KGEdge.status == "approved",
            (KGEdge.source_node_id == node_id) | (KGEdge.target_node_id == node_id),
        )
    ).all()

    return envelope({
        "node": KGNodeOut.model_validate(node).model_dump(mode="json"),
        "edges": [KGEdgeOut.model_validate(e).model_dump(mode="json") for e in edges],
    })


@router.get("/nodes/{node_id}/neighborhood")
def get_node_neighborhood(
    node_id: UUID,
    depth: int = Query(2, ge=1, le=4),
    current_user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_tenant_db),
):
    result = get_neighborhood(db, current_user.merchant_id, node_id, depth=depth, only_approved=True)
    return envelope(KGNeighborhoodResponse(
        nodes=[KGNodeOut.model_validate(n) for n in result["nodes"]],
        edges=[KGEdgeOut.model_validate(e) for e in result["edges"]],
    ).model_dump(mode="json"))


@router.get("/edges/pending")
def list_pending_edges(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    source_alias = aliased(KGNode)
    target_alias = aliased(KGNode)

    rows = db.execute(
        select(KGEdge, source_alias.label, target_alias.label)
        .join(source_alias, KGEdge.source_node_id == source_alias.id)
        .join(target_alias, KGEdge.target_node_id == target_alias.id)
        .where(KGEdge.merchant_id == current_user.merchant_id, KGEdge.status == "pending")
        .order_by(KGEdge.weight.desc())
    ).all()

    return envelope([
        PendingEdgeOut(
            id=edge.id, source_label=source_label, target_label=target_label,
            relationship_type=edge.relationship_type, weight=edge.weight,
            evidence=edge.evidence, created_at=edge.created_at,
        ).model_dump(mode="json")
        for edge, source_label, target_label in rows
    ])


@router.post("/edges/{edge_id}/approve")
def approve_edge(
    edge_id: UUID,
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
    db: Session = Depends(get_tenant_db),
):
    edge = db.get(KGEdge, edge_id)
    if edge is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Edge not found")
    edge.status = "approved"
    edge.reviewed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(edge)
    return envelope(KGEdgeOut.model_validate(edge).model_dump(mode="json"))


@router.post("/edges/{edge_id}/reject")
def reject_edge(
    edge_id: UUID,
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
    db: Session = Depends(get_tenant_db),
):
    edge = db.get(KGEdge, edge_id)
    if edge is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Edge not found")
    edge.status = "rejected"
    edge.reviewed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(edge)
    return envelope(KGEdgeOut.model_validate(edge).model_dump(mode="json"))


@router.post("/edges", status_code=status.HTTP_201_CREATED)
def create_edge(
    payload: KGEdgeCreate,
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
    db: Session = Depends(get_tenant_db),
):
    if payload.relationship_type not in RELATIONSHIP_TYPES:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"relationship_type must be one of {', '.join(RELATIONSHIP_TYPES)}")

    for node_id in (payload.source_node_id, payload.target_node_id):
        if db.get(KGNode, node_id) is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, f"Node {node_id} not found")

    existing = db.scalar(select(KGEdge).where(
        KGEdge.merchant_id == current_user.merchant_id, KGEdge.source_node_id == payload.source_node_id,
        KGEdge.target_node_id == payload.target_node_id, KGEdge.relationship_type == payload.relationship_type,
    ))
    if existing:
        raise HTTPException(status.HTTP_409_CONFLICT, "This edge already exists")

    edge = KGEdge(
        merchant_id=current_user.merchant_id, source_node_id=payload.source_node_id,
        target_node_id=payload.target_node_id, relationship_type=payload.relationship_type,
        weight=payload.weight, source="manual", status="approved",  # manual edges are auto-approved — a merchant typed it in themselves
        reviewed_at=datetime.now(timezone.utc),
    )
    db.add(edge)
    db.commit()
    db.refresh(edge)
    return envelope(KGEdgeOut.model_validate(edge).model_dump(mode="json"))


@router.delete("/edges/{edge_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_edge(
    edge_id: UUID,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    edge = db.get(KGEdge, edge_id)
    if edge is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Edge not found")
    db.delete(edge)
    db.commit()
