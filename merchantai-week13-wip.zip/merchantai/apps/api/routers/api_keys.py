from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.api_keys import generate_api_key
from core.response import envelope
from core.tenancy import CurrentUser, get_tenant_db, require_role
from models.api_key import ApiKey
from schemas.api_key import ApiKeyCreate, ApiKeyCreateResponse, ApiKeyOut

router = APIRouter(prefix="/api-keys", tags=["api-keys"])

VALID_SCOPES = {"widget", "admin", "analytics"}


@router.get("")
def list_api_keys(current_user: CurrentUser = Depends(require_role("owner", "admin")), db: Session = Depends(get_tenant_db)):
    keys = db.scalars(select(ApiKey).order_by(ApiKey.created_at.desc())).all()
    return envelope([ApiKeyOut.model_validate(k, from_attributes=True).model_dump(mode="json") for k in keys])


@router.post("", status_code=status.HTTP_201_CREATED)
def create_api_key(
    payload: ApiKeyCreate,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    invalid_scopes = set(payload.scopes) - VALID_SCOPES
    if invalid_scopes:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Invalid scopes: {', '.join(invalid_scopes)}. Valid scopes: {', '.join(VALID_SCOPES)}")

    plaintext, key_hash, display_prefix = generate_api_key()
    api_key = ApiKey(merchant_id=current_user.merchant_id, key_hash=key_hash, display_prefix=display_prefix, label=payload.label, scopes=payload.scopes)
    db.add(api_key)
    db.commit()
    db.refresh(api_key)

    return envelope(ApiKeyCreateResponse(
        id=api_key.id, label=api_key.label, display_prefix=api_key.display_prefix, scopes=api_key.scopes,
        last_used_at=None, created_at=api_key.created_at, revoked_at=None, plaintext_key=plaintext,
    ).model_dump(mode="json"))


@router.delete("/{key_id}", status_code=status.HTTP_204_NO_CONTENT)
def revoke_api_key(key_id: UUID, current_user: CurrentUser = Depends(require_role("owner", "admin")), db: Session = Depends(get_tenant_db)):
    api_key = db.get(ApiKey, key_id)
    if api_key is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "API key not found")
    # Revoke rather than delete — a revoked key still shows in the list with
    # its last_used_at history, useful for auditing what a leaked key touched.
    api_key.revoked_at = datetime.now(timezone.utc)
    db.commit()
