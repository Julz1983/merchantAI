from uuid import UUID

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db
from models.catalogue import Brand, Category

router = APIRouter(tags=["catalogue"])


class CategoryOut(BaseModel):
    id: UUID
    name: str
    parent_id: UUID | None
    model_config = {"from_attributes": True}


class BrandOut(BaseModel):
    id: UUID
    name: str
    model_config = {"from_attributes": True}


@router.get("/categories")
def list_categories(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    categories = db.scalars(select(Category).order_by(Category.name)).all()
    return envelope([CategoryOut.model_validate(c).model_dump(mode="json") for c in categories])


@router.get("/brands")
def list_brands(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    brands = db.scalars(select(Brand).order_by(Brand.name)).all()
    return envelope([BrandOut.model_validate(b).model_dump(mode="json") for b in brands])
