from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from core.rate_limit import rate_limit_by_merchant
from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db, require_role
from engines.auth_tenancy.user_service import (
    UserError, change_own_password, create_user, delete_user, list_users, update_user,
)
from schemas.user import PasswordChange, UserCreate, UserOut, UserUpdate

router = APIRouter(prefix="/users", tags=["users"])

_STATUS_FOR_CODE = {
    "forbidden": status.HTTP_403_FORBIDDEN,
    "not_found": status.HTTP_404_NOT_FOUND,
    "conflict": status.HTTP_409_CONFLICT,
    "invalid": status.HTTP_400_BAD_REQUEST,
}


def _raise(exc: UserError):
    raise HTTPException(_STATUS_FOR_CODE.get(exc.code, status.HTTP_400_BAD_REQUEST), str(exc)) from exc


def _out(user) -> dict:
    return UserOut.model_validate(user).model_dump(mode="json")


@router.get("")
def get_users(current_user: CurrentUser = Depends(require_role("owner", "admin")), db: Session = Depends(get_tenant_db)):
    return envelope([_out(u) for u in list_users(db, current_user.merchant_id)])


@router.post("", status_code=status.HTTP_201_CREATED)
def post_user(
    payload: UserCreate,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
    _rate_limit: None = Depends(rate_limit_by_merchant("user_create", limit=20, window_seconds=3600)),
):
    try:
        user = create_user(db, current_user.merchant_id, current_user.role, payload.email, payload.password, payload.role)
    except UserError as exc:
        _raise(exc)
    db.commit()
    db.refresh(user)
    return envelope(_out(user))


# Declared before the /{user_id} routes so "me" is never parsed as a UUID.
@router.post("/me/password", status_code=status.HTTP_204_NO_CONTENT)
def post_change_password(payload: PasswordChange, current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    try:
        change_own_password(db, current_user.merchant_id, current_user.user_id, payload.current_password, payload.new_password)
    except UserError as exc:
        _raise(exc)
    db.commit()


@router.patch("/{user_id}")
def patch_user(
    user_id: UUID,
    payload: UserUpdate,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    try:
        user = update_user(db, current_user.merchant_id, current_user.user_id, current_user.role, user_id, payload.role, payload.password)
    except UserError as exc:
        _raise(exc)
    db.commit()
    db.refresh(user)
    return envelope(_out(user))


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_user(user_id: UUID, current_user: CurrentUser = Depends(require_role("owner", "admin")), db: Session = Depends(get_tenant_db)):
    try:
        delete_user(db, current_user.merchant_id, current_user.user_id, current_user.role, user_id)
    except UserError as exc:
        _raise(exc)
    db.commit()
