from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import ValidationError
from sqlalchemy.orm import Session

from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db, require_role
from models.merchant import Merchant
from models.widget_settings import WidgetSettings
from schemas.settings import (
    AIPersona, AIPersonaUpdate, BrandColors, MerchantSettings, MerchantSettingsUpdate,
    WidgetSettingsOut, WidgetSettingsUpdate,
)

router = APIRouter(prefix="/settings", tags=["settings"])

DEFAULT_GREETING = "Hi! How can I help you find what you need?"


def _get_merchant(db: Session, current_user: CurrentUser) -> Merchant:
    merchant = db.get(Merchant, current_user.merchant_id)
    if merchant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Merchant not found")
    return merchant


def _merchant_out(m: Merchant) -> dict:
    try:
        colours = BrandColors(**(m.brand_colors or {}))
    except ValidationError:
        colours = BrandColors()  # stale/invalid stored value — show blanks rather than 500
    return MerchantSettings(name=m.name, logo_url=m.logo_url, brand_colors=colours).model_dump(mode="json")


def _persona_out(m: Merchant) -> dict:
    try:
        persona = AIPersona(**(m.ai_persona or {}))
    except ValidationError:
        persona = AIPersona()
    return persona.model_dump(mode="json")


@router.get("/merchant")
def get_merchant_settings(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    return envelope(_merchant_out(_get_merchant(db, current_user)))


@router.patch("/merchant")
def update_merchant_settings(
    payload: MerchantSettingsUpdate,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    merchant = _get_merchant(db, current_user)
    data = payload.model_dump(exclude_unset=True)

    if data.get("name") is not None:
        merchant.name = data["name"].strip()
    if "logo_url" in data:
        merchant.logo_url = data["logo_url"] or None
    if data.get("brand_colors"):
        merged = dict(merchant.brand_colors or {})
        merged.update({k: v for k, v in data["brand_colors"].items() if v is not None})
        merchant.brand_colors = merged  # new dict object so the JSON column change is tracked

    db.commit()
    db.refresh(merchant)
    return envelope(_merchant_out(merchant))


@router.get("/ai-persona")
def get_ai_persona(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    return envelope(_persona_out(_get_merchant(db, current_user)))


@router.patch("/ai-persona")
def update_ai_persona(
    payload: AIPersonaUpdate,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    """Structured settings only — never raw prompt text (architecture §0.4).
    These values are composed into a fixed, audited system-prompt template."""
    merchant = _get_merchant(db, current_user)
    current = AIPersona(**_persona_out(merchant))
    updates = {k: v for k, v in payload.model_dump(exclude_unset=True).items() if v is not None}
    merchant.ai_persona = current.model_copy(update=updates).model_dump(mode="json")
    db.commit()
    db.refresh(merchant)
    return envelope(_persona_out(merchant))


@router.get("/widget")
def get_widget_settings(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    row = db.get(WidgetSettings, current_user.merchant_id)
    return envelope(WidgetSettingsOut(
        launcher_position=row.launcher_position if row else "bottom-right",
        greeting_message=row.greeting_message if row else DEFAULT_GREETING,
    ).model_dump(mode="json"))


@router.patch("/widget")
def update_widget_settings(
    payload: WidgetSettingsUpdate,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    row = db.get(WidgetSettings, current_user.merchant_id)
    if row is None:
        row = WidgetSettings(merchant_id=current_user.merchant_id, launcher_position="bottom-right", greeting_message=DEFAULT_GREETING, theme_overrides={})
        db.add(row)

    data = payload.model_dump(exclude_unset=True)
    if data.get("launcher_position") is not None:
        row.launcher_position = data["launcher_position"]
    if data.get("greeting_message") is not None:
        row.greeting_message = data["greeting_message"].strip()

    db.commit()
    db.refresh(row)
    return envelope(WidgetSettingsOut(launcher_position=row.launcher_position, greeting_message=row.greeting_message).model_dump(mode="json"))
