from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, Form, HTTPException, Query, UploadFile, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.db import SessionLocal, set_tenant_context
from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db, require_role
from engines.document_engine.embeddings import get_embedding_provider
from engines.document_engine.extractors import ExtractionError
from engines.document_engine.pipeline import process_document
from engines.document_engine.vector_store import delete_document_chunks, search as vector_search
from models.document import DOC_TYPES, Document
from schemas.document import DocumentOut, DocumentSearchResult

router = APIRouter(prefix="/documents", tags=["documents"])

MAX_UPLOAD_BYTES = 20 * 1024 * 1024


async def _read_upload(file: UploadFile) -> bytes:
    file_bytes = await file.read()
    if len(file_bytes) > MAX_UPLOAD_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "File too large (max 20MB)")
    if not file_bytes:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Uploaded file is empty")
    return file_bytes


def _process_document_job(document_id: UUID, merchant_id: UUID, file_bytes: bytes) -> None:
    """Own session, same reasoning as products.py's _process_import_job —
    the request's session is closed by the time a BackgroundTask runs."""
    db: Session = SessionLocal()
    try:
        set_tenant_context(db, merchant_id)
        document = db.get(Document, document_id)
        if document is None:
            return
        process_document(db, merchant_id, document, file_bytes)
    finally:
        db.close()


@router.post("", status_code=status.HTTP_201_CREATED)
async def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile,
    title: str | None = Form(None),
    doc_type: str = Form("other"),
    current_user: CurrentUser = Depends(require_role("owner", "admin", "editor")),
    db: Session = Depends(get_tenant_db),
):
    if doc_type not in DOC_TYPES:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"doc_type must be one of {', '.join(DOC_TYPES)}")

    file_bytes = await _read_upload(file)

    document = Document(
        merchant_id=current_user.merchant_id,
        title=title or (file.filename or "Untitled document"),
        doc_type=doc_type,
        original_filename=file.filename or "upload",
        status="processing",
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    background_tasks.add_task(_process_document_job, document.id, current_user.merchant_id, file_bytes)

    return envelope(DocumentOut.model_validate(document).model_dump(mode="json"))


@router.get("")
def list_documents(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    documents = db.scalars(select(Document).order_by(Document.created_at.desc())).all()
    return envelope([DocumentOut.model_validate(d).model_dump(mode="json") for d in documents])


@router.get("/search")
def search_documents(
    q: str = Query(..., min_length=1),
    limit: int = Query(5, ge=1, le=20),
    current_user: CurrentUser = Depends(get_current_user),
):
    """
    Manual verification endpoint for the Week-3 exit criteria ("uploaded PDF
    is searchable via a test vector query") — embeds the query with the same
    provider used at ingest time and returns the nearest chunks. The AI
    Engine (Week 5) calls vector_store.search directly as part of hybrid
    retrieval rather than going through this HTTP endpoint; this route stays
    as a useful diagnostic / support tool either way.
    """
    provider = get_embedding_provider()
    query_vector = provider.embed([q])[0]
    results = vector_search(current_user.merchant_id, query_vector, limit=limit, content_type="document_chunk")
    return envelope([
        DocumentSearchResult(
            chunk_id=str(r["id"]),
            score=r["score"],
            document_id=r["payload"].get("document_id", ""),
            document_title=r["payload"].get("document_title", ""),
            chunk_index=r["payload"].get("chunk_index", 0),
            page_number=r["payload"].get("page_number"),
            content=r["payload"].get("content", ""),
        ).model_dump()
        for r in results
    ])


@router.get("/{document_id}")
def get_document(document_id: UUID, current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_tenant_db)):
    document = db.get(Document, document_id)
    if document is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    return envelope(DocumentOut.model_validate(document).model_dump(mode="json"))


@router.delete("/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(
    document_id: UUID,
    current_user: CurrentUser = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_tenant_db),
):
    document = db.get(Document, document_id)
    if document is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    delete_document_chunks(current_user.merchant_id, document_id)
    db.delete(document)  # cascades to document_chunks via FK ondelete=CASCADE
    db.commit()
