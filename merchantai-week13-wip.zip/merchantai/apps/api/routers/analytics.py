from collections import Counter
from datetime import datetime, timedelta, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from core.response import envelope
from core.tenancy import CurrentUser, get_current_user, get_tenant_db
from models.analytics import EVENT_TYPES, AnalyticsEvent
from models.document import Document, DocumentChunk
from schemas.analytics import AnalyticsEventOut, AnalyticsSummaryResponse, CitedDocumentItem, EventCounts, MissingQueryItem

router = APIRouter(prefix="/analytics", tags=["analytics"])

_RANGE_DAYS = {"7d": 7, "30d": 30, "90d": 90}


def _range_start(range_param: str) -> datetime | None:
    days = _RANGE_DAYS.get(range_param)
    if days is None:
        return None  # "all" or an unrecognized value — no lower bound
    return datetime.now(timezone.utc) - timedelta(days=days)


@router.get("/summary")
def get_analytics_summary(
    range: str = Query("30d", description="7d | 30d | 90d | all"),
    current_user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_tenant_db),
):
    since = _range_start(range)

    count_query = select(AnalyticsEvent.event_type, func.count()).where(AnalyticsEvent.merchant_id == current_user.merchant_id)
    if since:
        count_query = count_query.where(AnalyticsEvent.created_at >= since)
    count_query = count_query.group_by(AnalyticsEvent.event_type)

    counts_by_type = dict(db.execute(count_query).all())
    counts = EventCounts(**{k: counts_by_type.get(k, 0) for k in EVENT_TYPES})

    # Top missing-product queries — the genuine merchandising insight from
    # architecture Journey C ("demand signal for products they don't stock").
    missing_query = select(AnalyticsEvent.payload).where(
        AnalyticsEvent.merchant_id == current_user.merchant_id, AnalyticsEvent.event_type == "product_missing"
    )
    if since:
        missing_query = missing_query.where(AnalyticsEvent.created_at >= since)
    missing_payloads = db.scalars(missing_query).all()
    question_counts = Counter(p.get("question", "").strip().lower() for p in missing_payloads if p.get("question"))
    top_missing = [MissingQueryItem(question=q, count=c) for q, c in question_counts.most_common(10)]

    # Most-cited documents — aggregate document_used events' chunk_ids back
    # to their parent document. Done in Python rather than a JSON-array SQL
    # aggregation: simpler to read, and at MVP event volumes the event count
    # itself is the bottleneck long before this loop would be.
    doc_used_query = select(AnalyticsEvent.payload).where(
        AnalyticsEvent.merchant_id == current_user.merchant_id, AnalyticsEvent.event_type == "document_used"
    )
    if since:
        doc_used_query = doc_used_query.where(AnalyticsEvent.created_at >= since)
    doc_used_payloads = db.scalars(doc_used_query).all()

    all_chunk_ids: list[str] = [cid for p in doc_used_payloads for cid in p.get("chunk_ids", [])]
    most_cited_documents: list[CitedDocumentItem] = []
    if all_chunk_ids:
        chunk_to_doc = dict(db.execute(
            select(DocumentChunk.id, DocumentChunk.document_id).where(DocumentChunk.id.in_([UUID(c) for c in set(all_chunk_ids)]))
        ).all())
        doc_id_counts = Counter(chunk_to_doc[UUID(cid)] for cid in all_chunk_ids if UUID(cid) in chunk_to_doc)
        if doc_id_counts:
            titles = dict(db.execute(select(Document.id, Document.title).where(Document.id.in_(doc_id_counts.keys()))).all())
            most_cited_documents = [
                CitedDocumentItem(document_id=str(doc_id), document_title=titles.get(doc_id, "Unknown"), count=count)
                for doc_id, count in doc_id_counts.most_common(10)
            ]

    return envelope(AnalyticsSummaryResponse(
        range=range, counts=counts, top_missing_queries=top_missing, most_cited_documents=most_cited_documents,
    ).model_dump(mode="json"))


@router.get("/events")
def list_analytics_events(
    type: str | None = Query(None, alias="type"),
    range: str = Query("30d"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    current_user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_tenant_db),
):
    query = select(AnalyticsEvent).where(AnalyticsEvent.merchant_id == current_user.merchant_id)
    if type:
        query = query.where(AnalyticsEvent.event_type == type)
    since = _range_start(range)
    if since:
        query = query.where(AnalyticsEvent.created_at >= since)

    query = query.order_by(AnalyticsEvent.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    events = db.scalars(query).all()

    return envelope([
        AnalyticsEventOut(id=str(e.id), event_type=e.event_type, payload=e.payload, created_at=e.created_at).model_dump(mode="json")
        for e in events
    ])
