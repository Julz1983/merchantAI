from fastapi import APIRouter, Depends, HTTPException, status
from jose import JWTError
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from core.db import get_db
from core.rate_limit import rate_limit_by_ip
from core.response import envelope
from core.security import create_access_token, create_refresh_token, decode_token, verify_password
from core.tenancy import CurrentUser, get_current_user
from models.merchant import Merchant
from models.user import User
from schemas.auth import LoginRequest, MeResponse, RefreshRequest, TokenResponse

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login")
def login(
    payload: LoginRequest,
    db: Session = Depends(get_db),
    _rate_limit: None = Depends(rate_limit_by_ip("login", limit=10, window_seconds=300)),
):
    # Pre-tenant-context lookup: email isn't scoped to a merchant at this point,
    # so this is the one query in the system that intentionally runs without
    # RLS tenant filtering — it's a plain lookup by unique email.
    user = db.scalar(select(User).where(func.lower(User.email) == payload.email.lower()))
    if user is None or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")

    merchant = db.get(Merchant, user.merchant_id)
    if merchant is None or merchant.status == "suspended":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Merchant account is not active")

    tokens = TokenResponse(
        access_token=create_access_token(user.id, user.merchant_id, user.role),
        refresh_token=create_refresh_token(user.id, user.merchant_id, user.role),
    )
    return envelope(tokens.model_dump())


@router.post("/refresh")
def refresh(payload: RefreshRequest):
    try:
        token_payload = decode_token(payload.refresh_token)
    except JWTError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired refresh token") from exc

    if token_payload.type != "refresh":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Access token used where refresh token required")

    from uuid import UUID  # local import keeps top-level imports focused

    tokens = TokenResponse(
        access_token=create_access_token(UUID(token_payload.sub), UUID(token_payload.merchant_id), token_payload.role),
        refresh_token=create_refresh_token(UUID(token_payload.sub), UUID(token_payload.merchant_id), token_payload.role),
    )
    return envelope(tokens.model_dump())


@router.get("/me")
def me(current_user: CurrentUser = Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.get(User, current_user.user_id)
    merchant = db.get(Merchant, current_user.merchant_id)
    if user is None or merchant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User or merchant not found")

    response = MeResponse(
        user_id=user.id,
        merchant_id=merchant.id,
        email=user.email,
        role=user.role,
        merchant_name=merchant.name,
    )
    return envelope(response.model_dump(mode="json"))
