"""quotes + quote_items + RLS

Revision ID: 0011
Revises: 0010
Create Date: 2026-10-05

Quote Builder module. A quote snapshots a basket's contents at creation
time — sku/name/price are copied onto quote_items rather than joined live
to products, so a quote still shows what was actually quoted even if the
merchant later changes prices or deletes the product.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0011"
down_revision = "0010"
branch_labels = None
depends_on = None

RLS_TABLES = ("quotes", "quote_items")


def upgrade() -> None:
    op.create_table(
        "quotes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("session_id", sa.String(255), nullable=False),
        sa.Column("reference_number", sa.String(32), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="draft"),
        sa.Column("subtotal", sa.Numeric(10, 2), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_quotes_merchant_id", "quotes", ["merchant_id"])
    op.create_unique_constraint("uq_quotes_merchant_reference", "quotes", ["merchant_id", "reference_number"])

    op.create_table(
        "quote_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("quote_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("quotes.id", ondelete="CASCADE"), nullable=False),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("product_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("products.id", ondelete="SET NULL"), nullable=True),
        sa.Column("sku", sa.String(128), nullable=False),
        sa.Column("name", sa.String(500), nullable=False),
        sa.Column("unit_price", sa.Numeric(10, 2), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("line_total", sa.Numeric(10, 2), nullable=False),
    )
    op.create_index("ix_quote_items_merchant_id", "quote_items", ["merchant_id"])
    op.create_index("ix_quote_items_quote_id", "quote_items", ["quote_id"])

    for table in RLS_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {table}_tenant_select ON {table} FOR SELECT USING (merchant_id::text = current_setting('app.current_merchant_id', true))")
        op.execute(f"CREATE POLICY {table}_tenant_write ON {table} FOR INSERT WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))")
        op.execute(f"CREATE POLICY {table}_tenant_update ON {table} FOR UPDATE USING (merchant_id::text = current_setting('app.current_merchant_id', true)) WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))")
        op.execute(f"CREATE POLICY {table}_tenant_delete ON {table} FOR DELETE USING (merchant_id::text = current_setting('app.current_merchant_id', true))")


def downgrade() -> None:
    for table in RLS_TABLES:
        for policy in ("select", "write", "update", "delete"):
            op.execute(f"DROP POLICY IF EXISTS {table}_tenant_{policy} ON {table}")
    op.drop_table("quote_items")
    op.drop_table("quotes")
