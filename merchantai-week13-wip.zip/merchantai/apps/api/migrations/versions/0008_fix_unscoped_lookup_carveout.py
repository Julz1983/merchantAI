"""fix unscoped-lookup carve-outs: connection reuse means empty context can be NULL or ''

Revision ID: 0008
Revises: 0007
Create Date: 2026-10-06

Migration 0003 replaced users_tenant_select's `current_setting(...) = ''`
check with `current_setting(...) IS NULL`, reasoning that a truly-unset GUC
returns NULL, not ''. That was correct for a freshly-opened connection that
has never touched app.current_merchant_id — but wrong for a *pooled*
connection that has: Postgres's behavior for a custom (extension-less) GUC
set via set_config(..., is_local=true) is to return NULL before the GUC has
ever been touched on that physical connection, but '' (empty string, not
NULL) once it has been set at least once and the transaction that set it
ends — for the remaining lifetime of that connection, regardless of
commit/rollback.

In other words: the same connection checked out for two different requests
in sequence can legitimately present "no tenant context" as NULL the first
time and '' every time after. This was invisible in isolated testing
(migration 0003 was verified against a single request) and only surfaced
once widget auth was exercised across multiple sequential requests reusing
a pooled connection — a second request always got "Invalid or revoked API
key" even for a valid, unrevoked key. The correct carve-out checks both.
"""
from alembic import op

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None

_TABLES = ("users", "api_keys")


def upgrade() -> None:
    for table in _TABLES:
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_select ON {table}")
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_select ON {table}
            FOR SELECT
            USING (
                merchant_id::text = current_setting('app.current_merchant_id', true)
                OR current_setting('app.current_merchant_id', true) IS NULL
                OR current_setting('app.current_merchant_id', true) = ''
            )
            """
        )


def downgrade() -> None:
    for table in _TABLES:
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_select ON {table}")
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_select ON {table}
            FOR SELECT
            USING (
                merchant_id::text = current_setting('app.current_merchant_id', true)
                OR current_setting('app.current_merchant_id', true) IS NULL
            )
            """
        )
