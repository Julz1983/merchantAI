"""baskets + basket_items + RLS

Revision ID: 0010
Revises: 0009
Create Date: 2026-09-08

Basket Builder module (architecture Journey B: "Assistant offers to build a
shopping list from the conversation"). Session-scoped, same tenancy pattern
as chats/chat_messages — anonymous widget sessions, no customer account
required.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0010"
down_revision = "0009"
branch_labels = None
depends_on = None

RLS_TABLES = ("baskets", "basket_items")


def upgrade() -> None:
    op.create_table(
        "baskets",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("session_id", sa.String(255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_baskets_merchant_id", "baskets", ["merchant_id"])
    op.create_index("ix_baskets_merchant_session", "baskets", ["merchant_id", "session_id"], unique=True)

    op.create_table(
        "basket_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("basket_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("baskets.id", ondelete="CASCADE"), nullable=False),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("product_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("source", sa.String(16), nullable=False, server_default="assistant"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_basket_items_merchant_id", "basket_items", ["merchant_id"])
    op.create_index("ix_basket_items_basket_id", "basket_items", ["basket_id"])
    op.create_unique_constraint("uq_basket_items_basket_product", "basket_items", ["basket_id", "product_id"])

    for table in RLS_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_select ON {table}
            FOR SELECT
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_write ON {table}
            FOR INSERT
            WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_update ON {table}
            FOR UPDATE
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_delete ON {table}
            FOR DELETE
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )


def downgrade() -> None:
    for table in RLS_TABLES:
        for policy in ("select", "write", "update", "delete"):
            op.execute(f"DROP POLICY IF EXISTS {table}_tenant_{policy} ON {table}")
    op.drop_table("basket_items")
    op.drop_table("baskets")
