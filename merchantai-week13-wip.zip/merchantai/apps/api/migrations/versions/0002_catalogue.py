"""catalogue: brands, categories, products, import_jobs + RLS

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-18

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

RLS_TABLES = ("brands", "categories", "products", "import_jobs")


def upgrade() -> None:
    op.create_table(
        "brands",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_brands_merchant_id", "brands", ["merchant_id"])
    op.create_unique_constraint("uq_brands_merchant_name", "brands", ["merchant_id", "name"])

    op.create_table(
        "categories",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("parent_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("categories.id", ondelete="SET NULL"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_categories_merchant_id", "categories", ["merchant_id"])
    op.create_unique_constraint("uq_categories_merchant_name", "categories", ["merchant_id", "name"])

    op.create_table(
        "products",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sku", sa.String(128), nullable=False),
        sa.Column("name", sa.String(500), nullable=False),
        sa.Column("description", sa.String(), nullable=True),
        sa.Column("category_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("categories.id", ondelete="SET NULL"), nullable=True),
        sa.Column("brand_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("brands.id", ondelete="SET NULL"), nullable=True),
        sa.Column("price", sa.Numeric(10, 2), nullable=True),
        sa.Column("currency", sa.String(8), nullable=False, server_default="GBP"),
        sa.Column("images", sa.JSON(), nullable=False, server_default="[]"),
        sa.Column("product_url", sa.String(1024), nullable=True),
        sa.Column("specifications", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("attributes", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("stock_status", sa.String(32), nullable=False, server_default="unknown"),
        sa.Column("embedding_id", sa.String(128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_products_merchant_id", "products", ["merchant_id"])
    op.create_unique_constraint("uq_products_merchant_sku", "products", ["merchant_id", "sku"])
    op.create_index("ix_products_merchant_category", "products", ["merchant_id", "category_id"])
    op.create_index("ix_products_merchant_brand", "products", ["merchant_id", "brand_id"])
    op.create_index(
        "ix_products_name_trgm",
        "products",
        ["merchant_id", "name"],
    )

    op.create_table(
        "import_jobs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("filename", sa.String(512), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, server_default="pending"),
        sa.Column("total_rows", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("processed_rows", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("created_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("updated_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("error_rows", sa.JSON(), nullable=False, server_default="[]"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_import_jobs_merchant_id", "import_jobs", ["merchant_id"])

    # ── RLS — same pattern as migration 0001. Catalogue tables have no
    # legitimate cross-tenant read case (unlike users/login), so these get
    # the strict form: no unset-context carve-out on SELECT. ───────────────
    for table in RLS_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_select ON {table}
            FOR SELECT
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_write ON {table}
            FOR INSERT
            WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_update ON {table}
            FOR UPDATE
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_delete ON {table}
            FOR DELETE
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )


def downgrade() -> None:
    for table in RLS_TABLES:
        for policy in ("select", "write", "update", "delete"):
            op.execute(f"DROP POLICY IF EXISTS {table}_tenant_{policy} ON {table}")
    op.drop_table("import_jobs")
    op.drop_table("products")
    op.drop_table("categories")
    op.drop_table("brands")
