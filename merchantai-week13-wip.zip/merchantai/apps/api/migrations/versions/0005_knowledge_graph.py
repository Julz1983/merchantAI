"""knowledge graph: kg_nodes, kg_edges + RLS

Revision ID: 0005
Revises: 0004
Create Date: 2026-09-01

Adds a `status` column (pending | approved | rejected) to kg_edges beyond
what architecture §3's table listing originally sketched — needed to back
the review workflow the architecture doc's REST spec (§6) and KG design
(§4) already describe (`GET /kg/edges/pending`, approve/reject endpoints):
deterministic/manual edges are auto-approved, LLM-extracted edges start
pending and are never auto-published.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None

RLS_TABLES = ("kg_nodes", "kg_edges")


def upgrade() -> None:
    op.create_table(
        "kg_nodes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("node_type", sa.String(32), nullable=False),
        sa.Column("ref_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("label", sa.String(500), nullable=False),
        sa.Column("node_metadata", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_kg_nodes_merchant_id", "kg_nodes", ["merchant_id"])
    # Look up "the node for product X" without a table scan — this is the
    # hot path for both deterministic edge generation and LLM extraction.
    op.create_index("ix_kg_nodes_merchant_type_ref", "kg_nodes", ["merchant_id", "node_type", "ref_id"])

    op.create_table(
        "kg_edges",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("source_node_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("kg_nodes.id", ondelete="CASCADE"), nullable=False),
        sa.Column("target_node_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("kg_nodes.id", ondelete="CASCADE"), nullable=False),
        sa.Column("relationship_type", sa.String(32), nullable=False),
        sa.Column("weight", sa.Float(), nullable=False, server_default="1.0"),
        sa.Column("source", sa.String(16), nullable=False, server_default="manual"),
        sa.Column("status", sa.String(16), nullable=False, server_default="approved"),
        sa.Column("evidence", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_kg_edges_merchant_id", "kg_edges", ["merchant_id"])
    # Traversal indexes — both directions, since ALTERNATIVE/COMPATIBLE_WITH
    # are conceptually symmetric and callers may query from either side.
    op.create_index("ix_kg_edges_merchant_source", "kg_edges", ["merchant_id", "source_node_id"])
    op.create_index("ix_kg_edges_merchant_target", "kg_edges", ["merchant_id", "target_node_id"])
    op.create_index("ix_kg_edges_merchant_status", "kg_edges", ["merchant_id", "status"])
    # Avoid proposing/storing the exact same edge twice on re-import or
    # repeated LLM extraction runs.
    op.create_unique_constraint(
        "uq_kg_edges_dedupe", "kg_edges", ["merchant_id", "source_node_id", "target_node_id", "relationship_type"]
    )

    for table in RLS_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_select ON {table}
            FOR SELECT
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_write ON {table}
            FOR INSERT
            WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_update ON {table}
            FOR UPDATE
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )
        op.execute(
            f"""
            CREATE POLICY {table}_tenant_delete ON {table}
            FOR DELETE
            USING (merchant_id::text = current_setting('app.current_merchant_id', true))
            """
        )


def downgrade() -> None:
    for table in RLS_TABLES:
        for policy in ("select", "write", "update", "delete"):
            op.execute(f"DROP POLICY IF EXISTS {table}_tenant_{policy} ON {table}")
    op.drop_table("kg_edges")
    op.drop_table("kg_nodes")
