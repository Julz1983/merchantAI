"""widget_settings + fix api_keys RLS for unscoped key lookup

Revision ID: 0007
Revises: 0006
Create Date: 2026-09-29

api_keys needs the same SELECT policy carve-out that migration 0003 gave
users: widget authentication looks a key up by its hash *before* knowing
which merchant it belongs to (that's the whole point of the lookup), so it
runs on the unscoped session, same as login. Using the NULL-correct form
from the start this time (current_setting(...) IS NULL, not = '' — see
migration 0003's docstring for why the '' comparison was wrong).
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("api_keys", sa.Column("display_prefix", sa.String(32), nullable=False, server_default="mai_live_********"))
    op.alter_column("api_keys", "display_prefix", server_default=None)

    op.create_table(
        "widget_settings",
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("launcher_position", sa.String(16), nullable=False, server_default="bottom-right"),
        sa.Column("greeting_message", sa.String(500), nullable=False, server_default="Hi! How can I help you find what you need?"),
        sa.Column("theme_overrides", sa.JSON(), nullable=False, server_default="{}"),
    )
    op.execute("ALTER TABLE widget_settings ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE widget_settings FORCE ROW LEVEL SECURITY")
    op.execute(
        """
        CREATE POLICY widget_settings_tenant_select ON widget_settings
        FOR SELECT
        USING (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )
    op.execute(
        """
        CREATE POLICY widget_settings_tenant_write ON widget_settings
        FOR INSERT
        WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )
    op.execute(
        """
        CREATE POLICY widget_settings_tenant_update ON widget_settings
        FOR UPDATE
        USING (merchant_id::text = current_setting('app.current_merchant_id', true))
        WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )
    op.execute(
        """
        CREATE POLICY widget_settings_tenant_delete ON widget_settings
        FOR DELETE
        USING (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )

    op.execute("DROP POLICY IF EXISTS api_keys_tenant_select ON api_keys")
    op.execute(
        """
        CREATE POLICY api_keys_tenant_select ON api_keys
        FOR SELECT
        USING (
            merchant_id::text = current_setting('app.current_merchant_id', true)
            OR current_setting('app.current_merchant_id', true) IS NULL
        )
        """
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS api_keys_tenant_select ON api_keys")
    op.execute(
        """
        CREATE POLICY api_keys_tenant_select ON api_keys
        FOR SELECT
        USING (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )
    for policy in ("select", "write", "update", "delete"):
        op.execute(f"DROP POLICY IF EXISTS widget_settings_tenant_{policy} ON widget_settings")
    op.drop_table("widget_settings")
    op.drop_column("api_keys", "display_prefix")
