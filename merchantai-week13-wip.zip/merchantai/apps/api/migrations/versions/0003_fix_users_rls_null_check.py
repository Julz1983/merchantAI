"""fix users RLS policy: current_setting returns NULL when unset, not ''

Revision ID: 0003
Revises: 0002
Create Date: 2026-08-11

The original users_tenant_select policy (migration 0001) compared
current_setting('app.current_merchant_id', true) to an empty string to
detect "no tenant context set" (the case login legitimately needs, since it
looks a user up by email before knowing which merchant they belong to).

That comparison was wrong: current_setting(..., missing_ok=true) returns SQL
NULL when the setting has never been defined in the session, not ''. Since
`NULL = ''` evaluates to NULL (neither true nor false) in SQL, the intended
carve-out never actually matched — under a real non-superuser role (see
core/bootstrap_roles.py), this silently blocked the login lookup entirely.
It went unnoticed until testing against a restricted role instead of the
Postgres superuser, which bypasses RLS unconditionally and so never
exercised this path.
"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("DROP POLICY IF EXISTS users_tenant_select ON users")
    op.execute(
        """
        CREATE POLICY users_tenant_select ON users
        FOR SELECT
        USING (
            merchant_id::text = current_setting('app.current_merchant_id', true)
            OR current_setting('app.current_merchant_id', true) IS NULL
        )
        """
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS users_tenant_select ON users")
    op.execute(
        """
        CREATE POLICY users_tenant_select ON users
        FOR SELECT
        USING (
            merchant_id::text = current_setting('app.current_merchant_id', true)
            OR current_setting('app.current_merchant_id', true) = ''
        )
        """
    )
