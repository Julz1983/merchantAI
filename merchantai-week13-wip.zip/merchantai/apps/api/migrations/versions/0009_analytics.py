"""analytics_events + RLS

Revision ID: 0009
Revises: 0008
Create Date: 2026-10-13

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0009"
down_revision = "0008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "analytics_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("merchant_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_type", sa.String(32), nullable=False),
        sa.Column("chat_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("chats.id", ondelete="SET NULL"), nullable=True),
        sa.Column("payload", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    # (merchant_id, event_type, created_at) is the hot path for the
    # analytics summary — filter by type, order/range by time, per merchant.
    op.create_index("ix_analytics_events_merchant_type_created", "analytics_events", ["merchant_id", "event_type", "created_at"])
    op.create_index("ix_analytics_events_chat_id", "analytics_events", ["chat_id"])

    op.execute("ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE analytics_events FORCE ROW LEVEL SECURITY")
    op.execute(
        """
        CREATE POLICY analytics_events_tenant_select ON analytics_events
        FOR SELECT
        USING (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )
    op.execute(
        """
        CREATE POLICY analytics_events_tenant_write ON analytics_events
        FOR INSERT
        WITH CHECK (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )
    op.execute(
        """
        CREATE POLICY analytics_events_tenant_delete ON analytics_events
        FOR DELETE
        USING (merchant_id::text = current_setting('app.current_merchant_id', true))
        """
    )
    # No UPDATE policy on purpose — analytics events are append-only facts
    # about what happened; nothing in the app ever edits one after the fact.


def downgrade() -> None:
    for policy in ("select", "write", "delete"):
        op.execute(f"DROP POLICY IF EXISTS analytics_events_tenant_{policy} ON analytics_events")
    op.drop_table("analytics_events")
