import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator

HEX_COLOUR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
MAX_EMPHASIZED_CATEGORIES = 10


class BrandColors(BaseModel):
    primary: str | None = None
    secondary: str | None = None
    accent: str | None = None

    @field_validator("primary", "secondary", "accent")
    @classmethod
    def _must_be_hex(cls, value: str | None) -> str | None:
        if value is not None and not HEX_COLOUR_RE.match(value):
            raise ValueError("must be a hex colour like #E3572A")
        return value


class MerchantSettings(BaseModel):
    name: str
    logo_url: str | None
    brand_colors: BrandColors


class MerchantSettingsUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=255)
    logo_url: str | None = Field(None, max_length=1024)  # "" clears it
    brand_colors: BrandColors | None = None

    @field_validator("logo_url")
    @classmethod
    def _http_only(cls, value: str | None) -> str | None:
        # The logo URL is served to every visitor's browser via the widget
        # config — restricting to http(s) rules out javascript:/data: URLs.
        if value and not value.startswith(("http://", "https://")):
            raise ValueError("must start with http:// or https://")
        return value


def _clean_category(value: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise ValueError("categories can't be blank")
    if len(cleaned) > 100:
        raise ValueError("categories must be 100 characters or fewer")
    # These strings are composed into the LLM system prompt (see
    # engines/ai_engine/prompt_templates/system_prompt.py) — control
    # characters/newlines would let a category smuggle in its own
    # instructions, so they're rejected at the door as well as flattened
    # at prompt-build time.
    if any(ord(ch) < 32 for ch in cleaned):
        raise ValueError("categories can't contain control characters or line breaks")
    return cleaned


class AIPersona(BaseModel):
    tone: Literal["formal", "casual"] = "formal"
    upsell_aggressiveness: Literal["low", "medium", "high"] = "medium"
    emphasized_categories: list[str] = Field(default_factory=list, max_length=MAX_EMPHASIZED_CATEGORIES)

    @field_validator("emphasized_categories")
    @classmethod
    def _clean(cls, values: list[str]) -> list[str]:
        return [_clean_category(v) for v in values]


class AIPersonaUpdate(BaseModel):
    tone: Literal["formal", "casual"] | None = None
    upsell_aggressiveness: Literal["low", "medium", "high"] | None = None
    emphasized_categories: list[str] | None = Field(None, max_length=MAX_EMPHASIZED_CATEGORIES)

    @field_validator("emphasized_categories")
    @classmethod
    def _clean(cls, values: list[str] | None) -> list[str] | None:
        return None if values is None else [_clean_category(v) for v in values]


class WidgetSettingsOut(BaseModel):
    launcher_position: Literal["bottom-right", "bottom-left"]
    greeting_message: str


class WidgetSettingsUpdate(BaseModel):
    launcher_position: Literal["bottom-right", "bottom-left"] | None = None
    greeting_message: str | None = Field(None, min_length=1, max_length=500)
