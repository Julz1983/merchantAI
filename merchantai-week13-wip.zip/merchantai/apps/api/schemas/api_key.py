from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class ApiKeyCreate(BaseModel):
    label: str
    scopes: list[str] = ["widget"]


class ApiKeyOut(BaseModel):
    id: UUID
    label: str
    display_prefix: str
    scopes: list[str]
    last_used_at: datetime | None
    created_at: datetime
    revoked_at: datetime | None


class ApiKeyCreateResponse(ApiKeyOut):
    # Only ever present in the create response — the plaintext key is never
    # stored and never retrievable again after this one response.
    plaintext_key: str
