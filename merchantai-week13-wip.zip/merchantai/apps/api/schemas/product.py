from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class ProductOut(BaseModel):
    id: UUID
    sku: str
    name: str
    description: str | None
    category_id: UUID | None
    category_name: str | None = None
    brand_id: UUID | None
    brand_name: str | None = None
    price: float | None
    currency: str
    images: list[str]
    product_url: str | None
    specifications: dict
    attributes: dict
    stock_status: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ProductListResponse(BaseModel):
    items: list[ProductOut]
    total: int
    page: int
    page_size: int


class ProductCreate(BaseModel):
    sku: str
    name: str
    description: str | None = None
    category_id: UUID | None = None
    brand_id: UUID | None = None
    price: float | None = None
    images: list[str] = []
    product_url: str | None = None
    specifications: dict = {}
    attributes: dict = {}
    stock_status: str = "unknown"


class ProductUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    category_id: UUID | None = None
    brand_id: UUID | None = None
    price: float | None = None
    images: list[str] | None = None
    product_url: str | None = None
    specifications: dict | None = None
    attributes: dict | None = None
    stock_status: str | None = None
