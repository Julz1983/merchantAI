from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class DocumentOut(BaseModel):
    id: UUID
    title: str
    doc_type: str
    original_filename: str
    status: str
    error_message: str | None
    page_count: int | None
    chunk_count: int
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class DocumentSearchResult(BaseModel):
    chunk_id: str
    score: float
    document_id: str
    document_title: str
    chunk_index: int
    page_number: int | None
    content: str
