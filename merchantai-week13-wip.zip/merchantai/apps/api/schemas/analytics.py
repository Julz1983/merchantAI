from datetime import datetime

from pydantic import BaseModel


class EventCounts(BaseModel):
    question: int = 0
    recommendation: int = 0
    click: int = 0
    product_found: int = 0
    product_missing: int = 0
    document_used: int = 0
    kg_path_used: int = 0
    conversion: int = 0
    basket_add: int = 0


class MissingQueryItem(BaseModel):
    question: str
    count: int


class CitedDocumentItem(BaseModel):
    document_id: str
    document_title: str
    count: int


class AnalyticsSummaryResponse(BaseModel):
    range: str
    counts: EventCounts
    top_missing_queries: list[MissingQueryItem]
    most_cited_documents: list[CitedDocumentItem]


class AnalyticsEventOut(BaseModel):
    id: str
    event_type: str
    payload: dict
    created_at: datetime
