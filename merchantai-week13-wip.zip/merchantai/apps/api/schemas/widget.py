from datetime import datetime

from pydantic import BaseModel


class WidgetConfigResponse(BaseModel):
    """Public-safe fields only — this is served to anyone with a valid
    widget-scoped API key, which in practice means anyone who can view the
    merchant's website source. Never include internal ids beyond merchant
    name/branding, never include settings that could leak other merchants'
    data (there aren't any here, since this is entirely this-merchant-scoped)."""
    merchant_name: str
    logo_url: str | None
    brand_colors: dict
    launcher_position: str
    greeting_message: str


class WidgetChatRequest(BaseModel):
    session_id: str
    message: str


class WidgetClickRequest(BaseModel):
    session_id: str
    product_id: str
    sku: str


class BasketAddRequest(BaseModel):
    session_id: str
    product_id: str
    quantity: int = 1
    source: str = "manual"  # "manual" (customer clicked add) | "assistant" (from a chat recommendation)


class BasketUpdateQuantityRequest(BaseModel):
    session_id: str
    quantity: int


class BasketItemOut(BaseModel):
    id: str
    product_id: str
    sku: str
    name: str
    price: float | None
    stock_status: str
    quantity: int
    line_total: float | None
    source: str


class BasketOut(BaseModel):
    id: str
    items: list[BasketItemOut]
    item_count: int
    subtotal: float | None


class CalculateQuantityRequest(BaseModel):
    product_id: str
    area_m2: float | None = None
    length_m: float | None = None
    width_m: float | None = None
    waste_factor: float = 0.10


class CalculateQuantityResponse(BaseModel):
    product_id: str
    sku: str
    name: str
    area_m2: float
    waste_factor: float
    coverage_per_unit_m2: float
    units_needed: int
    basis: str


class CreateQuoteRequest(BaseModel):
    session_id: str


class QuoteItemOut(BaseModel):
    sku: str
    name: str
    unit_price: float
    quantity: int
    line_total: float


class QuoteOut(BaseModel):
    id: str
    reference_number: str
    status: str
    subtotal: float
    items: list[QuoteItemOut]
    created_at: datetime
    expires_at: datetime
    is_expired: bool
