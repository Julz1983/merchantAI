from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, EmailStr


class UserOut(BaseModel):
    id: UUID
    email: str
    role: str
    created_at: datetime

    model_config = {"from_attributes": True}


class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role: str = "viewer"


class UserUpdate(BaseModel):
    role: str | None = None
    password: str | None = None


class PasswordChange(BaseModel):
    current_password: str
    new_password: str
