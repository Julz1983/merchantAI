from datetime import datetime

from pydantic import BaseModel


class ChatMessageRequest(BaseModel):
    session_id: str
    message: str


class SuggestedProductOut(BaseModel):
    id: str
    sku: str
    name: str
    price: float | None
    stock_status: str
    reason: str


class ChatMessageResponse(BaseModel):
    reply: str
    citations: dict
    suggested_products: list[SuggestedProductOut]


class ChatMessageHistoryItem(BaseModel):
    role: str
    content: str
    citations: dict
    created_at: datetime
