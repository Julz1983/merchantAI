from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class KGNodeOut(BaseModel):
    id: UUID
    node_type: str
    ref_id: UUID | None
    label: str

    model_config = {"from_attributes": True}


class KGEdgeOut(BaseModel):
    id: UUID
    source_node_id: UUID
    target_node_id: UUID
    relationship_type: str
    weight: float
    source: str
    status: str
    evidence: str | None
    created_at: datetime
    reviewed_at: datetime | None

    model_config = {"from_attributes": True}


class KGNeighborhoodResponse(BaseModel):
    nodes: list[KGNodeOut]
    edges: list[KGEdgeOut]


class KGEdgeCreate(BaseModel):
    source_node_id: UUID
    target_node_id: UUID
    relationship_type: str
    weight: float = 1.0


class PendingEdgeOut(BaseModel):
    """Pending edge enriched with node labels — the review UI shouldn't need
    a second round-trip per card just to show product names."""
    id: UUID
    source_label: str
    target_label: str
    relationship_type: str
    weight: float
    evidence: str | None
    created_at: datetime
