from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class ImportInspectResponse(BaseModel):
    headers: list[str]
    suggested_mapping: dict[str, str]  # target_field -> source_header
    sample_rows: list[dict[str, str]]  # first few raw rows, for the mapping UI preview
    total_rows: int
    target_fields: list[str]
    required_fields: list[str]


class ImportJobOut(BaseModel):
    id: UUID
    filename: str
    status: str
    total_rows: int
    processed_rows: int
    created_count: int
    updated_count: int
    error_rows: list[dict]
    created_at: datetime
    completed_at: datetime | None

    model_config = {"from_attributes": True}
