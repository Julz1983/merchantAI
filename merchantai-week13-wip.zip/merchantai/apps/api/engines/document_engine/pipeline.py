from uuid import UUID

from sqlalchemy.orm import Session

from engines.document_engine.chunker import chunk_document
from engines.document_engine.embeddings import get_embedding_provider
from engines.document_engine.extractors import ExtractionError, get_extractor
from engines.document_engine.vector_store import upsert_chunks
from models.document import Document, DocumentChunk

# Embedding API calls are batched, not one call per chunk — fewer round
# trips, and stays well under provider per-request input limits even for a
# large manual (hundreds of chunks).
EMBED_BATCH_SIZE = 64


def process_document(db: Session, merchant_id: UUID, document: Document, file_bytes: bytes) -> None:
    """
    Runs inside a background task with its own DB session — same pattern and
    same reasoning as engines/import_engine/product_import.py: the request's
    session is already closed by the time a FastAPI BackgroundTask executes.
    """
    try:
        extractor = get_extractor(document.original_filename)
        extracted = extractor.extract(file_bytes)
        chunks = chunk_document(extracted)

        if not chunks:
            raise ExtractionError("No text content could be extracted from this document.")

        provider = get_embedding_provider()

        chunk_rows: list[DocumentChunk] = []
        for i, chunk in enumerate(chunks):
            chunk_rows.append(DocumentChunk(
                document_id=document.id,
                merchant_id=merchant_id,
                chunk_index=i,
                content=chunk.content,
                chunk_metadata={"page_number": chunk.page_number, "token_count": chunk.token_count},
            ))
        db.add_all(chunk_rows)
        db.flush()  # assign chunk_rows[i].id without committing yet

        points: list[tuple[UUID, list[float], dict]] = []
        for batch_start in range(0, len(chunks), EMBED_BATCH_SIZE):
            batch_chunks = chunks[batch_start:batch_start + EMBED_BATCH_SIZE]
            batch_rows = chunk_rows[batch_start:batch_start + EMBED_BATCH_SIZE]
            vectors = provider.embed([c.content for c in batch_chunks])
            for row, vector in zip(batch_rows, vectors):
                points.append((row.id, vector, {
                    "content_type": "document_chunk",
                    "merchant_id": str(merchant_id),
                    "document_id": str(document.id),
                    "document_title": document.title,
                    "chunk_index": row.chunk_index,
                    "page_number": row.chunk_metadata["page_number"],
                    "content": row.content,
                }))

        upsert_chunks(merchant_id, points)

        document.status = "ready"
        document.page_count = extracted.page_count
        document.chunk_count = len(chunks)
        document.error_message = None
        db.commit()

    except ExtractionError as exc:
        db.rollback()
        document = db.get(Document, document.id)
        if document:
            document.status = "failed"
            document.error_message = str(exc)
            db.commit()
    except Exception as exc:  # noqa: BLE001 — surfaced via document.error_message, not a crash
        db.rollback()
        document = db.get(Document, document.id)
        if document:
            document.status = "failed"
            document.error_message = f"Unexpected error while processing this document: {exc}"
            db.commit()
