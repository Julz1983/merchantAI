from dataclasses import dataclass, field
from typing import Protocol


@dataclass
class ExtractedPage:
    page_number: int  # 1-indexed
    text: str


@dataclass
class ExtractedDocument:
    pages: list[ExtractedPage] = field(default_factory=list)

    @property
    def full_text(self) -> str:
        return "\n\n".join(p.text for p in self.pages if p.text.strip())

    @property
    def page_count(self) -> int:
        return len(self.pages)


class Extractor(Protocol):
    def extract(self, file_bytes: bytes) -> ExtractedDocument: ...


class ExtractionError(Exception):
    """Raised when a file can't be read at all (corrupt, encrypted, wrong format, empty)."""
