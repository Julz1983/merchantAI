from engines.document_engine.extractors.base import ExtractedDocument, ExtractedPage, ExtractionError


class TXTExtractor:
    def extract(self, file_bytes: bytes) -> ExtractedDocument:
        try:
            text = file_bytes.decode("utf-8-sig")
        except UnicodeDecodeError:
            try:
                text = file_bytes.decode("latin-1")  # tolerate Windows-exported text files
            except UnicodeDecodeError as exc:
                raise ExtractionError("Couldn't read this file as text — check its encoding.") from exc

        if not text.strip():
            raise ExtractionError("This text file is empty.")

        return ExtractedDocument(pages=[ExtractedPage(page_number=1, text=text)])
