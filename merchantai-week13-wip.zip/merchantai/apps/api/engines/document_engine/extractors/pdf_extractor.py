import io

from pypdf import PdfReader
from pypdf.errors import PdfReadError

from engines.document_engine.extractors.base import ExtractedDocument, ExtractedPage, ExtractionError


class PDFExtractor:
    def extract(self, file_bytes: bytes) -> ExtractedDocument:
        try:
            reader = PdfReader(io.BytesIO(file_bytes))
        except PdfReadError as exc:
            raise ExtractionError("Couldn't read this PDF — it may be corrupted.") from exc

        if reader.is_encrypted:
            # Try an empty password first — some PDFs are "encrypted" with
            # owner-password-only restrictions but no user password.
            try:
                reader.decrypt("")
            except Exception as exc:
                raise ExtractionError("This PDF is password-protected and can't be read.") from exc

        pages = []
        for i, page in enumerate(reader.pages, start=1):
            try:
                text = page.extract_text() or ""
            except Exception:
                text = ""  # a single unparseable page shouldn't fail the whole document
            pages.append(ExtractedPage(page_number=i, text=text))

        if not any(p.text.strip() for p in pages):
            raise ExtractionError(
                "No extractable text found in this PDF. It may be a scanned "
                "image without OCR — scanned-document support isn't in this MVP."
            )

        return ExtractedDocument(pages=pages)
