import io

from docx import Document as DocxDocument
from docx.opc.exceptions import PackageNotFoundError

from engines.document_engine.extractors.base import ExtractedDocument, ExtractedPage, ExtractionError


class DOCXExtractor:
    def extract(self, file_bytes: bytes) -> ExtractedDocument:
        try:
            doc = DocxDocument(io.BytesIO(file_bytes))
        except PackageNotFoundError as exc:
            raise ExtractionError("Couldn't read this file as a Word document.") from exc

        # Word documents don't have a reliable page concept without a layout
        # engine — we treat the whole document as one logical "page" for
        # citation purposes (section headings in chunk_metadata do the finer
        # location work instead, see chunker.py).
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        text = "\n\n".join(paragraphs)

        if not text.strip():
            raise ExtractionError("This Word document appears to be empty.")

        return ExtractedDocument(pages=[ExtractedPage(page_number=1, text=text)])
