from engines.document_engine.extractors.base import ExtractedDocument, ExtractedPage, Extractor, ExtractionError
from engines.document_engine.extractors.docx_extractor import DOCXExtractor
from engines.document_engine.extractors.pdf_extractor import PDFExtractor
from engines.document_engine.extractors.txt_extractor import TXTExtractor

# Pluggable by extension, same pattern as the product import parsers registry
# (engines/import_engine/parsers/__init__.py) — covers the brief's "PDF, Word,
# TXT" document import formats.
_EXTRACTORS: dict[str, Extractor] = {
    ".pdf": PDFExtractor(),
    ".docx": DOCXExtractor(),
    ".txt": TXTExtractor(),
}


def get_extractor(filename: str) -> Extractor:
    lower = filename.lower()
    for ext, extractor in _EXTRACTORS.items():
        if lower.endswith(ext):
            return extractor
    raise ExtractionError(f"Unsupported file type. Supported formats: {', '.join(_EXTRACTORS.keys())}")


__all__ = ["get_extractor", "ExtractedDocument", "ExtractedPage", "ExtractionError"]
