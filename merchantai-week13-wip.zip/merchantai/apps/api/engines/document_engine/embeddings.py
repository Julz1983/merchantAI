import hashlib
import os
from typing import Protocol

# Matches OpenAI's text-embedding-3-large dimensionality (architecture §8) —
# the local provider below produces vectors of the same size so Qdrant
# collections created against it are structurally identical to production
# ones, just not semantically meaningful.
EMBEDDING_DIMENSIONS = 3072


class EmbeddingProvider(Protocol):
    def embed(self, texts: list[str]) -> list[list[float]]: ...


class OpenAIEmbeddingProvider:
    """Production provider — text-embedding-3-large, per architecture §8."""

    def __init__(self, api_key: str | None = None, model: str = "text-embedding-3-large"):
        # Imported lazily so environments without OPENAI_API_KEY (and without
        # ever calling this provider) don't need the openai package installed
        # at import time, and so unit tests that only exercise the local
        # provider don't need network access.
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))
        self._model = model

    def embed(self, texts: list[str]) -> list[list[float]]:
        response = self._client.embeddings.create(model=self._model, input=texts)
        return [item.embedding for item in response.data]


class LocalHashEmbeddingProvider:
    """
    Deterministic, dependency-free, offline embedding provider. NOT semantically
    meaningful — it does not understand text, it hashes it into a fixed-size
    vector. Two different sentences about decking will not score as similar
    just because they're both about decking.

    What it IS useful for: exercising the full pipeline (chunk -> embed ->
    store in Qdrant -> query -> get matching chunks back) in tests, CI, and
    local dev without an OpenAI API key or network access — proving the
    plumbing works end-to-end, which is a different and complementary thing
    to proving retrieval *quality*, which requires the real provider.

    Same embed() -> vector shape as OpenAIEmbeddingProvider, so swapping
    providers is a one-line change (see get_embedding_provider() below) and
    nothing downstream (chunker, vector_store, pipeline) needs to know which
    one is active.
    """

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._hash_embed(t) for t in texts]

    @staticmethod
    def _hash_embed(text: str) -> list[float]:
        # Repeatedly hash to fill EMBEDDING_DIMENSIONS floats in [-1, 1].
        # Deterministic: same text always produces the same vector, which is
        # what lets tests assert "searching for X's own chunk returns X".
        vector: list[float] = []
        seed = text.encode("utf-8")
        counter = 0
        while len(vector) < EMBEDDING_DIMENSIONS:
            digest = hashlib.sha256(seed + counter.to_bytes(4, "big")).digest()
            for byte in digest:
                vector.append((byte / 255.0) * 2 - 1)
            counter += 1
        return vector[:EMBEDDING_DIMENSIONS]


def get_embedding_provider() -> EmbeddingProvider:
    """
    Selects the provider based on environment, not a hardcoded choice — this
    is the abstraction point the brief asks for ("design abstraction layer so
    Claude/OpenAI can be swapped"). Falls back to the local provider when no
    API key is configured, rather than failing hard, so `docker compose up`
    with an empty .env still produces a working (if not semantically
    meaningful) demo instead of a crash on the first document upload.
    """
    if os.environ.get("OPENAI_API_KEY"):
        return OpenAIEmbeddingProvider()
    return LocalHashEmbeddingProvider()
