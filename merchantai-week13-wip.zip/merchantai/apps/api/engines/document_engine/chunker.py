from dataclasses import dataclass

import re
from dataclasses import dataclass

from engines.document_engine.extractors.base import ExtractedDocument

CHUNK_SIZE_TOKENS = 500
CHUNK_OVERLAP_TOKENS = 75  # ~15% of 500, per architecture §8

_WORD_RE = re.compile(r"\S+")


def _estimate_tokens(text: str) -> int:
    """
    Approximates token count without a real tokenizer. tiktoken (the exact
    tokenizer for OpenAI's embedding models) downloads its BPE vocab file
    from openaipublic.blob.core.windows.net on first use — an unnecessary
    hidden network dependency for something that only needs to land roughly
    at CHUNK_SIZE_TOKENS, not exactly. Chunk boundaries don't need
    token-perfect precision; they need "not too big, not too small" for
    retrieval granularity. Word count * 1.3 is the standard rule-of-thumb
    approximation for English text and holds up well enough in practice.

    If this ever needs to be exact (e.g. for strict provider token-limit
    enforcement rather than chunk sizing), swap this for a real tokenizer at
    that call site — don't add it here just to make chunk boundaries exact.
    """
    word_count = len(_WORD_RE.findall(text))
    return round(word_count * 1.3)


@dataclass
class Chunk:
    content: str
    page_number: int
    token_count: int


def _split_into_paragraphs(text: str) -> list[str]:
    return [p.strip() for p in text.split("\n\n") if p.strip()]


def chunk_document(doc: ExtractedDocument) -> list[Chunk]:
    """
    Greedily packs paragraphs into ~CHUNK_SIZE_TOKENS-token chunks, carrying
    the last CHUNK_OVERLAP_TOKENS worth of text into the next chunk so a
    concept split across a chunk boundary still has full context on both
    sides. A chunk's page_number is the page its first paragraph came from —
    good enough for "which page to open" in a citation, even if a chunk
    straddles a page break.

    A single paragraph longer than CHUNK_SIZE_TOKENS (rare, but possible with
    poorly-formatted source documents) becomes its own oversized chunk rather
    than being truncated — losing content silently would be worse than one
    chunk that's larger than the target.
    """
    chunks: list[Chunk] = []
    current_parts: list[str] = []
    current_tokens = 0
    current_page = 1

    def flush():
        nonlocal current_parts, current_tokens
        if not current_parts:
            return
        content = "\n\n".join(current_parts)
        chunks.append(Chunk(content=content, page_number=current_page, token_count=current_tokens))

    for page in doc.pages:
        for paragraph in _split_into_paragraphs(page.text):
            para_tokens = _estimate_tokens(paragraph)

            if current_parts and current_tokens + para_tokens > CHUNK_SIZE_TOKENS:
                flush()
                # Carry overlap: keep trailing paragraphs whose combined
                # token count is closest to CHUNK_OVERLAP_TOKENS.
                overlap_parts: list[str] = []
                overlap_tokens = 0
                for part in reversed(current_parts):
                    part_tokens = _estimate_tokens(part)
                    if overlap_tokens + part_tokens > CHUNK_OVERLAP_TOKENS:
                        break
                    overlap_parts.insert(0, part)
                    overlap_tokens += part_tokens
                current_parts = overlap_parts
                current_tokens = overlap_tokens
                current_page = page.page_number

            if not current_parts:
                current_page = page.page_number

            current_parts.append(paragraph)
            current_tokens += para_tokens

    flush()
    return chunks
