from uuid import UUID

from qdrant_client import QdrantClient
from qdrant_client.models import Distance, FieldCondition, Filter, MatchValue, PointStruct, VectorParams

from core.config import settings
from engines.document_engine.embeddings import EMBEDDING_DIMENSIONS

# An empty/unset QDRANT_URL (e.g. in a unit test) falls back to Qdrant's
# in-process "local mode" (":memory:"), which runs the same client interface
# without a server — good enough to prove the store/query pipeline works,
# though it doesn't persist between process restarts. Production always sets
# QDRANT_URL to a real Qdrant instance (see docker-compose.yml).
_client: QdrantClient | None = None


def get_client() -> QdrantClient:
    global _client
    if _client is None:
        _client = QdrantClient(url=settings.QDRANT_URL) if settings.QDRANT_URL else QdrantClient(":memory:")
    return _client


def collection_name(merchant_id: UUID) -> str:
    # One collection per merchant (architecture §14): cheap to create/delete/
    # export independently, and one tenant's catalogue size never affects
    # another's query latency the way a shared collection + filter would.
    return f"merchant_{merchant_id}"


def ensure_collection(merchant_id: UUID) -> None:
    client = get_client()
    name = collection_name(merchant_id)
    if not client.collection_exists(name):
        client.create_collection(name, vectors_config=VectorParams(size=EMBEDDING_DIMENSIONS, distance=Distance.COSINE))


def upsert_chunks(merchant_id: UUID, points: list[tuple[UUID, list[float], dict]]) -> None:
    """points: [(chunk_id, vector, payload), ...]. payload should carry
    enough to render a citation without a DB round-trip (document_id,
    chunk_index, page_number) plus whatever the AI Engine's retrieval
    filtering needs later (e.g. product_id for hybrid retrieval, §8)."""
    ensure_collection(merchant_id)
    client = get_client()
    client.upsert(
        collection_name(merchant_id),
        points=[PointStruct(id=str(chunk_id), vector=vector, payload=payload) for chunk_id, vector, payload in points],
    )


def delete_document_chunks(merchant_id: UUID, document_id: UUID) -> None:
    client = get_client()
    name = collection_name(merchant_id)
    if not client.collection_exists(name):
        return
    client.delete(
        name,
        points_selector=Filter(must=[FieldCondition(key="document_id", match=MatchValue(value=str(document_id)))]),
    )


def search(merchant_id: UUID, query_vector: list[float], limit: int = 5, content_type: str | None = None) -> list[dict]:
    """
    Returns [{ id, score, payload }, ...]. content_type filters to only
    points whose payload["content_type"] matches (e.g. "document_chunk") —
    needed because products and document chunks share one collection per
    merchant (architecture §14), so an unfiltered search mixes both. A
    document-only search that doesn't filter will return product vectors
    mixed in with empty document_id/title/content fields, since those
    fields don't exist on a product's payload — this was a real bug caught
    by testing with a realistic catalogue where products significantly
    outnumbered document chunks.
    """
    client = get_client()
    name = collection_name(merchant_id)
    if not client.collection_exists(name):
        return []
    query_filter = Filter(must=[FieldCondition(key="content_type", match=MatchValue(value=content_type))]) if content_type else None
    results = client.query_points(name, query=query_vector, limit=limit, query_filter=query_filter).points
    return [{"id": r.id, "score": r.score, "payload": r.payload} for r in results]
