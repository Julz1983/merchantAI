from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from core.security import hash_password, verify_password
from models.user import VALID_ROLES, User

ROLE_RANK = {"viewer": 0, "editor": 1, "admin": 2, "owner": 3}
MIN_PASSWORD_LENGTH = 8


class UserError(Exception):
    """code is one of: forbidden | not_found | conflict | invalid — the
    router maps these to 403 / 404 / 409 / 400."""

    def __init__(self, message: str, code: str):
        super().__init__(message)
        self.code = code


def can_manage_role(actor_role: str, target_role: str) -> bool:
    """Owners can manage any role. Admins can only manage roles strictly
    below admin (editor, viewer) — an admin must not be able to mint
    another admin/owner or touch an existing one, or "admin" would be
    indistinguishable from "owner" in practice. Everyone else manages no one."""
    if actor_role == "owner":
        return True
    if actor_role == "admin":
        return ROLE_RANK.get(target_role, 99) < ROLE_RANK["admin"]
    return False


def _validate_password(password: str) -> None:
    if len(password) < MIN_PASSWORD_LENGTH:
        raise UserError(f"Password must be at least {MIN_PASSWORD_LENGTH} characters", "invalid")


def _get_user(db: Session, merchant_id: UUID, user_id: UUID) -> User:
    user = db.get(User, user_id)
    # Same "not found" whether the id doesn't exist or belongs to another
    # merchant — never confirm that another tenant's user id exists.
    if user is None or user.merchant_id != merchant_id:
        raise UserError("User not found", "not_found")
    return user


def _owner_count(db: Session, merchant_id: UUID) -> int:
    return db.scalar(select(func.count()).select_from(User).where(User.merchant_id == merchant_id, User.role == "owner")) or 0


def list_users(db: Session, merchant_id: UUID) -> list[User]:
    return list(db.scalars(select(User).where(User.merchant_id == merchant_id).order_by(User.created_at)).all())


def create_user(db: Session, merchant_id: UUID, actor_role: str, email: str, password: str, role: str) -> User:
    if role not in VALID_ROLES:
        raise UserError(f"Role must be one of: {', '.join(VALID_ROLES)}", "invalid")
    if not can_manage_role(actor_role, role):
        raise UserError("You don't have permission to create a user with that role", "forbidden")
    _validate_password(password)

    # Lowercased on write; login compares case-insensitively (routers/auth.py)
    # so "Bob@x.com" and "bob@x.com" can never be two different accounts.
    user = User(merchant_id=merchant_id, email=email.strip().lower(), password_hash=hash_password(password), role=role)
    db.add(user)
    try:
        db.flush()
    except IntegrityError as exc:
        db.rollback()
        # Email uniqueness is global (one login identity per address), so
        # this can fire because ANOTHER merchant has the address — the
        # message is deliberately the same either way.
        raise UserError("That email address is already in use", "conflict") from exc
    return user


def update_user(db: Session, merchant_id: UUID, actor_id: UUID, actor_role: str, user_id: UUID, role: str | None = None, password: str | None = None) -> User:
    user = _get_user(db, merchant_id, user_id)
    is_self = user.id == actor_id

    if not is_self and not can_manage_role(actor_role, user.role):
        raise UserError("You don't have permission to modify this user", "forbidden")

    if role is not None and role != user.role:
        if role not in VALID_ROLES:
            raise UserError(f"Role must be one of: {', '.join(VALID_ROLES)}", "invalid")
        if is_self:
            raise UserError("You can't change your own role", "forbidden")
        if not can_manage_role(actor_role, role):
            raise UserError("You don't have permission to assign that role", "forbidden")
        if user.role == "owner" and _owner_count(db, merchant_id) <= 1:
            raise UserError("Can't demote the last owner — promote someone else to owner first", "conflict")
        user.role = role

    if password is not None:
        _validate_password(password)
        user.password_hash = hash_password(password)

    db.flush()
    return user


def delete_user(db: Session, merchant_id: UUID, actor_id: UUID, actor_role: str, user_id: UUID) -> None:
    user = _get_user(db, merchant_id, user_id)
    if user.id == actor_id:
        raise UserError("You can't remove your own account", "forbidden")
    if not can_manage_role(actor_role, user.role):
        raise UserError("You don't have permission to remove this user", "forbidden")
    if user.role == "owner" and _owner_count(db, merchant_id) <= 1:
        raise UserError("Can't remove the last owner", "conflict")
    db.delete(user)
    db.flush()


def change_own_password(db: Session, merchant_id: UUID, user_id: UUID, current_password: str, new_password: str) -> None:
    user = _get_user(db, merchant_id, user_id)
    if not verify_password(current_password, user.password_hash):
        raise UserError("Current password is incorrect", "invalid")
    _validate_password(new_password)
    user.password_hash = hash_password(new_password)
    db.flush()
