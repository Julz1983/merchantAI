from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from engines.ai_engine.rag_pipeline import RAGResponse, answer_question
from engines.analytics_engine.event_ingest import record_event
from models.chat import Chat, ChatMessage
from models.merchant import Merchant


def handle_chat_turn(db: Session, merchant: Merchant, merchant_id: UUID, session_id: str, message: str) -> RAGResponse:
    """One request/response turn: find-or-create the chat session, store the
    user message, run RAG, store the assistant message with its (validated)
    citations, and return the response. Identical behavior regardless of
    whether the caller came in via JWT (dashboard) or an API key (widget) —
    see routers/chat.py and routers/widget.py."""
    chat = db.scalar(select(Chat).where(Chat.merchant_id == merchant_id, Chat.session_id == session_id))
    if chat is None:
        chat = Chat(merchant_id=merchant_id, session_id=session_id)
        db.add(chat)
        db.flush()

    db.add(ChatMessage(chat_id=chat.id, merchant_id=merchant_id, role="user", content=message, citations={}))
    record_event(db, merchant_id, "question", {"message": message}, chat_id=chat.id)

    rag_response = answer_question(db, merchant, message)

    citations = {"product_ids": rag_response.cited_product_ids, "document_chunk_ids": rag_response.cited_document_chunk_ids}
    db.add(ChatMessage(chat_id=chat.id, merchant_id=merchant_id, role="assistant", content=rag_response.reply, citations=citations))

    _record_answer_events(db, merchant_id, chat.id, message, rag_response)

    db.commit()

    return rag_response


def _record_answer_events(db: Session, merchant_id: UUID, chat_id: UUID, question: str, rag_response: RAGResponse) -> None:
    """
    Maps one answered question onto the brief's tracked event vocabulary
    (§"Analytics"). This is deliberately derived from what the RAG pipeline
    already computed — no separate tracking logic that could drift from what
    the customer actually saw.
    """
    if rag_response.suggested_products:
        record_event(db, merchant_id, "product_found", {"count": len(rag_response.suggested_products)}, chat_id=chat_id)
        for product in rag_response.suggested_products:
            record_event(db, merchant_id, "recommendation", {
                "product_id": product.id, "sku": product.sku, "name": product.name, "reason": product.reason,
            }, chat_id=chat_id)
            if product.reason != "vector_match":
                record_event(db, merchant_id, "kg_path_used", {
                    "product_id": product.id, "relationship_type": product.reason,
                }, chat_id=chat_id)
    else:
        # No products in the final cited/suggested set — a genuine
        # merchandising signal (architecture Journey C: "demand signal for
        # products they don't stock"), not just a failed query.
        record_event(db, merchant_id, "product_missing", {"question": question}, chat_id=chat_id)

    if rag_response.cited_document_chunk_ids:
        record_event(db, merchant_id, "document_used", {"chunk_ids": rag_response.cited_document_chunk_ids}, chat_id=chat_id)
