from models.merchant import Merchant

# Fixed, audited template — every merchant gets the same grounding/safety
# rules. Persona settings only vary tone and emphasis, never whether the
# grounding rules apply (architecture §0.4): merchants get structured
# settings composed into this template, not a raw system-prompt override.
_BASE_INSTRUCTIONS = (
    "You are a knowledgeable assistant for a builders' merchant, helping "
    "customers find products, understand what they need for a project, and "
    "get accessories/requirements right.\n\n"
    "CRITICAL RULES:\n"
    "- Only state facts that are present in the CONTEXT section below. "
    "Never invent a product, price, specification, or compatibility claim.\n"
    "- If the context doesn't have what's needed to answer, say so plainly "
    "and offer to connect the customer with the merchant — do not guess.\n"
    "- When you mention a product or document from the context, you MUST "
    "include its id in cited_product_ids or cited_document_chunk_ids.\n"
    "- Never cite an id that wasn't given to you in the context."
)

_TONE_PHRASES = {
    "formal": "Keep a professional, precise tone.",
    "casual": "Keep a friendly, conversational tone, like a helpful staff member on the shop floor.",
}

# Every level is explicitly bounded by "from the context" — a more
# aggressive upsell setting changes how much of the retrieved context the
# assistant volunteers, never whether it may go beyond it.
_UPSELL_PHRASES = {
    "low": "Only mention related products or accessories when the customer asks about them or they are strictly required for the job.",
    "medium": "Mention required accessories and clearly relevant add-ons that fit the customer's project, without pushing.",
    "high": "Proactively suggest the relevant accessories and complementary products from the context that would help complete the customer's project.",
}


def _flatten(value: object) -> str:
    """Collapse any whitespace/newlines and cap the length — persona values
    are validated on write (schemas/settings.py), but this is the last line
    of defence for anything already stored or written by another path."""
    return " ".join(str(value).split())[:100]


def build_system_prompt(merchant: Merchant) -> str:
    persona = merchant.ai_persona or {}
    tone = persona.get("tone", "formal")
    upsell = persona.get("upsell_aggressiveness", "medium")
    emphasized = [c for c in (_flatten(c) for c in (persona.get("emphasized_categories") or [])[:10]) if c]

    lines = [
        _BASE_INSTRUCTIONS,
        _TONE_PHRASES.get(tone, _TONE_PHRASES["formal"]),
        _UPSELL_PHRASES.get(upsell, _UPSELL_PHRASES["medium"]),
    ]
    if emphasized:
        lines.append(f"This merchant particularly wants to highlight these categories when relevant: {', '.join(emphasized)}.")

    return "\n\n".join(lines)
