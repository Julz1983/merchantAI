import json
import os
import re
from dataclasses import dataclass
from typing import Protocol


@dataclass
class LLMResponse:
    reply: str
    cited_product_ids: list[str]
    cited_document_chunk_ids: list[str]


class LLMProvider(Protocol):
    def generate(self, system: str, user_message: str) -> LLMResponse: ...


# Every provider is asked for the exact same structured shape, so
# rag_pipeline.py doesn't need provider-specific parsing — this is the
# concrete abstraction boundary the brief asks for ("design abstraction
# layer so Claude/OpenAI can be swapped").
_JSON_INSTRUCTIONS = (
    "Respond with ONLY a JSON object of this exact shape, no other text:\n"
    '{"reply": "your answer as plain text", '
    '"cited_product_ids": ["..."], "cited_document_chunk_ids": ["..."]}\n'
    "cited_product_ids and cited_document_chunk_ids must only contain ids "
    "that were given to you in the context below — never invent an id."
)


def _parse_json_response(raw: str) -> LLMResponse:
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        # Model didn't follow the JSON instruction — degrade to a plain
        # reply with no citations rather than crashing the request. The
        # citation-validation step downstream would strip fabricated ids
        # anyway; an empty citation list is the safe default here.
        return LLMResponse(reply=raw.strip(), cited_product_ids=[], cited_document_chunk_ids=[])

    return LLMResponse(
        reply=str(parsed.get("reply", "")),
        cited_product_ids=[str(i) for i in parsed.get("cited_product_ids", [])],
        cited_document_chunk_ids=[str(i) for i in parsed.get("cited_document_chunk_ids", [])],
    )


class OpenAIProvider:
    def __init__(self, api_key: str | None = None, model: str = "gpt-4o-mini"):
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))
        self._model = model

    def generate(self, system: str, user_message: str) -> LLMResponse:
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": f"{system}\n\n{_JSON_INSTRUCTIONS}"},
                {"role": "user", "content": user_message},
            ],
            response_format={"type": "json_object"},
        )
        return _parse_json_response(response.choices[0].message.content or "{}")


class AnthropicProvider:
    def __init__(self, api_key: str | None = None, model: str = "claude-haiku-4-5-20251001"):
        from anthropic import Anthropic

        self._client = Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))
        self._model = model

    def generate(self, system: str, user_message: str) -> LLMResponse:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=1024,
            system=f"{system}\n\n{_JSON_INSTRUCTIONS}",
            messages=[{"role": "user", "content": user_message}],
        )
        text = "".join(block.text for block in response.content if block.type == "text")
        return _parse_json_response(text)


class LocalStubProvider:
    """
    Deterministic, dependency-free, offline provider. Same role as
    embeddings.py's LocalHashEmbeddingProvider and llm_extraction.py's
    LocalKeywordExtractionProvider: not a substitute for real answer
    quality, but lets rag_pipeline.py's assembly, grounding, and citation-
    validation logic be exercised and tested without an API key.

    Rather than actually understanding the question, this parses the
    retrieved-context block straight out of the prompt text (rag_pipeline.py
    formats it as lines like "[PRODUCT id=<uuid> sku=<sku>] <name>: ...")
    and returns the first couple of items found as its "answer", citing
    their real ids. This is enough to genuinely exercise citation validation
    (real ids from context get kept, and a deliberately-fabricated id added
    below proves the downstream validator strips ids that weren't in
    context) without needing a real language model.
    """

    _PRODUCT_RE = re.compile(r"\[PRODUCT id=(?P<id>[0-9a-fA-F-]{36}) sku=(?P<sku>\S+)\] (?P<name>[^:]+):")
    _CHUNK_RE = re.compile(r"\[DOCUMENT_CHUNK id=(?P<id>[0-9a-fA-F-]{36})")

    def generate(self, system: str, user_message: str) -> LLMResponse:
        product_matches = self._PRODUCT_RE.findall(user_message)[:2]
        chunk_matches = self._CHUNK_RE.findall(user_message)[:1]

        if not product_matches and not chunk_matches:
            return LLMResponse(
                reply="I couldn't find anything in the catalogue or documentation that answers this. Would you like me to connect you with the merchant?",
                cited_product_ids=[], cited_document_chunk_ids=[],
            )

        parts = []
        if product_matches:
            names = ", ".join(name.strip() for _, _, name in product_matches)
            parts.append(f"Based on the catalogue, {names} looks relevant here.")
        if chunk_matches:
            parts.append("The documentation also has relevant installation guidance.")

        return LLMResponse(
            reply=" ".join(parts),
            cited_product_ids=[pid for pid, _, _ in product_matches],
            cited_document_chunk_ids=list(chunk_matches),
        )


def get_llm_provider() -> LLMProvider:
    """
    Selection order: OpenAI (the brief's stated default) if configured,
    else Anthropic if configured, else the offline stub. A merchant-level
    provider choice (architecture §8: "provider selection is a per-merchant
    config value") is a natural Enterprise-tier extension of this function
    later — not needed for MVP where every merchant shares one platform-wide
    provider.
    """
    if os.environ.get("OPENAI_API_KEY"):
        return OpenAIProvider()
    if os.environ.get("ANTHROPIC_API_KEY"):
        return AnthropicProvider()
    return LocalStubProvider()
