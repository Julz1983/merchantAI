from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from engines.document_engine.embeddings import get_embedding_provider
from engines.document_engine.vector_store import upsert_chunks
from models.catalogue import Brand, Category, Product

EMBED_BATCH_SIZE = 64


def _compose_embedding_text(product: Product, category_name: str | None, brand_name: str | None) -> str:
    """
    Per architecture §8: "products embed a composed string of name +
    description + category + attributes (not raw JSON) so semantic search
    matches how customers actually phrase questions" — a customer asking
    about "coastal decking" should match on category/attribute text even if
    those exact words aren't in the product name.
    """
    parts = [product.name]
    if product.description:
        parts.append(product.description)
    if category_name:
        parts.append(category_name)
    if brand_name:
        parts.append(brand_name)
    if product.attributes:
        parts.append(" ".join(f"{k} {v}" for k, v in product.attributes.items()))
    if product.specifications:
        parts.append(" ".join(f"{k} {v}" for k, v in product.specifications.items()))
    return " — ".join(parts)


def index_products(db: Session, merchant_id: UUID) -> dict:
    """
    Embeds every product for a merchant and upserts into the vector store
    with content_type='product' in the payload, so hybrid_retrieval.py can
    tell products and document chunks apart in the same collection. Called
    after every product import (see routers/products.py), same as the KG
    build — re-running is safe, Qdrant upsert is idempotent by point id
    (the product's own id).
    """
    rows = db.execute(
        select(Product, Category.name, Brand.name)
        .outerjoin(Category, Product.category_id == Category.id)
        .outerjoin(Brand, Product.brand_id == Brand.id)
        .where(Product.merchant_id == merchant_id)
    ).all()

    if not rows:
        return {"products_indexed": 0}

    provider = get_embedding_provider()
    indexed = 0

    for batch_start in range(0, len(rows), EMBED_BATCH_SIZE):
        batch = rows[batch_start:batch_start + EMBED_BATCH_SIZE]
        texts = [_compose_embedding_text(p, cat, brand) for p, cat, brand in batch]
        vectors = provider.embed(texts)

        points = [
            (p.id, vector, {
                "content_type": "product",
                "merchant_id": str(merchant_id),
                "product_id": str(p.id),
                "sku": p.sku,
                "name": p.name,
                "description": p.description or "",
                "category_name": cat,
                "price": float(p.price) if p.price is not None else None,
                "stock_status": p.stock_status,
            })
            for (p, cat, brand), vector in zip(batch, vectors)
        ]
        upsert_chunks(merchant_id, points)
        indexed += len(points)

    return {"products_indexed": indexed}
