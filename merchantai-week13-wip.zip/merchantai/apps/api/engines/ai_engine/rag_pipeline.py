from dataclasses import dataclass
from uuid import UUID

from sqlalchemy.orm import Session

from engines.ai_engine.llm_gateway import get_llm_provider
from engines.ai_engine.prompt_templates.system_prompt import build_system_prompt
from engines.knowledge_engine.hybrid_retrieval import RetrievalContext, hybrid_retrieve
from models.merchant import Merchant


@dataclass
class SuggestedProduct:
    id: str
    sku: str
    name: str
    price: float | None
    stock_status: str
    reason: str  # "vector_match" or a relationship_type


@dataclass
class RAGResponse:
    reply: str
    cited_product_ids: list[str]
    cited_document_chunk_ids: list[str]
    suggested_products: list[SuggestedProduct]


def _format_context(context: RetrievalContext) -> str:
    """
    Formats retrieved context into the prompt. The bracketed [PRODUCT id=...]
    / [DOCUMENT_CHUNK id=...] markers aren't just for the real LLM providers
    to reference — LocalStubProvider (llm_gateway.py) parses these exact
    patterns back out to build its offline test reply, so this format is
    part of the tested contract, not incidental formatting.
    """
    if not context.products and not context.chunks:
        return "CONTEXT: (nothing relevant found in the catalogue or documentation)"

    lines = ["CONTEXT:"]
    for p in context.products:
        why = f" — found via {p.relevance} relationship with {p.related_to}" if p.related_to else ""
        price_str = f"£{p.price:.2f}" if p.price is not None else "price not set"
        lines.append(f"[PRODUCT id={p.id} sku={p.sku}] {p.name}: {p.description} ({price_str}, {p.stock_status}){why}")

    for c in context.chunks:
        lines.append(f"[DOCUMENT_CHUNK id={c.id}] From \"{c.document_title}\" (page {c.page_number}): {c.content}")

    return "\n".join(lines)


def answer_question(db: Session, merchant: Merchant, question: str) -> RAGResponse:
    context = hybrid_retrieve(db, merchant.id, question)

    system_prompt = build_system_prompt(merchant)
    user_message = f"{_format_context(context)}\n\nCUSTOMER QUESTION: {question}"

    provider = get_llm_provider()
    llm_response = provider.generate(system_prompt, user_message)

    # Grounding enforcement is structural, not just prompted (architecture
    # §8): strip any cited id that wasn't actually in the retrieved context,
    # regardless of what the model claims. This is what makes "never
    # hallucinate" an enforced property of the system rather than a hope.
    valid_product_ids = {p.id for p in context.products}
    valid_chunk_ids = {c.id for c in context.chunks}

    validated_product_citations = [pid for pid in llm_response.cited_product_ids if pid in valid_product_ids]
    validated_chunk_citations = [cid for cid in llm_response.cited_document_chunk_ids if cid in valid_chunk_ids]

    products_by_id = {p.id: p for p in context.products}
    suggested = [
        SuggestedProduct(id=p.id, sku=p.sku, name=p.name, price=p.price, stock_status=p.stock_status, reason=p.relevance)
        for pid in validated_product_citations
        if (p := products_by_id.get(pid)) is not None
    ]

    return RAGResponse(
        reply=llm_response.reply,
        cited_product_ids=validated_product_citations,
        cited_document_chunk_ids=validated_chunk_citations,
        suggested_products=suggested,
    )
