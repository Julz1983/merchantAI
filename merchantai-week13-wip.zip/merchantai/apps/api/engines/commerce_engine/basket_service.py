from dataclasses import dataclass
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from models.basket import Basket, BasketItem
from models.catalogue import Product


class BasketError(Exception):
    """Raised for basket operations that fail a business rule (e.g. adding
    a product that doesn't exist for this merchant) — callers turn this into
    an HTTP 404/400, never a 500."""


@dataclass
class BasketItemView:
    id: str
    product_id: str
    sku: str
    name: str
    price: float | None
    stock_status: str
    quantity: int
    line_total: float | None
    source: str


@dataclass
class BasketView:
    id: str
    items: list[BasketItemView]
    item_count: int  # sum of quantities, not row count — 3x one product is 3 items
    subtotal: float | None  # None if any item's product has no price set, rather than silently undercounting


def get_or_create_basket(db: Session, merchant_id: UUID, session_id: str) -> Basket:
    basket = db.scalar(select(Basket).where(Basket.merchant_id == merchant_id, Basket.session_id == session_id))
    if basket:
        return basket
    basket = Basket(merchant_id=merchant_id, session_id=session_id)
    db.add(basket)
    db.flush()
    return basket


def add_item(db: Session, merchant_id: UUID, session_id: str, product_id: UUID, quantity: int = 1, source: str = "assistant") -> Basket:
    """Adding a product already in the basket increases its quantity rather
    than creating a duplicate row — matches how every real shopping cart
    behaves, and is what the unique (basket_id, product_id) constraint
    (migration 0010) exists to make safe under concurrent adds."""
    if quantity < 1:
        raise BasketError("Quantity must be at least 1")

    product = db.get(Product, product_id)
    if product is None or product.merchant_id != merchant_id:
        raise BasketError("Product not found")

    basket = get_or_create_basket(db, merchant_id, session_id)

    existing = db.scalar(select(BasketItem).where(BasketItem.basket_id == basket.id, BasketItem.product_id == product_id))
    if existing:
        existing.quantity += quantity
    else:
        db.add(BasketItem(basket_id=basket.id, merchant_id=merchant_id, product_id=product_id, quantity=quantity, source=source))

    db.flush()
    return basket


def remove_item(db: Session, merchant_id: UUID, session_id: str, item_id: UUID) -> None:
    item = db.get(BasketItem, item_id)
    if item is None or item.merchant_id != merchant_id:
        raise BasketError("Basket item not found")

    basket = db.get(Basket, item.basket_id)
    if basket is None or basket.session_id != session_id:
        # A basket item id from a different session — don't leak whether it
        # exists at all; same 404 either way.
        raise BasketError("Basket item not found")

    db.delete(item)
    db.flush()


def update_item_quantity(db: Session, merchant_id: UUID, session_id: str, item_id: UUID, quantity: int) -> None:
    if quantity < 1:
        raise BasketError("Quantity must be at least 1 — use remove_item to take an item out entirely")

    item = db.get(BasketItem, item_id)
    if item is None or item.merchant_id != merchant_id:
        raise BasketError("Basket item not found")

    basket = db.get(Basket, item.basket_id)
    if basket is None or basket.session_id != session_id:
        raise BasketError("Basket item not found")

    item.quantity = quantity
    db.flush()


def get_basket_view(db: Session, merchant_id: UUID, session_id: str) -> BasketView:
    basket = db.scalar(select(Basket).where(Basket.merchant_id == merchant_id, Basket.session_id == session_id))
    if basket is None:
        return BasketView(id="", items=[], item_count=0, subtotal=0.0)

    rows = db.execute(
        select(BasketItem, Product).join(Product, BasketItem.product_id == Product.id).where(BasketItem.basket_id == basket.id)
    ).all()

    items = []
    subtotal = 0.0
    any_missing_price = False
    for item, product in rows:
        price = float(product.price) if product.price is not None else None
        line_total = round(price * item.quantity, 2) if price is not None else None
        if price is None:
            any_missing_price = True
        else:
            subtotal += line_total
        items.append(BasketItemView(
            id=str(item.id), product_id=str(product.id), sku=product.sku, name=product.name,
            price=price, stock_status=product.stock_status, quantity=item.quantity, line_total=line_total, source=item.source,
        ))

    return BasketView(
        id=str(basket.id), items=items, item_count=sum(i.quantity for i in items),
        subtotal=None if any_missing_price else round(subtotal, 2),
    )
