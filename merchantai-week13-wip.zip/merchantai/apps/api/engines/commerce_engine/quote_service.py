import secrets
import string
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from engines.commerce_engine.basket_service import get_basket_view
from models.quote import Quote, QuoteItem

DEFAULT_VALIDITY_DAYS = 14
REFERENCE_ALPHABET = string.ascii_uppercase.replace("O", "").replace("I", "") + "23456789"  # no ambiguous O/0/I/1
REFERENCE_LENGTH = 6
MAX_REFERENCE_ATTEMPTS = 10


class QuoteError(Exception):
    """Raised for quote operations that fail a business rule — callers turn
    this into an HTTP 400/404, never a 500."""


@dataclass
class QuoteItemView:
    sku: str
    name: str
    unit_price: float
    quantity: int
    line_total: float


@dataclass
class QuoteView:
    id: str
    reference_number: str
    status: str
    subtotal: float
    items: list[QuoteItemView]
    created_at: datetime
    expires_at: datetime
    is_expired: bool


def _generate_reference_number(db: Session, merchant_id: UUID) -> str:
    """Short, spoken-aloud-friendly code (e.g. 'Q-4K7XJ9') a customer can
    quote back to staff over the phone. Retries on collision; the unique
    constraint in migration 0011 is the backstop."""
    for _ in range(MAX_REFERENCE_ATTEMPTS):
        candidate = "Q-" + "".join(secrets.choice(REFERENCE_ALPHABET) for _ in range(REFERENCE_LENGTH))
        exists = db.scalar(select(Quote).where(Quote.merchant_id == merchant_id, Quote.reference_number == candidate))
        if not exists:
            return candidate
    raise QuoteError("Could not generate a unique quote reference — please try again")


def create_quote_from_basket(db: Session, merchant_id: UUID, session_id: str, validity_days: int = DEFAULT_VALIDITY_DAYS) -> QuoteView:
    basket = get_basket_view(db, merchant_id, session_id)
    if not basket.items:
        raise QuoteError("Can't create a quote from an empty basket")
    if basket.subtotal is None:
        raise QuoteError("Can't create a quote — one or more items don't have a price set")

    reference_number = _generate_reference_number(db, merchant_id)
    now = datetime.now(timezone.utc)

    quote = Quote(
        merchant_id=merchant_id, session_id=session_id, reference_number=reference_number,
        status="draft", subtotal=basket.subtotal, expires_at=now + timedelta(days=validity_days),
    )
    db.add(quote)
    db.flush()

    item_views: list[QuoteItemView] = []
    for basket_item in basket.items:
        db.add(QuoteItem(
            quote_id=quote.id, merchant_id=merchant_id, product_id=UUID(basket_item.product_id),
            sku=basket_item.sku, name=basket_item.name, unit_price=basket_item.price,
            quantity=basket_item.quantity, line_total=basket_item.line_total,
        ))
        item_views.append(QuoteItemView(
            sku=basket_item.sku, name=basket_item.name, unit_price=basket_item.price,
            quantity=basket_item.quantity, line_total=basket_item.line_total,
        ))

    db.flush()
    db.refresh(quote)

    return QuoteView(
        id=str(quote.id), reference_number=quote.reference_number, status=quote.status,
        subtotal=float(quote.subtotal), items=item_views, created_at=quote.created_at,
        expires_at=quote.expires_at, is_expired=False,
    )


def get_quote_by_reference(db: Session, merchant_id: UUID, reference_number: str) -> QuoteView:
    quote = db.scalar(select(Quote).where(Quote.merchant_id == merchant_id, Quote.reference_number == reference_number))
    if quote is None:
        raise QuoteError("Quote not found")

    items = db.scalars(select(QuoteItem).where(QuoteItem.quote_id == quote.id)).all()
    is_expired = quote.expires_at < datetime.now(timezone.utc)

    return QuoteView(
        id=str(quote.id), reference_number=quote.reference_number, status=quote.status,
        subtotal=float(quote.subtotal),
        items=[QuoteItemView(sku=i.sku, name=i.name, unit_price=float(i.unit_price), quantity=i.quantity, line_total=float(i.line_total)) for i in items],
        created_at=quote.created_at, expires_at=quote.expires_at, is_expired=is_expired,
    )
