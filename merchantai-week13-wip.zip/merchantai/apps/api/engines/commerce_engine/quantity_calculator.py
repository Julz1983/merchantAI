import math
import re
from dataclasses import dataclass

from models.catalogue import Product

DEFAULT_WASTE_FACTOR = 0.10  # 10% extra — standard trade allowance for cuts/offcuts/breakage


class QuantityCalculatorError(Exception):
    """Raised when a product's specifications don't contain enough
    information to calculate coverage — callers turn this into an HTTP 400,
    with a message the widget can show directly ('we don't have enough
    information...') rather than a generic failure."""


@dataclass
class QuantityCalculation:
    product_id: str
    sku: str
    name: str
    area_m2: float
    waste_factor: float
    coverage_per_unit_m2: float
    units_needed: int
    basis: str  # human-readable explanation of how coverage was determined


# A number immediately followed by "m2" (no other unit word in between) is a
# direct area-per-unit value: "Approx 60m2" -> 60 m2 per unit, "5.76m2/pack"
# -> 5.76 m2 per unit (the "/pack" just names the unit, it doesn't change
# the math). Checked first, since it's unambiguous whenever it matches.
_DIRECT_AREA_RE = re.compile(r"(\d+(?:\.\d+)?)\s*m2\b", re.IGNORECASE)

# A number followed by some other word(s) then "/m2" is an inverse value —
# units *per* square metre, not area per unit: "Approx 10 tiles/m2" means
# each unit covers 1/10 m2, not that one unit is 10m2. Only checked if the
# direct pattern above didn't match, since "5.76m2/pack" would otherwise
# also match this looser pattern (the m2 there is on the wrong side of the
# slash for this to apply).
_INVERSE_AREA_RE = re.compile(r"(\d+(?:\.\d+)?)[^\d]*?/\s*m2\b", re.IGNORECASE)

# A plain linear measurement: "3.6m", "150mm", "25cm". Word-boundary at the
# end so this doesn't accidentally match inside "m2" itself.
_LENGTH_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(mm|cm|m)\b", re.IGNORECASE)


def _to_meters(value: float, unit: str) -> float:
    unit = unit.lower()
    if unit == "m":
        return value
    if unit == "cm":
        return value / 100
    if unit == "mm":
        return value / 1000
    raise ValueError(f"Unrecognized length unit: {unit}")


def _find_spec(specifications: dict, *keywords: str) -> str | None:
    """Case-insensitive substring match on spec keys — merchant exports
    spell these inconsistently ('Coverage' vs 'coverage area' vs 'Covers'),
    so this can't be an exact-key lookup."""
    for key, value in specifications.items():
        key_lower = key.lower()
        if any(kw in key_lower for kw in keywords):
            return str(value)
    return None


def get_coverage_per_unit_m2(product: Product) -> tuple[float, str] | None:
    """
    Returns (coverage_m2_per_unit, basis_description) or None if the
    product's specifications don't contain enough information. Tries two
    strategies, in order:

    1. An explicit "Coverage" spec (paint, insulation, roof tiles) — handles
       both direct ("60m2 per unit") and inverse ("10 tiles per m2") phrasing.
    2. Length × Width (decking boards, sheet materials) — the area one unit
       physically covers, derived rather than stated.
    """
    specs = product.specifications or {}

    coverage_text = _find_spec(specs, "coverage")
    if coverage_text:
        direct_match = _DIRECT_AREA_RE.search(coverage_text)
        if direct_match:
            value = float(direct_match.group(1))
            return value, f"{value}m² coverage per unit (from product specification)"

        inverse_match = _INVERSE_AREA_RE.search(coverage_text)
        if inverse_match:
            units_per_m2 = float(inverse_match.group(1))
            if units_per_m2 > 0:
                return 1 / units_per_m2, f"{units_per_m2} units per m² (from product specification)"

    length_text = _find_spec(specs, "length")
    width_text = _find_spec(specs, "width")
    if length_text and width_text:
        length_match = _LENGTH_RE.search(length_text)
        width_match = _LENGTH_RE.search(width_text)
        if length_match and width_match:
            length_m = _to_meters(float(length_match.group(1)), length_match.group(2))
            width_m = _to_meters(float(width_match.group(1)), width_match.group(2))
            area = length_m * width_m
            if area > 0:
                return area, f"{length_m:g}m × {width_m:g}m per unit (from product dimensions)"

    return None


def calculate_units_for_area(product: Product, area_m2: float, waste_factor: float = DEFAULT_WASTE_FACTOR) -> QuantityCalculation:
    if area_m2 <= 0:
        raise QuantityCalculatorError("Area must be greater than zero")
    if waste_factor < 0:
        raise QuantityCalculatorError("Waste factor can't be negative")

    coverage_result = get_coverage_per_unit_m2(product)
    if coverage_result is None:
        raise QuantityCalculatorError(
            f"Not enough specification data on '{product.name}' to calculate quantity — "
            "needs either a Coverage spec or both Length and Width."
        )
    coverage_per_unit, basis = coverage_result

    area_with_waste = area_m2 * (1 + waste_factor)
    units_needed = math.ceil(area_with_waste / coverage_per_unit)

    return QuantityCalculation(
        product_id=str(product.id), sku=product.sku, name=product.name,
        area_m2=area_m2, waste_factor=waste_factor, coverage_per_unit_m2=round(coverage_per_unit, 4),
        units_needed=units_needed, basis=basis,
    )
