from uuid import UUID

from sqlalchemy.orm import Session

from models.analytics import AnalyticsEvent


def record_event(db: Session, merchant_id: UUID, event_type: str, payload: dict | None = None, chat_id: UUID | None = None) -> None:
    """
    Adds an event to the session — deliberately does NOT commit. Analytics
    events are recorded alongside other work (a chat turn, a click) that
    already has its own commit point; forcing a commit here would mean two
    round trips per chat message for no benefit, and risks committing half
    a chat turn if analytics recording happens before the "real" work
    finishes. Callers commit once, at the natural end of the request.
    """
    db.add(AnalyticsEvent(merchant_id=merchant_id, event_type=event_type, chat_id=chat_id, payload=payload or {}))
