from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from engines.knowledge_engine.kg_repository import create_edge_if_new, get_or_create_node
from models.catalogue import Brand, Category, Product


def build_deterministic_edges(db: Session, merchant_id: UUID) -> dict:
    """
    Creates PRODUCT nodes for every product, plus CATEGORY/BRAND edges from
    the FK relationships already established at import time (architecture
    §4, point 1). These are facts directly from the data — not proposals —
    so they're created with source='import', status='approved': nothing to
    review, a product either is or isn't in a category.

    Idempotent and safe to re-run after every import — create_edge_if_new
    and get_or_create_node both no-op on anything that already exists.
    """
    products = db.scalars(select(Product).where(Product.merchant_id == merchant_id)).all()

    category_nodes: dict[UUID, object] = {}
    brand_nodes: dict[UUID, object] = {}
    category_edges_created = 0
    brand_edges_created = 0

    for product in products:
        product_node = get_or_create_node(db, merchant_id, "PRODUCT", product.name, ref_id=product.id)

        if product.category_id:
            if product.category_id not in category_nodes:
                category = db.get(Category, product.category_id)
                if category:
                    category_nodes[product.category_id] = get_or_create_node(db, merchant_id, "CATEGORY", category.name, ref_id=category.id)
            category_node = category_nodes.get(product.category_id)
            if category_node and create_edge_if_new(db, merchant_id, product_node.id, category_node.id, "CATEGORY", source="import", status="approved"):
                category_edges_created += 1

        if product.brand_id:
            if product.brand_id not in brand_nodes:
                brand = db.get(Brand, product.brand_id)
                if brand:
                    brand_nodes[product.brand_id] = get_or_create_node(db, merchant_id, "BRAND", brand.name, ref_id=brand.id)
            brand_node = brand_nodes.get(product.brand_id)
            if brand_node and create_edge_if_new(db, merchant_id, product_node.id, brand_node.id, "BRAND", source="import", status="approved"):
                brand_edges_created += 1

    db.commit()
    return {
        "products_processed": len(products),
        "category_edges_created": category_edges_created,
        "brand_edges_created": brand_edges_created,
    }
