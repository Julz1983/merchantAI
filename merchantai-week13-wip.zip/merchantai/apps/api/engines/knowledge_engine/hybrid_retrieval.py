from dataclasses import dataclass, field
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from engines.document_engine.embeddings import get_embedding_provider
from engines.document_engine.vector_store import search as vector_search
from engines.knowledge_engine.kg_repository import get_neighborhood
from models.catalogue import Product
from models.knowledge_graph import KGNode

VECTOR_SEARCH_LIMIT = 10  # raw hits fetched before splitting by content_type
MAX_PRIMARY_PRODUCTS = 4
MAX_DOCUMENT_CHUNKS = 3
MAX_RELATED_PRODUCTS = 6


@dataclass
class RetrievedProduct:
    id: str
    sku: str
    name: str
    description: str
    price: float | None
    stock_status: str
    relevance: str  # "vector_match" | a relationship_type like "REQUIRES" — why this product is in context
    related_to: str | None = None  # name of the product that pulled this one in via the KG, if relevance != "vector_match"


@dataclass
class RetrievedChunk:
    id: str
    document_title: str
    page_number: int | None
    content: str


@dataclass
class RetrievalContext:
    products: list[RetrievedProduct] = field(default_factory=list)
    chunks: list[RetrievedChunk] = field(default_factory=list)


def hybrid_retrieve(db: Session, merchant_id: UUID, query: str) -> RetrievalContext:
    """
    Two-stage retrieval per architecture §8:
    1. Vector search across the merchant's collection (products + document
       chunks share one collection, distinguished by content_type).
    2. KG expansion from the top vector-matched products, 1 hop, approved
       edges only — pulls in REQUIRES/ACCESSORY/ALTERNATIVE/COMPATIBLE_WITH
       relationships that raw text similarity wouldn't surface (a customer
       asking about decking boards should also see the joists it requires,
       even if "joist" never appears in their query).
    """
    provider = get_embedding_provider()
    query_vector = provider.embed([query])[0]

    raw_hits = vector_search(merchant_id, query_vector, limit=VECTOR_SEARCH_LIMIT)

    primary_products: list[RetrievedProduct] = []
    chunks: list[RetrievedChunk] = []
    seen_product_ids: set[str] = set()

    for hit in raw_hits:
        payload = hit["payload"]
        if payload.get("content_type") == "product" and len(primary_products) < MAX_PRIMARY_PRODUCTS:
            product_id = payload["product_id"]
            if product_id in seen_product_ids:
                continue
            seen_product_ids.add(product_id)
            primary_products.append(RetrievedProduct(
                id=product_id, sku=payload["sku"], name=payload["name"],
                description=payload.get("description", ""), price=payload.get("price"),
                stock_status=payload.get("stock_status", "unknown"), relevance="vector_match",
            ))
        elif payload.get("content_type") != "product" and len(chunks) < MAX_DOCUMENT_CHUNKS:
            chunks.append(RetrievedChunk(
                id=str(hit["id"]), document_title=payload.get("document_title", ""),
                page_number=payload.get("page_number"), content=payload.get("content", ""),
            ))

    related_products = _expand_via_knowledge_graph(db, merchant_id, primary_products, seen_product_ids)

    return RetrievalContext(products=primary_products + related_products, chunks=chunks)


def _expand_via_knowledge_graph(
    db: Session, merchant_id: UUID, primary_products: list[RetrievedProduct], seen_product_ids: set[str],
) -> list[RetrievedProduct]:
    related: list[RetrievedProduct] = []

    for primary in primary_products:
        if len(related) >= MAX_RELATED_PRODUCTS:
            break

        node = db.scalar(select(KGNode).where(KGNode.merchant_id == merchant_id, KGNode.node_type == "PRODUCT", KGNode.ref_id == UUID(primary.id)))
        if node is None:
            continue

        neighborhood = get_neighborhood(db, merchant_id, node.id, depth=1, only_approved=True)
        related_node_ids = {n.id for n in neighborhood["nodes"] if n.node_type == "PRODUCT" and n.ref_id and str(n.ref_id) not in seen_product_ids}
        if not related_node_ids:
            continue

        # Map node -> relationship_type from the edges we already fetched, so
        # the RAG prompt can say *why* this product is relevant (e.g. "you'll
        # also need" vs "an alternative to").
        node_by_id = {n.id: n for n in neighborhood["nodes"]}
        rel_type_by_node: dict[UUID, str] = {}
        for edge in neighborhood["edges"]:
            if edge.source_node_id == node.id and edge.target_node_id in related_node_ids:
                rel_type_by_node[edge.target_node_id] = edge.relationship_type
            elif edge.target_node_id == node.id and edge.source_node_id in related_node_ids:
                rel_type_by_node[edge.source_node_id] = edge.relationship_type

        related_ref_ids = [node_by_id[nid].ref_id for nid in related_node_ids if nid in rel_type_by_node]
        if not related_ref_ids:
            continue

        related_products_rows = db.scalars(select(Product).where(Product.id.in_(related_ref_ids))).all()
        for product in related_products_rows:
            if str(product.id) in seen_product_ids or len(related) >= MAX_RELATED_PRODUCTS:
                continue
            seen_product_ids.add(str(product.id))
            kg_node_id = next(nid for nid, n in node_by_id.items() if n.ref_id == product.id)
            related.append(RetrievedProduct(
                id=str(product.id), sku=product.sku, name=product.name, description=product.description or "",
                price=float(product.price) if product.price is not None else None, stock_status=product.stock_status,
                relevance=rel_type_by_node[kg_node_id], related_to=primary.name,
            ))

    return related
