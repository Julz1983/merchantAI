from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from models.knowledge_graph import KGEdge, KGNode


def get_or_create_node(db: Session, merchant_id: UUID, node_type: str, label: str, ref_id: UUID | None = None, metadata: dict | None = None) -> KGNode:
    """
    Nodes backed by another table (PRODUCT/CATEGORY/BRAND/DOCUMENT) are keyed
    on (node_type, ref_id) — one node per underlying row, ever. Abstract
    nodes (PROJECT/ATTRIBUTE) have no ref_id, so they're keyed on
    (node_type, label) instead — "Coastal Areas" the attribute should be one
    node that many products point at, not a new node per product.
    """
    if ref_id is not None:
        existing = db.scalar(select(KGNode).where(KGNode.merchant_id == merchant_id, KGNode.node_type == node_type, KGNode.ref_id == ref_id))
    else:
        existing = db.scalar(select(KGNode).where(KGNode.merchant_id == merchant_id, KGNode.node_type == node_type, KGNode.ref_id.is_(None), KGNode.label == label))

    if existing:
        return existing

    node = KGNode(merchant_id=merchant_id, node_type=node_type, ref_id=ref_id, label=label, node_metadata=metadata or {})
    db.add(node)
    db.flush()
    return node


def create_edge_if_new(
    db: Session, merchant_id: UUID, source_node_id: UUID, target_node_id: UUID, relationship_type: str,
    source: str, status: str, weight: float = 1.0, evidence: str | None = None,
) -> KGEdge | None:
    """Returns None (no-op) if this exact edge already exists — dedupe is
    also enforced at the DB level (uq_kg_edges_dedupe, migration 0005) so
    this check is a courtesy that avoids relying on catching an
    IntegrityError for the common re-import/re-extraction case."""
    existing = db.scalar(select(KGEdge).where(
        KGEdge.merchant_id == merchant_id, KGEdge.source_node_id == source_node_id,
        KGEdge.target_node_id == target_node_id, KGEdge.relationship_type == relationship_type,
    ))
    if existing:
        return None

    edge = KGEdge(
        merchant_id=merchant_id, source_node_id=source_node_id, target_node_id=target_node_id,
        relationship_type=relationship_type, source=source, status=status, weight=weight, evidence=evidence,
    )
    db.add(edge)
    db.flush()
    return edge


def get_neighborhood(db: Session, merchant_id: UUID, node_id: UUID, depth: int = 1, only_approved: bool = True) -> dict:
    """
    Recursive CTE traversal up to `depth` hops, treating edges as
    undirected for traversal purposes (an ALTERNATIVE or COMPATIBLE_WITH
    edge is conceptually symmetric, and even directed ones like REQUIRES are
    useful to see from either end in a neighborhood view). Returns
    { nodes: [...], edges: [...] } — the shape the KG viewer and, later, the
    AI Engine's hybrid retrieval (architecture §8) both consume.

    This is the "Postgres-as-graph-database" approach from architecture §0.1
    — correct and fast at per-tenant scale (thousands of nodes), with a
    documented migration trigger (§15) if any tenant's graph grows past what
    a recursive CTE handles comfortably.
    """
    status_filter = "AND e.status = 'approved'" if only_approved else ""

    rows = db.execute(
        text(f"""
            WITH RECURSIVE traversal(node_id, depth) AS (
                SELECT CAST(:start_id AS uuid), 0
                UNION
                SELECT
                    CASE WHEN e.source_node_id = t.node_id THEN e.target_node_id ELSE e.source_node_id END,
                    t.depth + 1
                FROM kg_edges e
                JOIN traversal t ON (e.source_node_id = t.node_id OR e.target_node_id = t.node_id)
                WHERE e.merchant_id = :merchant_id {status_filter} AND t.depth < :depth
            )
            SELECT DISTINCT node_id FROM traversal
        """),
        {"start_id": str(node_id), "merchant_id": str(merchant_id), "depth": depth},
    ).all()
    node_ids = [r[0] for r in rows]

    if not node_ids:
        return {"nodes": [], "edges": []}

    nodes = db.scalars(select(KGNode).where(KGNode.id.in_(node_ids))).all()

    edge_query = select(KGEdge).where(
        KGEdge.merchant_id == merchant_id,
        KGEdge.source_node_id.in_(node_ids),
        KGEdge.target_node_id.in_(node_ids),
    )
    if only_approved:
        edge_query = edge_query.where(KGEdge.status == "approved")
    edges = db.scalars(edge_query).all()

    return {"nodes": nodes, "edges": edges}
