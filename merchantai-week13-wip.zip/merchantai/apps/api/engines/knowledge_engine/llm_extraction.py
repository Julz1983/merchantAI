import os
from dataclasses import dataclass
from typing import Protocol

# Generic builders'-merchant domain terms used by the offline heuristic
# provider below to propose candidate REQUIRES/ACCESSORY edges. Deliberately
# broad category terms, not specific to any one product line, so the
# heuristic isn't over-fit to a single test catalogue.
REQUIRES_KEYWORDS = ["joist", "membrane", "underlay", "batten", "insulation", "primer", "subframe", "substrate"]
ACCESSORY_KEYWORDS = ["clip", "screw", "bracket", "adhesive", "sealant", "tape", "fixing", "fastener", "bolt"]

MAX_CANDIDATES_PER_RUN = 200


@dataclass
class ProductSummary:
    id: str  # product UUID as string
    sku: str
    name: str
    description: str
    category: str | None


@dataclass
class CandidateEdge:
    source_product_id: str
    target_product_id: str
    relationship_type: str
    confidence: float
    evidence: str


class ExtractionProvider(Protocol):
    def propose_edges(self, products: list[ProductSummary]) -> list[CandidateEdge]: ...


class OpenAIExtractionProvider:
    """
    Production provider. Prompts the model with a batch of products and asks
    for structured JSON identifying REQUIRES/ALTERNATIVE/ACCESSORY/
    COMPATIBLE_WITH relationships among them, per architecture §4 point 2.
    Every proposal from this provider is treated as unverified — the caller
    (pipeline.py) always stores these as status='pending', never
    auto-approved, regardless of the confidence this returns.
    """

    BATCH_SIZE = 15  # keep the prompt focused — a huge catalogue in one call degrades relevance, not just cost

    def __init__(self, api_key: str | None = None, model: str = "gpt-4o-mini"):
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))
        self._model = model

    def propose_edges(self, products: list[ProductSummary]) -> list[CandidateEdge]:
        candidates: list[CandidateEdge] = []
        for batch_start in range(0, len(products), self.BATCH_SIZE):
            batch = products[batch_start:batch_start + self.BATCH_SIZE]
            candidates.extend(self._propose_for_batch(batch))
        return candidates

    def _propose_for_batch(self, batch: list[ProductSummary]) -> list[CandidateEdge]:
        import json

        product_lines = "\n".join(
            f"- SKU {p.sku}: {p.name} (category: {p.category or 'none'}) — {p.description or 'no description'}"
            for p in batch
        )
        prompt = (
            "You are analyzing a builders' merchant's product catalogue to find "
            "relationships between products, for a knowledge graph.\n\n"
            f"Products:\n{product_lines}\n\n"
            "Identify relationships between these products using ONLY these "
            "relationship types: REQUIRES, ALTERNATIVE, ACCESSORY, COMPATIBLE_WITH, "
            "NOT_COMPATIBLE_WITH, INSTALLED_WITH.\n"
            "Only propose a relationship if there is clear evidence in the product "
            "names/descriptions — do not guess. Respond with ONLY a JSON object: "
            '{"edges": [{"source_sku": "...", "target_sku": "...", '
            '"relationship_type": "...", "confidence": 0.0-1.0, "evidence": "short quote or reasoning"}]}'
        )

        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
        )
        try:
            parsed = json.loads(response.choices[0].message.content or "{}")
        except json.JSONDecodeError:
            return []

        sku_to_id = {p.sku: p.id for p in batch}
        candidates = []
        for edge in parsed.get("edges", []):
            source_id = sku_to_id.get(edge.get("source_sku"))
            target_id = sku_to_id.get(edge.get("target_sku"))
            rel_type = edge.get("relationship_type")
            if not source_id or not target_id or source_id == target_id:
                continue
            if rel_type not in ("REQUIRES", "ALTERNATIVE", "ACCESSORY", "COMPATIBLE_WITH", "NOT_COMPATIBLE_WITH", "INSTALLED_WITH"):
                continue
            candidates.append(CandidateEdge(
                source_product_id=source_id, target_product_id=target_id, relationship_type=rel_type,
                confidence=max(0.0, min(1.0, float(edge.get("confidence", 0.5)))),
                evidence=str(edge.get("evidence", ""))[:500],
            ))
        return candidates


class LocalKeywordExtractionProvider:
    """
    Deterministic, dependency-free, offline stand-in for KG extraction. Same
    role as embeddings.py's LocalHashEmbeddingProvider: NOT a substitute for
    real extraction quality, but lets the full pipeline (propose -> store as
    pending -> review -> approve) be exercised and tested without an OpenAI
    API key or network access.

    Two heuristics, both generic builders'-merchant domain knowledge rather
    than tuned to any specific test catalogue:
    1. Products sharing a category are proposed as ALTERNATIVE candidates
       (low confidence — same category doesn't necessarily mean substitutable).
    2. A product whose name/description contains a REQUIRES/ACCESSORY keyword
       (joist, membrane, clip, fixing, etc.) is proposed as required-by/
       accessory-to other products that don't themselves look like components.
    """

    def propose_edges(self, products: list[ProductSummary]) -> list[CandidateEdge]:
        candidates: list[CandidateEdge] = []
        candidates.extend(self._same_category_alternatives(products))
        candidates.extend(self._keyword_requires_and_accessories(products))
        return candidates[:MAX_CANDIDATES_PER_RUN]

    @staticmethod
    def _same_category_alternatives(products: list[ProductSummary]) -> list[CandidateEdge]:
        by_category: dict[str, list[ProductSummary]] = {}
        for p in products:
            if p.category:
                by_category.setdefault(p.category, []).append(p)

        candidates = []
        for category, group in by_category.items():
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    candidates.append(CandidateEdge(
                        source_product_id=group[i].id, target_product_id=group[j].id,
                        relationship_type="ALTERNATIVE", confidence=0.4,
                        evidence=f"Both products are in the '{category}' category",
                    ))
        return candidates

    @staticmethod
    def _looks_like_component(text: str) -> bool:
        return any(kw in text for kw in REQUIRES_KEYWORDS + ACCESSORY_KEYWORDS)

    def _keyword_requires_and_accessories(self, products: list[ProductSummary]) -> list[CandidateEdge]:
        candidates = []
        for base in products:
            base_text = f"{base.name} {base.description or ''}".lower()
            if self._looks_like_component(base_text):
                continue  # a component isn't usually the source of a REQUIRES/ACCESSORY edge

            for other in products:
                if other.id == base.id:
                    continue
                other_text = f"{other.name} {other.description or ''}".lower()

                matched_requires = next((kw for kw in REQUIRES_KEYWORDS if kw in other_text), None)
                if matched_requires:
                    candidates.append(CandidateEdge(
                        source_product_id=base.id, target_product_id=other.id, relationship_type="REQUIRES",
                        confidence=0.5, evidence=f"'{matched_requires}' found in {other.sku}'s description",
                    ))
                    continue

                matched_accessory = next((kw for kw in ACCESSORY_KEYWORDS if kw in other_text), None)
                if matched_accessory:
                    candidates.append(CandidateEdge(
                        source_product_id=base.id, target_product_id=other.id, relationship_type="ACCESSORY",
                        confidence=0.5, evidence=f"'{matched_accessory}' found in {other.sku}'s description",
                    ))
        return candidates


def get_extraction_provider() -> ExtractionProvider:
    """Same env-based selection pattern as embeddings.get_embedding_provider()."""
    if os.environ.get("OPENAI_API_KEY"):
        return OpenAIExtractionProvider()
    return LocalKeywordExtractionProvider()
