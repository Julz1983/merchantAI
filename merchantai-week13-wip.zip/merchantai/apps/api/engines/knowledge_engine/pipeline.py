from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from engines.knowledge_engine.deterministic_edges import build_deterministic_edges
from engines.knowledge_engine.kg_repository import create_edge_if_new, get_or_create_node
from engines.knowledge_engine.llm_extraction import ProductSummary, get_extraction_provider
from models.catalogue import Category, Product


def build_knowledge_graph(db: Session, merchant_id: UUID) -> dict:
    """
    Full KG build for a merchant: deterministic edges first (fast, free,
    zero error rate — architecture §4 point 1), then LLM-assisted extraction
    of semantic edges, stored as pending review (§4 point 2). Called after
    every product import (see routers/products.py) so "importing a
    catalogue produces a reviewable graph" — this week's exit criteria —
    holds without a separate manual trigger.

    Safe to re-run: deterministic edges are idempotent, and LLM extraction
    skips any candidate that would duplicate an edge that already exists
    (approved, rejected, or still pending) via create_edge_if_new.
    """
    deterministic_result = build_deterministic_edges(db, merchant_id)
    extraction_result = _run_llm_extraction(db, merchant_id)
    return {**deterministic_result, **extraction_result}


def _run_llm_extraction(db: Session, merchant_id: UUID) -> dict:
    rows = db.execute(
        select(Product, Category.name)
        .outerjoin(Category, Product.category_id == Category.id)
        .where(Product.merchant_id == merchant_id)
    ).all()

    products = [
        ProductSummary(id=str(p.id), sku=p.sku, name=p.name, description=p.description or "", category=category_name)
        for p, category_name in rows
    ]
    if len(products) < 2:
        return {"candidate_edges_proposed": 0}

    provider = get_extraction_provider()
    candidates = provider.propose_edges(products)

    proposed_count = 0
    for candidate in candidates:
        source_product = next((p for p in products if p.id == candidate.source_product_id), None)
        target_product = next((p for p in products if p.id == candidate.target_product_id), None)
        if not source_product or not target_product:
            continue

        source_node = get_or_create_node(db, merchant_id, "PRODUCT", source_product.name, ref_id=UUID(candidate.source_product_id))
        target_node = get_or_create_node(db, merchant_id, "PRODUCT", target_product.name, ref_id=UUID(candidate.target_product_id))

        edge = create_edge_if_new(
            db, merchant_id, source_node.id, target_node.id, candidate.relationship_type,
            source="llm_extracted", status="pending", weight=candidate.confidence, evidence=candidate.evidence,
        )
        if edge:
            proposed_count += 1

    db.commit()
    return {"candidate_edges_proposed": proposed_count}
