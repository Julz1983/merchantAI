import re
from dataclasses import dataclass, field

# Product fields a merchant's spreadsheet column can map onto (brief §"Product Import: Fields").
TARGET_FIELDS = [
    "sku", "name", "description", "category", "price", "brand",
    "images", "product_url", "specifications", "attributes", "stock_status",
]
REQUIRED_FIELDS = {"sku", "name"}

# Known synonyms for auto-suggesting a mapping from a merchant's raw column
# headers — this is what makes the import screen usable without the merchant
# having to rename their spreadsheet columns first.
_SYNONYMS: dict[str, list[str]] = {
    "sku": ["sku", "item code", "code", "product code", "part number"],
    "name": ["name", "product name", "title", "product title"],
    "description": ["description", "desc", "product description"],
    "category": ["category", "cat", "product category", "department"],
    "price": ["price", "cost", "rrp", "unit price", "sell price"],
    "brand": ["brand", "manufacturer", "make"],
    "images": ["images", "image", "photo", "photos", "image url", "image urls"],
    "product_url": ["product_url", "url", "link", "product link", "product page"],
    "specifications": ["specifications", "specs", "spec"],
    "attributes": ["attributes", "attrs", "tags"],
    "stock_status": ["stock_status", "stock", "availability", "in stock"],
}


def _normalize(header: str) -> str:
    return re.sub(r"[\s_\-]+", " ", header.strip().lower())


def suggest_mapping(headers: list[str]) -> dict[str, str]:
    """Returns { target_field: source_header } for every target field we can
    confidently guess. Fields the merchant will need to map manually are
    simply absent from the result — the dashboard renders those as empty
    dropdowns rather than us guessing wrong."""
    normalized_lookup = {_normalize(h): h for h in headers}
    mapping: dict[str, str] = {}
    for target, synonyms in _SYNONYMS.items():
        for synonym in synonyms:
            if synonym in normalized_lookup:
                mapping[target] = normalized_lookup[synonym]
                break
    return mapping


@dataclass
class NormalizedRow:
    row_number: int  # 1-indexed, matches what a merchant sees if they open the file
    sku: str = ""
    name: str = ""
    description: str | None = None
    category: str | None = None
    price: float | None = None
    brand: str | None = None
    images: list[str] = field(default_factory=list)
    product_url: str | None = None
    specifications: dict = field(default_factory=dict)
    attributes: dict = field(default_factory=dict)
    stock_status: str = "unknown"
    errors: list[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return not self.errors


def _parse_kv_pairs(raw: str) -> dict:
    """'Width: 150mm | Length: 3.6m' -> {'Width': '150mm', 'Length': '3.6m'}.
    Tolerant by design: malformed pairs are skipped, never fail the row —
    specifications/attributes are supplementary, not required for a valid import."""
    result = {}
    if not raw:
        return result
    for pair in raw.split("|"):
        if ":" not in pair:
            continue
        key, _, value = pair.partition(":")
        key, value = key.strip(), value.strip()
        if key and value:
            result[key] = value
    return result


def _parse_stock_status(raw: str) -> str:
    normalized = raw.strip().lower()
    if normalized in ("in stock", "in_stock", "yes", "true", "available"):
        return "in_stock"
    if normalized in ("out of stock", "out_of_stock", "no", "false", "unavailable"):
        return "out_of_stock"
    return "unknown"


def apply_mapping(sheet_rows: list[dict[str, str]], mapping: dict[str, str]) -> list[NormalizedRow]:
    """mapping: { target_field: source_header }. Missing/blank optional fields
    are fine; missing required fields (sku, name) are recorded as row errors
    and the row is skipped at import time rather than failing the whole batch —
    a single bad row in a 4,000-line catalogue shouldn't block the other 3,999."""
    normalized: list[NormalizedRow] = []

    for i, raw_row in enumerate(sheet_rows, start=1):
        def get(field_name: str) -> str:
            header = mapping.get(field_name)
            return raw_row.get(header, "").strip() if header else ""

        row = NormalizedRow(row_number=i)
        row.sku = get("sku")
        row.name = get("name")
        row.description = get("description") or None
        row.category = get("category") or None
        row.brand = get("brand") or None
        row.product_url = get("product_url") or None
        row.stock_status = _parse_stock_status(get("stock_status"))

        price_raw = get("price")
        if price_raw:
            try:
                row.price = float(re.sub(r"[^\d.]", "", price_raw))
            except ValueError:
                row.errors.append(f"Price '{price_raw}' isn't a valid number")

        images_raw = get("images")
        if images_raw:
            row.images = [u.strip() for u in re.split(r"[,|]", images_raw) if u.strip()]

        row.specifications = _parse_kv_pairs(get("specifications"))
        row.attributes = _parse_kv_pairs(get("attributes"))

        if not row.sku:
            row.errors.append("Missing SKU (required)")
        if not row.name:
            row.errors.append("Missing product name (required)")

        normalized.append(row)

    return normalized
