import io

from openpyxl import load_workbook

from engines.import_engine.parsers.base import ParsedSheet, ParseError


class XLSXParser:
    def parse(self, file_bytes: bytes) -> ParsedSheet:
        try:
            workbook = load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
        except Exception as exc:  # openpyxl raises several exception types for bad files
            raise ParseError("Couldn't read this file as an Excel workbook.") from exc

        sheet = workbook.active
        rows_iter = sheet.iter_rows(values_only=True)

        try:
            header_row = next(rows_iter)
        except StopIteration as exc:
            raise ParseError("This spreadsheet is empty.") from exc

        headers = [str(h).strip() if h is not None else "" for h in header_row]

        rows: list[dict[str, str]] = []
        for raw_row in rows_iter:
            if raw_row is None or all(cell is None for cell in raw_row):
                continue  # skip fully blank rows
            row = {}
            for header, cell in zip(headers, raw_row):
                if not header:
                    continue
                row[header] = "" if cell is None else str(cell).strip()
            rows.append(row)

        if not rows:
            raise ParseError("This spreadsheet has a header row but no data rows.")

        return ParsedSheet(headers=headers, rows=rows)
