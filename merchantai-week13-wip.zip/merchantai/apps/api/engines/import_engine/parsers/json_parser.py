import json

from engines.import_engine.parsers.base import ParsedSheet, ParseError


class JSONParser:
    """
    Accepts two shapes:
    1. A top-level JSON array of objects: [{"sku": "...", "name": "...", ...}, ...]
    2. A top-level object with exactly one array-valued key (a common export
       shape, e.g. {"products": [...]}) — that array is used as the rows.

    Converts every value to a string on the way out, matching the contract
    CSVParser and XLSXParser already establish (mapping.py's apply_mapping
    expects string cell values regardless of source format) — a JSON number
    or boolean becomes "45.99" or "true", not a Python float/bool, so
    downstream parsing (mapping.py's price/stock-status coercion) behaves
    identically no matter which file format a merchant exports from.
    """

    def parse(self, file_bytes: bytes) -> ParsedSheet:
        try:
            text = file_bytes.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ParseError("File is not valid UTF-8 text. Export as UTF-8 JSON and try again.") from exc

        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ParseError(f"Invalid JSON: {exc.msg} at line {exc.lineno}.") from exc

        records = self._extract_records(parsed)

        if not records:
            raise ParseError("This JSON file contains no product records.")

        if not all(isinstance(r, dict) for r in records):
            raise ParseError("Every item in the JSON array must be an object (e.g. {\"sku\": \"...\", \"name\": \"...\"}).")

        # Headers are the union of keys across all records, order-preserving
        # by first appearance — real exports are sometimes inconsistent
        # about which optional fields each record includes, so this can't
        # just take the first record's keys.
        headers: list[str] = []
        seen = set()
        for record in records:
            for key in record.keys():
                if key not in seen:
                    seen.add(key)
                    headers.append(key)

        rows = [
            {key: self._stringify(record.get(key)) for key in headers}
            for record in records
        ]

        return ParsedSheet(headers=headers, rows=rows)

    @staticmethod
    def _extract_records(parsed) -> list:
        if isinstance(parsed, list):
            return parsed

        if isinstance(parsed, dict):
            array_valued = {k: v for k, v in parsed.items() if isinstance(v, list)}
            if len(array_valued) == 1:
                return next(iter(array_valued.values()))
            if len(array_valued) > 1:
                raise ParseError(
                    f"This JSON object has multiple array fields ({', '.join(array_valued.keys())}) — "
                    "unclear which one holds the products. Export a top-level array instead."
                )
            raise ParseError("This JSON object has no array field containing product records.")

        raise ParseError("Expected a JSON array of products, or an object containing one.")

    @staticmethod
    def _stringify(value) -> str:
        if value is None:
            return ""
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (dict, list)):
            # Nested structures (e.g. a JSON array of spec objects) get
            # serialized back to a JSON string rather than dropped — better
            # to hand mapping.py something it can't fully parse than to
            # silently lose data the merchant's export actually contained.
            return json.dumps(value)
        return str(value)
