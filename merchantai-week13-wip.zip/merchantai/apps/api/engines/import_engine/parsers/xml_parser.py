from engines.import_engine.parsers.base import ParsedSheet, ParseError


class XMLParser:
    """
    Expects a simple, flat "records" shape — the format most product-export
    tools actually produce:

        <products>
          <product>
            <sku>DK-100</sku>
            <name>Composite Decking Board 3.6m</name>
            <price>45.99</price>
          </product>
          <product>...</product>
        </products>

    The root element's tag name and each record's tag name are both
    read from the file itself (not hardcoded to "products"/"product") —
    whatever the root's direct children are named, each one becomes a row,
    and each of ITS children becomes a field. Attributes are ignored;
    only child-element text content is read, since attribute-based exports
    are rare for this use case and would need a different, incompatible
    row model.
    """

    def parse(self, file_bytes: bytes) -> ParsedSheet:
        root = self._safe_parse(file_bytes)

        record_elements = list(root)
        if not record_elements:
            raise ParseError(f"The <{root.tag}> root element has no child records.")

        headers: list[str] = []
        seen = set()
        rows: list[dict[str, str]] = []

        for record_el in record_elements:
            row: dict[str, str] = {}
            for field_el in record_el:
                tag = field_el.tag
                if tag not in seen:
                    seen.add(tag)
                    headers.append(tag)
                row[tag] = (field_el.text or "").strip()
            rows.append(row)

        if not headers:
            raise ParseError(f"Records under <{root.tag}> have no field elements to read.")

        normalized_rows = [{h: row.get(h, "") for h in headers} for row in rows]

        return ParsedSheet(headers=headers, rows=normalized_rows)

    @staticmethod
    def _safe_parse(file_bytes: bytes):
        # defusedxml guards against XML-specific attacks (billion-laughs
        # entity expansion, external entity/XXE file disclosure) that
        # Python's built-in xml.etree does not protect against by default.
        # Falls back to stdlib only if defusedxml genuinely isn't installed,
        # so this doesn't hard-fail an otherwise-working deployment — but
        # every real deployment should have defusedxml available (it's in
        # requirements.txt).
        try:
            from defusedxml import ElementTree as SafeET
            from defusedxml.common import DefusedXmlException

            try:
                return SafeET.fromstring(file_bytes)
            except DefusedXmlException as exc:
                raise ParseError("This XML file was rejected as potentially unsafe (e.g. entity expansion).") from exc
            except Exception as exc:  # noqa: BLE001 — includes ElementTree.ParseError, whose exact type varies
                raise ParseError(f"Couldn't parse this XML file: {exc}") from exc
        except ImportError:
            import xml.etree.ElementTree as ET

            try:
                return ET.fromstring(file_bytes)
            except ET.ParseError as exc:
                raise ParseError(f"Couldn't parse this XML file: {exc}") from exc
