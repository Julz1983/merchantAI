from dataclasses import dataclass
from typing import Protocol


@dataclass
class ParsedSheet:
    """Raw parse result — headers as found in the file, rows as header->cell dicts.
    No knowledge of product fields yet; that's mapping.py's job. This is what
    lets CSV and XLSX share one mapping/validation/import pipeline."""

    headers: list[str]
    rows: list[dict[str, str]]


class Parser(Protocol):
    def parse(self, file_bytes: bytes) -> ParsedSheet: ...


class ParseError(Exception):
    """Raised when a file can't be read at all (corrupt, wrong format, empty)."""
