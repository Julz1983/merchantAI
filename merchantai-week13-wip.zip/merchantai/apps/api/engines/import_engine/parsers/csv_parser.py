import csv
import io

from engines.import_engine.parsers.base import ParsedSheet, ParseError


class CSVParser:
    def parse(self, file_bytes: bytes) -> ParsedSheet:
        try:
            text = file_bytes.decode("utf-8-sig")  # tolerate Excel-exported BOM
        except UnicodeDecodeError as exc:
            raise ParseError("File is not valid UTF-8 text. Export as UTF-8 CSV and try again.") from exc

        reader = csv.DictReader(io.StringIO(text))
        if reader.fieldnames is None:
            raise ParseError("Couldn't find a header row in this CSV.")

        headers = [h.strip() for h in reader.fieldnames]
        rows = [
            {k.strip(): (v or "").strip() for k, v in row.items() if k is not None}
            for row in reader
        ]

        if not rows:
            raise ParseError("This CSV has a header row but no data rows.")

        return ParsedSheet(headers=headers, rows=rows)
