from engines.import_engine.parsers.base import Parser, ParsedSheet, ParseError
from engines.import_engine.parsers.csv_parser import CSVParser
from engines.import_engine.parsers.json_parser import JSONParser
from engines.import_engine.parsers.xlsx_parser import XLSXParser
from engines.import_engine.parsers.xml_parser import XMLParser

# Pluggable by design (brief: CSV/Excel/XML/JSON). CSV/XLSX shipped at MVP
# (architecture §0.2); JSON/XML added post-MVP — adding them required only
# a new parser file each plus this registry entry, no changes to
# mapping.py or product_import.py, exactly as designed.
_PARSERS: dict[str, Parser] = {
    ".csv": CSVParser(),
    ".xlsx": XLSXParser(),
    ".json": JSONParser(),
    ".xml": XMLParser(),
}


def get_parser(filename: str) -> Parser:
    lower = filename.lower()
    for ext, parser in _PARSERS.items():
        if lower.endswith(ext):
            return parser
    raise ParseError(f"Unsupported file type. Supported formats: {', '.join(_PARSERS.keys())}")


__all__ = ["get_parser", "ParsedSheet", "ParseError"]
