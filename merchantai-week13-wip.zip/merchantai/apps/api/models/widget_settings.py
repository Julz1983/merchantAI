import uuid

from sqlalchemy import JSON, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import Mapped, mapped_column

from core.db import Base


class WidgetSettings(Base):
    __tablename__ = "widget_settings"

    merchant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("merchants.id", ondelete="CASCADE"), primary_key=True)

    launcher_position: Mapped[str] = mapped_column(String(16), default="bottom-right")  # bottom-right | bottom-left
    greeting_message: Mapped[str] = mapped_column(String(500), default="Hi! How can I help you find what you need?")
    theme_overrides: Mapped[dict] = mapped_column(JSON, default=dict)
