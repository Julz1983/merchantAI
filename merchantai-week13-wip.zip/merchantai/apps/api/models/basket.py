import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import Mapped, mapped_column

from core.db import Base


class Basket(Base):
    """
    A shopping list tied to a widget session, not a customer account —
    widget sessions are anonymous by design (see models/chat.py's Chat
    model, same reasoning applies here). One basket per (merchant,
    session_id), matching how Chat is keyed.
    """

    __tablename__ = "baskets"

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False)
    session_id: Mapped[str] = mapped_column(String(255), nullable=False)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class BasketItem(Base):
    __tablename__ = "basket_items"

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    basket_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("baskets.id", ondelete="CASCADE"), nullable=False)
    merchant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False)
    product_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("products.id", ondelete="CASCADE"), nullable=False)

    quantity: Mapped[int] = mapped_column(Integer, default=1)

    # How this item entered the basket — "assistant" (added from a chat
    # recommendation) vs "manual" (customer clicked "add" on a card
    # unprompted). Not used for anything functional yet, but cheap to
    # capture now and useful for the analytics question "does the assistant
    # actually drive basket adds" later, without a schema change.
    source: Mapped[str] = mapped_column(String(16), default="assistant")

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
