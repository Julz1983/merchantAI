import uuid
from datetime import datetime

from sqlalchemy import JSON, DateTime, Float, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import Mapped, mapped_column

from core.db import Base

NODE_TYPES = ("PRODUCT", "CATEGORY", "BRAND", "DOCUMENT", "PROJECT", "ATTRIBUTE")

RELATIONSHIP_TYPES = (
    "REQUIRES", "OPTIONAL", "ALTERNATIVE", "COMPATIBLE_WITH", "NOT_COMPATIBLE_WITH",
    "INSTALLED_WITH", "PART_OF_PROJECT", "USED_BY", "CATEGORY", "BRAND", "DOCUMENT", "ACCESSORY",
)

# Deterministic edges (from import data) and manual edges are auto-published —
# there's nothing to review, the relationship is a direct fact from the data
# (a product IS in this category) or a merchant typed it in themselves.
# LLM-extracted edges start "pending" and are never auto-published — see
# architecture §4: this is the concrete implementation of "nothing
# LLM-extracted goes live without merchant review".
EDGE_STATUSES = ("pending", "approved", "rejected")
EDGE_SOURCES = ("import", "llm_extracted", "manual")


class KGNode(Base):
    __tablename__ = "kg_nodes"

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False)

    node_type: Mapped[str] = mapped_column(String(32), nullable=False)
    # Polymorphic pointer to products.id / categories.id / documents.id, etc.
    # Nullable for abstract nodes (PROJECT, ATTRIBUTE) that don't back onto
    # another table — see architecture §4.
    ref_id: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True), nullable=True)
    label: Mapped[str] = mapped_column(String(500), nullable=False)
    node_metadata: Mapped[dict] = mapped_column(JSON, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class KGEdge(Base):
    __tablename__ = "kg_edges"

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False)

    source_node_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("kg_nodes.id", ondelete="CASCADE"), nullable=False)
    target_node_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("kg_nodes.id", ondelete="CASCADE"), nullable=False)
    relationship_type: Mapped[str] = mapped_column(String(32), nullable=False)

    weight: Mapped[float] = mapped_column(Float, default=1.0)  # confidence / relevance
    source: Mapped[str] = mapped_column(String(16), default="manual")  # import | llm_extracted | manual
    status: Mapped[str] = mapped_column(String(16), default="approved")  # pending | approved | rejected

    # For llm_extracted edges: the text snippet that justified the proposal,
    # shown in the review UI so a merchant isn't asked to trust a bare claim.
    evidence: Mapped[str | None] = mapped_column(String, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
