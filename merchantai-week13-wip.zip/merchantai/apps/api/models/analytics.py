import uuid
from datetime import datetime

from sqlalchemy import JSON, DateTime, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import Mapped, mapped_column

from core.db import Base

# Per brief: "Track Questions, Recommendations, Clicks, Products Found,
# Products Missing, Documents Used, Knowledge Graph Paths Used, Conversion
# Events." Conversion isn't captured yet — it needs a real e-commerce
# integration (webhook/pixel from the merchant's storefront) that's out of
# MVP scope; the event_type is reserved here so adding it later is additive.
# basket_add is an addition beyond the brief's original list, tracking the
# Basket Builder module (architecture Journey B) — the concrete signal that
# closes the loop from "recommended" all the way to "customer built a list".
EVENT_TYPES = (
    "question", "recommendation", "click", "product_found", "product_missing",
    "document_used", "kg_path_used", "conversion", "basket_add",
)


class AnalyticsEvent(Base):
    __tablename__ = "analytics_events"

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    merchant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("merchants.id", ondelete="CASCADE"), nullable=False)

    event_type: Mapped[str] = mapped_column(String(32), nullable=False)
    chat_id: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True), ForeignKey("chats.id", ondelete="SET NULL"), nullable=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
