# Deploying MerchantAI (staging / single-host production)

This covers the "single small host" deployment tier from architecture §12 —
appropriate for staging and early production, before traffic justifies
managed services. See architecture §15 for the trigger-based migration path
to managed Postgres/Qdrant/Redis, read replicas, and multi-region as the
platform scales.

## Prerequisites

- A host with Docker and the Docker Compose plugin installed
- A domain name pointed at the host (for TLS)
- At minimum one of `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` — without either,
  the platform runs on offline stub providers, which is fine for an internal
  demo but not for real customer traffic (see
  `apps/api/engines/ai_engine/llm_gateway.py`)

## Steps

1. **Configure secrets**
   ```bash
   cd infra
   cp .env.prod.example .env.prod
   ```
   Fill in every value marked `CHANGE_ME`. Generate `JWT_SECRET` with
   `openssl rand -hex 32`, and separate strong random passwords for
   `POSTGRES_PASSWORD` and `APP_DB_PASSWORD` (they must be different —
   these are two different Postgres roles with very different privileges,
   see `core/bootstrap_roles.py`).

2. **Build and start**
   ```bash
   docker compose -f docker-compose.prod.yml up --build -d
   ```

3. **Run migrations and bootstrap the restricted app role** (first deploy,
   and after every deploy that adds a migration)
   ```bash
   docker compose -f docker-compose.prod.yml exec api alembic upgrade head
   docker compose -f docker-compose.prod.yml exec api python -m core.bootstrap_roles
   ```
   **This second step is not optional.** Skipping it means the API
   connects to Postgres as the migration/superuser role, which silently
   disables Row-Level Security platform-wide — every tenant's data becomes
   visible to every other tenant, with no error or warning. See the root
   README's "Design notes" section for how this was actually caught during
   development, and `apps/api/core/rls_audit.py` for a script that verifies
   this didn't happen — run it as a post-deploy check:
   ```bash
   docker compose -f docker-compose.prod.yml exec api python -m core.rls_audit
   ```

4. **TLS.** The bundled `nginx.conf` starts HTTP-only. Provision certificates
   (e.g. `certbot certonly --standalone` for the domain, or your platform's
   managed cert if using a cloud load balancer instead of the bundled nginx
   container), mount them into `infra/nginx/certs/`, then uncomment the
   `https` server block in `infra/nginx/nginx.conf` and the HTTP→HTTPS
   redirect, and restart nginx.

5. **Seed a demo merchant** (optional — skip for a real customer onboarding,
   which should go through the dashboard's own signup flow once built)
   ```bash
   docker compose -f docker-compose.prod.yml exec api python -m core.seed
   ```

## Post-deploy checklist

- [ ] `alembic upgrade head` ran successfully
- [ ] `core.bootstrap_roles` ran successfully — **check this is not skipped**
- [ ] `core.rls_audit` passes with no problems
- [ ] TLS certificate is valid and HTTP redirects to HTTPS
- [ ] At least one of `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` is set (skip
      only for an internal/offline demo)
- [ ] `docker compose ps` shows all services healthy/running

## What this tier does NOT include

- Read replicas, connection pooling beyond SQLAlchemy's own pool, or
  multi-region — see architecture §15 for the triggers that justify each
- Automated backups — set these up at the infrastructure layer (e.g.
  scheduled `pg_dump` to object storage, or use a managed Postgres instance
  that includes this)
- Log aggregation / APM — the API logs unhandled exceptions to stdout
  (`core/error_handlers.py`); ship container logs to your platform's
  logging service
